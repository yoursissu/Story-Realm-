/** @type {import('tailwindcss').Config} */
module.exports = {
  darkMode: ["class"],
  content: [
    './pages/**/*.{js,jsx}',
    './components/**/*.{js,jsx}',
    './app/**/*.{js,jsx}',
    './src/**/*.{js,jsx}',
  ],
  prefix: "",
  theme: {
    container: {
      center: true,
      padding: "2rem",
      screens: {
        "2xl": "1400px",
      },
    },
    extend: {
      colors: {
        border: "var(--color-border)", // soft tan
        input: "var(--color-input)", // subtle cream
        ring: "var(--color-ring)", // warm brown
        background: "var(--color-background)", // warm off-white
        foreground: "var(--color-foreground)", // rich dark brown
        primary: {
          DEFAULT: "var(--color-primary)", // warm brown
          foreground: "var(--color-primary-foreground)", // warm off-white
        },
        secondary: {
          DEFAULT: "var(--color-secondary)", // soft tan
          foreground: "var(--color-secondary-foreground)", // rich dark brown
        },
        destructive: {
          DEFAULT: "var(--color-destructive)", // muted red
          foreground: "var(--color-destructive-foreground)", // warm off-white
        },
        muted: {
          DEFAULT: "var(--color-muted)", // subtle cream
          foreground: "var(--color-muted-foreground)", // medium brown
        },
        accent: {
          DEFAULT: "var(--color-accent)", // energizing coral
          foreground: "var(--color-accent-foreground)", // warm off-white
        },
        popover: {
          DEFAULT: "var(--color-popover)", // warm off-white
          foreground: "var(--color-popover-foreground)", // rich dark brown
        },
        card: {
          DEFAULT: "var(--color-card)", // subtle cream
          foreground: "var(--color-card-foreground)", // rich dark brown
        },
        success: {
          DEFAULT: "var(--color-success)", // forest green
          foreground: "var(--color-success-foreground)", // warm off-white
        },
        warning: {
          DEFAULT: "var(--color-warning)", // golden yellow
          foreground: "var(--color-warning-foreground)", // rich dark brown
        },
        error: {
          DEFAULT: "var(--color-error)", // muted red
          foreground: "var(--color-error-foreground)", // warm off-white
        },
      },
      borderRadius: {
        lg: "var(--radius)",
        md: "calc(var(--radius) - 2px)",
        sm: "calc(var(--radius) - 4px)",
      },
      fontFamily: {
        heading: ['Crimson Text', 'serif'],
        body: ['Source Sans 3', 'sans-serif'],
        caption: ['Inter', 'sans-serif'],
        mono: ['JetBrains Mono', 'monospace'],
      },
      boxShadow: {
        'warm-sm': '0 1px 2px 0 rgba(139, 69, 19, 0.1)',
        'warm': '0 1px 3px 0 rgba(139, 69, 19, 0.1), 0 1px 2px 0 rgba(139, 69, 19, 0.06)',
        'warm-md': '0 4px 6px -1px rgba(139, 69, 19, 0.1), 0 2px 4px -1px rgba(139, 69, 19, 0.06)',
        'warm-lg': '0 10px 15px -3px rgba(139, 69, 19, 0.1), 0 4px 6px -2px rgba(139, 69, 19, 0.05)',
        'warm-xl': '0 20px 25px -5px rgba(139, 69, 19, 0.1), 0 10px 10px -5px rgba(139, 69, 19, 0.04)',
      },
      keyframes: {
        "accordion-down": {
          from: { height: "0" },
          to: { height: "var(--radix-accordion-content-height)" },
        },
        "accordion-up": {
          from: { height: "var(--radix-accordion-content-height)" },
          to: { height: "0" },
        },
      },
      animation: {
        "accordion-down": "accordion-down 0.2s ease-out",
        "accordion-up": "accordion-up 0.2s ease-out",
      },
      transitionTimingFunction: {
        'warm': 'cubic-bezier(0.4, 0, 0.2, 1)',
      },
      spacing: {
        '18': '4.5rem',
        '88': '22rem',
      },
    },
  },
  plugins: [
    require("tailwindcss-animate"),
  ],
}