import React from "react";
import { BrowserRouter, Routes as RouterRoutes, Route } from "react-router-dom";
import ScrollToTop from "components/ScrollToTop";
import ErrorBoundary from "components/ErrorBoundary";
import NotFound from "pages/NotFound";
import UserLogin from './pages/user-login';
import InteractiveStoryReader from './pages/interactive-story-reader';
import StoryCreationEditor from './pages/story-creation-editor';
import UserProfileManagement from './pages/user-profile-management';
import UserRegistration from './pages/user-registration';
import StoryDiscoveryDashboard from './pages/story-discovery-dashboard';

const Routes = () => {
  return (
    <BrowserRouter>
      <ErrorBoundary>
      <ScrollToTop />
      <RouterRoutes>
        {/* Define your route here */}
        <Route path="/" element={<InteractiveStoryReader />} />
        <Route path="/user-login" element={<UserLogin />} />
        <Route path="/interactive-story-reader" element={<InteractiveStoryReader />} />
        <Route path="/story-creation-editor" element={<StoryCreationEditor />} />
        <Route path="/user-profile-management" element={<UserProfileManagement />} />
        <Route path="/user-registration" element={<UserRegistration />} />
        <Route path="/story-discovery-dashboard" element={<StoryDiscoveryDashboard />} />
        <Route path="*" element={<NotFound />} />
      </RouterRoutes>
      </ErrorBoundary>
    </BrowserRouter>
  );
};

export default Routes;
