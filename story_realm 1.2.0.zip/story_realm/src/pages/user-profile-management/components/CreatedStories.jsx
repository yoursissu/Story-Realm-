import React, { useState } from 'react';
import Image from '../../../components/AppImage';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const CreatedStories = ({ stories, onEditStory, onDeleteStory }) => {
  const [viewMode, setViewMode] = useState('grid'); // 'grid' or 'list'
  const [sortBy, setSortBy] = useState('recent'); // 'recent', 'popular', 'title'

  const sortedStories = [...stories]?.sort((a, b) => {
    switch (sortBy) {
      case 'popular':
        return b?.views - a?.views;
      case 'title':
        return a?.title?.localeCompare(b?.title);
      case 'recent':
      default:
        return new Date(b.lastUpdated) - new Date(a.lastUpdated);
    }
  });

  const StoryCard = ({ story }) => (
    <div className="bg-card rounded-lg border border-border overflow-hidden hover:shadow-lg transition-shadow">
      <div className="relative">
        <div className="aspect-video overflow-hidden">
          <Image
            src={story?.coverImage}
            alt={story?.title}
            className="w-full h-full object-cover"
          />
        </div>
        <div className="absolute top-2 right-2">
          <span className={`px-2 py-1 rounded-full text-xs font-medium ${
            story?.status === 'published' ?'bg-success text-success-foreground'
              : story?.status === 'draft' ?'bg-warning text-warning-foreground' :'bg-muted text-muted-foreground'
          }`}>
            {story?.status}
          </span>
        </div>
      </div>
      
      <div className="p-4">
        <div className="flex items-start justify-between mb-2">
          <h3 className="font-semibold text-foreground line-clamp-2">{story?.title}</h3>
          <div className="flex items-center gap-1 ml-2">
            <Button variant="ghost" size="icon" onClick={() => onEditStory(story?.id)}>
              <Icon name="Edit" size={16} />
            </Button>
            <Button variant="ghost" size="icon" onClick={() => onDeleteStory(story?.id)}>
              <Icon name="Trash2" size={16} />
            </Button>
          </div>
        </div>
        
        <p className="text-sm text-muted-foreground mb-3 line-clamp-2">
          {story?.description}
        </p>
        
        <div className="flex items-center gap-2 mb-3">
          <span className="px-2 py-1 bg-primary/10 text-primary text-xs rounded-full">
            {story?.genre}
          </span>
          <span className="text-xs text-muted-foreground">
            {story?.chapters} chapters
          </span>
        </div>
        
        <div className="flex items-center justify-between text-sm text-muted-foreground">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-1">
              <Icon name="Eye" size={14} />
              <span>{story?.views}</span>
            </div>
            <div className="flex items-center gap-1">
              <Icon name="Heart" size={14} />
              <span>{story?.likes}</span>
            </div>
            <div className="flex items-center gap-1">
              <Icon name="MessageCircle" size={14} />
              <span>{story?.comments}</span>
            </div>
          </div>
          <div className="flex items-center gap-1">
            <Icon name="Star" size={14} />
            <span>{story?.rating}</span>
          </div>
        </div>
        
        <div className="mt-3 pt-3 border-t border-border">
          <div className="text-xs text-muted-foreground">
            Last updated: {story?.lastUpdated}
          </div>
        </div>
      </div>
    </div>
  );

  const StoryListItem = ({ story }) => (
    <div className="bg-card rounded-lg border border-border p-4 hover:shadow-md transition-shadow">
      <div className="flex items-center gap-4">
        <div className="w-16 h-16 rounded-lg overflow-hidden flex-shrink-0">
          <Image
            src={story?.coverImage}
            alt={story?.title}
            className="w-full h-full object-cover"
          />
        </div>
        
        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between mb-1">
            <h3 className="font-semibold text-foreground truncate">{story?.title}</h3>
            <span className={`px-2 py-1 rounded-full text-xs font-medium ml-2 ${
              story?.status === 'published' ?'bg-success text-success-foreground'
                : story?.status === 'draft' ?'bg-warning text-warning-foreground' :'bg-muted text-muted-foreground'
            }`}>
              {story?.status}
            </span>
          </div>
          
          <p className="text-sm text-muted-foreground mb-2 line-clamp-1">
            {story?.description}
          </p>
          
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4 text-sm text-muted-foreground">
              <span>{story?.genre}</span>
              <span>{story?.chapters} chapters</span>
              <div className="flex items-center gap-3">
                <span>{story?.views} views</span>
                <span>{story?.likes} likes</span>
                <span>★ {story?.rating}</span>
              </div>
            </div>
            
            <div className="flex items-center gap-1">
              <Button variant="ghost" size="icon" onClick={() => onEditStory(story?.id)}>
                <Icon name="Edit" size={16} />
              </Button>
              <Button variant="ghost" size="icon" onClick={() => onDeleteStory(story?.id)}>
                <Icon name="Trash2" size={16} />
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="flex items-center gap-2">
          <Icon name="BookOpen" size={20} color="var(--color-primary)" />
          <h2 className="text-xl font-heading font-semibold text-foreground">My Stories</h2>
          <span className="bg-primary/10 text-primary px-2 py-1 rounded-full text-sm">
            {stories?.length}
          </span>
        </div>
        
        <div className="flex items-center gap-2">
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e?.target?.value)}
            className="px-3 py-2 bg-input border border-border rounded-md text-sm text-foreground"
          >
            <option value="recent">Most Recent</option>
            <option value="popular">Most Popular</option>
            <option value="title">Title A-Z</option>
          </select>
          
          <div className="flex items-center bg-muted rounded-lg p-1">
            <Button
              variant={viewMode === 'grid' ? 'default' : 'ghost'}
              size="icon"
              onClick={() => setViewMode('grid')}
            >
              <Icon name="Grid3X3" size={16} />
            </Button>
            <Button
              variant={viewMode === 'list' ? 'default' : 'ghost'}
              size="icon"
              onClick={() => setViewMode('list')}
            >
              <Icon name="List" size={16} />
            </Button>
          </div>
        </div>
      </div>
      {sortedStories?.length === 0 ? (
        <div className="text-center py-12">
          <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
            <Icon name="BookOpen" size={24} color="var(--color-muted-foreground)" />
          </div>
          <h3 className="text-lg font-semibold text-foreground mb-2">No stories yet</h3>
          <p className="text-muted-foreground mb-4">Start your storytelling journey by creating your first story.</p>
          <Button variant="default" iconName="Plus" iconPosition="left">
            Create New Story
          </Button>
        </div>
      ) : (
        <div className={
          viewMode === 'grid' ?'grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6' :'space-y-4'
        }>
          {sortedStories?.map((story) => (
            viewMode === 'grid' ? (
              <StoryCard key={story?.id} story={story} />
            ) : (
              <StoryListItem key={story?.id} story={story} />
            )
          ))}
        </div>
      )}
    </div>
  );
};

export default CreatedStories;