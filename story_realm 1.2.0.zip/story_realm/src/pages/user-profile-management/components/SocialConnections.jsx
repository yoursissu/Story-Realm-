import React, { useState } from 'react';
import Image from '../../../components/AppImage';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const SocialConnections = ({ followers, following, onFollow, onUnfollow }) => {
  const [activeTab, setActiveTab] = useState('followers');
  const [searchTerm, setSearchTerm] = useState('');

  const currentList = activeTab === 'followers' ? followers : following;
  const filteredList = currentList?.filter(user =>
    user?.displayName?.toLowerCase()?.includes(searchTerm?.toLowerCase()) ||
    user?.username?.toLowerCase()?.includes(searchTerm?.toLowerCase())
  );

  const UserCard = ({ user, showFollowButton = false }) => (
    <div className="bg-card rounded-lg border border-border p-4 hover:shadow-md transition-shadow">
      <div className="flex items-center gap-4">
        <div className="relative">
          <div className="w-12 h-12 rounded-full overflow-hidden">
            <Image
              src={user?.avatar}
              alt={user?.displayName}
              className="w-full h-full object-cover"
            />
          </div>
          {user?.isOnline && (
            <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-success rounded-full border-2 border-background" />
          )}
        </div>
        
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-1">
            <h3 className="font-semibold text-foreground truncate">{user?.displayName}</h3>
            {user?.isVerified && (
              <div className="bg-primary text-primary-foreground rounded-full p-0.5">
                <Icon name="CheckCircle" size={12} />
              </div>
            )}
          </div>
          <p className="text-sm text-muted-foreground truncate">@{user?.username}</p>
          <div className="flex items-center gap-4 mt-2 text-xs text-muted-foreground">
            <span>{user?.storiesCount} stories</span>
            <span>{user?.followersCount} followers</span>
            <span>Joined {user?.joinDate}</span>
          </div>
        </div>
        
        <div className="flex items-center gap-2">
          {showFollowButton && (
            <Button
              variant={user?.isFollowing ? 'outline' : 'default'}
              size="sm"
              onClick={() => user?.isFollowing ? onUnfollow(user?.id) : onFollow(user?.id)}
            >
              {user?.isFollowing ? 'Following' : 'Follow'}
            </Button>
          )}
          <Button variant="ghost" size="icon">
            <Icon name="MoreHorizontal" size={16} />
          </Button>
        </div>
      </div>
      
      {user?.bio && (
        <p className="text-sm text-muted-foreground mt-3 line-clamp-2">
          {user?.bio}
        </p>
      )}
      
      {user?.recentStory && (
        <div className="mt-3 pt-3 border-t border-border">
          <div className="flex items-center gap-2">
            <Icon name="BookOpen" size={14} color="var(--color-primary)" />
            <span className="text-sm text-foreground">Latest: </span>
            <span className="text-sm text-muted-foreground truncate">{user?.recentStory}</span>
          </div>
        </div>
      )}
    </div>
  );

  const tabs = [
    { 
      id: 'followers', 
      label: 'Followers', 
      count: followers?.length,
      icon: 'Users'
    },
    { 
      id: 'following', 
      label: 'Following', 
      count: following?.length,
      icon: 'UserPlus'
    }
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-2 mb-4">
        <Icon name="Users" size={20} color="var(--color-primary)" />
        <h2 className="text-xl font-heading font-semibold text-foreground">Social Connections</h2>
      </div>
      {/* Tab Navigation */}
      <div className="flex items-center justify-between">
        <div className="flex bg-muted rounded-lg p-1">
          {tabs?.map((tab) => (
            <Button
              key={tab?.id}
              variant={activeTab === tab?.id ? 'default' : 'ghost'}
              size="sm"
              onClick={() => setActiveTab(tab?.id)}
              className="flex items-center gap-2"
            >
              <Icon name={tab?.icon} size={16} />
              <span>{tab?.label}</span>
              <span className="bg-background/20 text-xs px-1.5 py-0.5 rounded-full">
                {tab?.count}
              </span>
            </Button>
          ))}
        </div>
        
        <Button variant="outline" size="sm" iconName="UserPlus" iconPosition="left">
          Find Friends
        </Button>
      </div>
      {/* Search */}
      <div className="relative">
        <Icon 
          name="Search" 
          size={16} 
          className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground" 
        />
        <input
          type="text"
          placeholder={`Search ${activeTab}...`}
          value={searchTerm}
          onChange={(e) => setSearchTerm(e?.target?.value)}
          className="w-full pl-10 pr-4 py-2 bg-input border border-border rounded-md text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring"
        />
      </div>
      {/* Connection Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-card rounded-lg border border-border p-4 text-center">
          <div className="text-2xl font-semibold text-primary mb-1">{followers?.length}</div>
          <div className="text-sm text-muted-foreground">Followers</div>
        </div>
        <div className="bg-card rounded-lg border border-border p-4 text-center">
          <div className="text-2xl font-semibold text-accent mb-1">{following?.length}</div>
          <div className="text-sm text-muted-foreground">Following</div>
        </div>
        <div className="bg-card rounded-lg border border-border p-4 text-center">
          <div className="text-2xl font-semibold text-success mb-1">
            {followers?.filter(f => f?.isOnline)?.length}
          </div>
          <div className="text-sm text-muted-foreground">Online Now</div>
        </div>
        <div className="bg-card rounded-lg border border-border p-4 text-center">
          <div className="text-2xl font-semibold text-warning mb-1">
            {following?.filter(f => f?.mutualFollowers > 0)?.length}
          </div>
          <div className="text-sm text-muted-foreground">Mutual</div>
        </div>
      </div>
      {/* User List */}
      {filteredList?.length === 0 ? (
        <div className="text-center py-12">
          <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
            <Icon name="Users" size={24} color="var(--color-muted-foreground)" />
          </div>
          <h3 className="text-lg font-semibold text-foreground mb-2">
            {searchTerm ? 'No matching users found' : `No ${activeTab} yet`}
          </h3>
          <p className="text-muted-foreground mb-4">
            {searchTerm 
              ? 'Try adjusting your search terms'
              : activeTab === 'followers' ?'Share your stories to attract followers' :'Discover and follow other writers in the community'
            }
          </p>
          {!searchTerm && (
            <Button variant="default" iconName="UserPlus" iconPosition="left">
              {activeTab === 'followers' ? 'Share Stories' : 'Find Writers'}
            </Button>
          )}
        </div>
      ) : (
        <div className="space-y-4">
          {filteredList?.map((user) => (
            <UserCard 
              key={user?.id} 
              user={user} 
              showFollowButton={activeTab === 'followers'}
            />
          ))}
        </div>
      )}
      {/* Suggested Connections */}
      {activeTab === 'following' && (
        <div className="bg-card rounded-lg border border-border p-6">
          <h3 className="text-lg font-semibold text-foreground mb-4">Suggested for You</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {[
              {
                id: 'suggested-1',
                displayName: 'Sarah Chen',
                username: 'sarahwrites',
                avatar: 'https://images.unsplash.com/photo-1494790108755-2616b612b786?w=150',
                bio: 'Fantasy writer with a passion for world-building',
                storiesCount: 12,
                followersCount: 1250,
                mutualFollowers: 3,
                isVerified: true
              },
              {
                id: 'suggested-2',
                displayName: 'Marcus Johnson',
                username: 'marcusj',
                avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150',
                bio: 'Sci-fi enthusiast and tech blogger',
                storiesCount: 8,
                followersCount: 890,
                mutualFollowers: 2,
                isVerified: false
              }
            ]?.map((user) => (
              <div key={user?.id} className="flex items-center gap-3 p-3 bg-muted rounded-lg">
                <div className="w-10 h-10 rounded-full overflow-hidden">
                  <Image
                    src={user?.avatar}
                    alt={user?.displayName}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-1">
                    <span className="font-medium text-foreground text-sm">{user?.displayName}</span>
                    {user?.isVerified && (
                      <Icon name="CheckCircle" size={12} color="var(--color-primary)" />
                    )}
                  </div>
                  <p className="text-xs text-muted-foreground">{user?.mutualFollowers} mutual followers</p>
                </div>
                <Button variant="outline" size="sm">
                  Follow
                </Button>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default SocialConnections;