import React, { useState } from 'react';
import Image from '../../../components/AppImage';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';

const ProfileHeader = ({ user, onUpdateProfile }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [editData, setEditData] = useState({
    displayName: user?.displayName,
    bio: user?.bio,
    location: user?.location
  });

  const handleSave = () => {
    onUpdateProfile(editData);
    setIsEditing(false);
  };

  const handleCancel = () => {
    setEditData({
      displayName: user?.displayName,
      bio: user?.bio,
      location: user?.location
    });
    setIsEditing(false);
  };

  return (
    <div className="bg-card rounded-lg border border-border p-6 mb-6">
      <div className="flex flex-col md:flex-row items-start md:items-center gap-6">
        {/* Avatar Section */}
        <div className="relative">
          <div className="w-24 h-24 md:w-32 md:h-32 rounded-full overflow-hidden border-4 border-primary">
            <Image
              src={user?.avatar}
              alt={user?.displayName}
              className="w-full h-full object-cover"
            />
          </div>
          <Button
            variant="outline"
            size="icon"
            className="absolute -bottom-2 -right-2 rounded-full bg-background"
          >
            <Icon name="Camera" size={16} />
          </Button>
        </div>

        {/* Profile Info */}
        <div className="flex-1 min-w-0">
          {isEditing ? (
            <div className="space-y-4">
              <Input
                label="Display Name"
                value={editData?.displayName}
                onChange={(e) => setEditData({ ...editData, displayName: e?.target?.value })}
                className="max-w-md"
              />
              <Input
                label="Bio"
                value={editData?.bio}
                onChange={(e) => setEditData({ ...editData, bio: e?.target?.value })}
                className="max-w-lg"
              />
              <Input
                label="Location"
                value={editData?.location}
                onChange={(e) => setEditData({ ...editData, location: e?.target?.value })}
                className="max-w-sm"
              />
              <div className="flex gap-2">
                <Button variant="default" onClick={handleSave}>
                  Save Changes
                </Button>
                <Button variant="outline" onClick={handleCancel}>
                  Cancel
                </Button>
              </div>
            </div>
          ) : (
            <div>
              <div className="flex items-center gap-3 mb-2">
                <h1 className="text-2xl md:text-3xl font-heading font-semibold text-foreground">
                  {user?.displayName}
                </h1>
                {user?.isVerified && (
                  <div className="bg-primary text-primary-foreground rounded-full p-1">
                    <Icon name="CheckCircle" size={16} />
                  </div>
                )}
              </div>
              <p className="text-muted-foreground mb-3 leading-relaxed">
                {user?.bio}
              </p>
              <div className="flex flex-wrap items-center gap-4 text-sm text-muted-foreground">
                <div className="flex items-center gap-1">
                  <Icon name="MapPin" size={14} />
                  <span>{user?.location}</span>
                </div>
                <div className="flex items-center gap-1">
                  <Icon name="Calendar" size={14} />
                  <span>Joined {user?.joinDate}</span>
                </div>
                <div className="flex items-center gap-1">
                  <Icon name="BookOpen" size={14} />
                  <span>{user?.storiesCount} stories</span>
                </div>
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setIsEditing(true)}
                className="mt-4"
                iconName="Edit"
                iconPosition="left"
              >
                Edit Profile
              </Button>
            </div>
          )}
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-3 gap-4 md:gap-6">
          <div className="text-center">
            <div className="text-2xl font-semibold text-foreground">{user?.followersCount}</div>
            <div className="text-sm text-muted-foreground">Followers</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-semibold text-foreground">{user?.followingCount}</div>
            <div className="text-sm text-muted-foreground">Following</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-semibold text-foreground">{user?.totalReads}</div>
            <div className="text-sm text-muted-foreground">Total Reads</div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProfileHeader;