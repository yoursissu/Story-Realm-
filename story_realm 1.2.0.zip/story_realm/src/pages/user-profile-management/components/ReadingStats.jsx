import React from 'react';
import Icon from '../../../components/AppIcon';

const ReadingStats = ({ stats }) => {
  const StatCard = ({ icon, label, value, color = "text-foreground" }) => (
    <div className="bg-card rounded-lg border border-border p-4">
      <div className="flex items-center gap-3 mb-2">
        <div className={`p-2 rounded-lg bg-${color?.replace('text-', '')}/10`}>
          <Icon name={icon} size={20} color={`var(--color-${color?.replace('text-', '')})`} />
        </div>
        <div>
          <div className={`text-2xl font-semibold ${color}`}>{value}</div>
          <div className="text-sm text-muted-foreground">{label}</div>
        </div>
      </div>
    </div>
  );

  const ProgressBar = ({ label, current, total, color = "primary" }) => {
    const percentage = Math.min((current / total) * 100, 100);
    
    return (
      <div className="space-y-2">
        <div className="flex justify-between text-sm">
          <span className="text-foreground">{label}</span>
          <span className="text-muted-foreground">{current}/{total}</span>
        </div>
        <div className="w-full bg-muted rounded-full h-2">
          <div
            className={`bg-${color} h-2 rounded-full transition-all duration-300`}
            style={{ width: `${percentage}%` }}
          />
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-2 mb-4">
        <Icon name="BarChart3" size={20} color="var(--color-primary)" />
        <h2 className="text-xl font-heading font-semibold text-foreground">Reading Statistics</h2>
      </div>
      {/* Quick Stats Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <StatCard
          icon="BookOpen"
          label="Stories Read"
          value={stats?.storiesRead}
          color="text-primary"
        />
        <StatCard
          icon="Clock"
          label="Reading Hours"
          value={`${stats?.readingHours}h`}
          color="text-accent"
        />
        <StatCard
          icon="Flame"
          label="Current Streak"
          value={`${stats?.currentStreak} days`}
          color="text-warning"
        />
        <StatCard
          icon="Trophy"
          label="Best Streak"
          value={`${stats?.bestStreak} days`}
          color="text-success"
        />
      </div>
      {/* Reading Goals */}
      <div className="bg-card rounded-lg border border-border p-6">
        <h3 className="text-lg font-semibold text-foreground mb-4">Reading Goals</h3>
        <div className="space-y-4">
          <ProgressBar
            label="Monthly Reading Goal"
            current={stats?.monthlyProgress?.current}
            total={stats?.monthlyProgress?.target}
            color="primary"
          />
          <ProgressBar
            label="Yearly Reading Goal"
            current={stats?.yearlyProgress?.current}
            total={stats?.yearlyProgress?.target}
            color="accent"
          />
        </div>
      </div>
      {/* Favorite Genres */}
      <div className="bg-card rounded-lg border border-border p-6">
        <h3 className="text-lg font-semibold text-foreground mb-4">Favorite Genres</h3>
        <div className="space-y-3">
          {stats?.favoriteGenres?.map((genre, index) => (
            <div key={genre?.name} className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className={`w-3 h-3 rounded-full bg-${index === 0 ? 'primary' : index === 1 ? 'accent' : 'secondary'}`} />
                <span className="text-foreground">{genre?.name}</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="text-sm text-muted-foreground">{genre?.count} stories</div>
                <div className="text-sm font-medium text-foreground">{genre?.percentage}%</div>
              </div>
            </div>
          ))}
        </div>
      </div>
      {/* Reading Activity */}
      <div className="bg-card rounded-lg border border-border p-6">
        <h3 className="text-lg font-semibold text-foreground mb-4">Recent Activity</h3>
        <div className="space-y-3">
          {stats?.recentActivity?.map((activity, index) => (
            <div key={index} className="flex items-center gap-3 p-3 bg-muted rounded-lg">
              <div className="p-2 bg-primary/10 rounded-lg">
                <Icon name={activity?.icon} size={16} color="var(--color-primary)" />
              </div>
              <div className="flex-1">
                <div className="text-sm text-foreground">{activity?.action}</div>
                <div className="text-xs text-muted-foreground">{activity?.time}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default ReadingStats;