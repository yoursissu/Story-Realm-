import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const AchievementsBadges = ({ achievements, badges }) => {
  const [activeTab, setActiveTab] = useState('achievements');
  const [filter, setFilter] = useState('all'); // 'all', 'earned', 'locked'

  const filteredItems = (activeTab === 'achievements' ? achievements : badges)?.filter(item => {
    if (filter === 'earned') return item?.earned;
    if (filter === 'locked') return !item?.earned;
    return true;
  });

  const getBadgeColor = (rarity) => {
    switch (rarity) {
      case 'legendary':
        return 'from-yellow-400 to-orange-500';
      case 'epic':
        return 'from-purple-400 to-pink-500';
      case 'rare':
        return 'from-blue-400 to-cyan-500';
      case 'common':
      default:
        return 'from-gray-400 to-gray-600';
    }
  };

  const getProgressColor = (progress) => {
    if (progress >= 100) return 'bg-success';
    if (progress >= 75) return 'bg-warning';
    if (progress >= 50) return 'bg-primary';
    return 'bg-muted-foreground';
  };

  const AchievementCard = ({ item }) => (
    <div className={`bg-card rounded-lg border border-border p-4 transition-all duration-300 ${
      item?.earned ? 'hover:shadow-lg' : 'opacity-60'
    }`}>
      <div className="flex items-start gap-4">
        <div className={`w-16 h-16 rounded-full flex items-center justify-center ${
          item?.earned 
            ? `bg-gradient-to-br ${getBadgeColor(item?.rarity)} text-white`
            : 'bg-muted text-muted-foreground'
        }`}>
          <Icon name={item?.icon} size={24} />
        </div>
        
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-1">
            <h3 className={`font-semibold ${item?.earned ? 'text-foreground' : 'text-muted-foreground'}`}>
              {item?.title}
            </h3>
            {item?.earned && item?.rarity === 'legendary' && (
              <div className="bg-gradient-to-r from-yellow-400 to-orange-500 text-white px-2 py-0.5 rounded-full text-xs font-medium">
                Legendary
              </div>
            )}
          </div>
          
          <p className="text-sm text-muted-foreground mb-3 line-clamp-2">
            {item?.description}
          </p>
          
          {!item?.earned && item?.progress !== undefined && (
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Progress</span>
                <span className="text-foreground">{item?.current}/{item?.target}</span>
              </div>
              <div className="w-full bg-muted rounded-full h-2">
                <div
                  className={`h-2 rounded-full transition-all duration-300 ${getProgressColor(item?.progress)}`}
                  style={{ width: `${Math.min(item?.progress, 100)}%` }}
                />
              </div>
            </div>
          )}
          
          {item?.earned && (
            <div className="flex items-center gap-4 text-sm text-muted-foreground">
              <div className="flex items-center gap-1">
                <Icon name="Calendar" size={14} />
                <span>Earned {item?.earnedDate}</span>
              </div>
              {item?.points && (
                <div className="flex items-center gap-1">
                  <Icon name="Star" size={14} />
                  <span>{item?.points} points</span>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );

  const StatCard = ({ icon, label, value, color = "text-foreground" }) => (
    <div className="bg-card rounded-lg border border-border p-4 text-center">
      <div className={`w-12 h-12 rounded-full bg-${color?.replace('text-', '')}/10 flex items-center justify-center mx-auto mb-2`}>
        <Icon name={icon} size={20} color={`var(--color-${color?.replace('text-', '')})`} />
      </div>
      <div className={`text-2xl font-semibold ${color} mb-1`}>{value}</div>
      <div className="text-sm text-muted-foreground">{label}</div>
    </div>
  );

  const tabs = [
    { 
      id: 'achievements', 
      label: 'Achievements', 
      count: achievements?.length,
      icon: 'Trophy'
    },
    { 
      id: 'badges', 
      label: 'Badges', 
      count: badges?.length,
      icon: 'Award'
    }
  ];

  const filterOptions = [
    { value: 'all', label: 'All' },
    { value: 'earned', label: 'Earned' },
    { value: 'locked', label: 'Locked' }
  ];

  const earnedCount = (activeTab === 'achievements' ? achievements : badges)?.filter(item => item?.earned)?.length;
  const totalCount = (activeTab === 'achievements' ? achievements : badges)?.length;
  const completionPercentage = Math.round((earnedCount / totalCount) * 100);

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-2 mb-4">
        <Icon name="Trophy" size={20} color="var(--color-primary)" />
        <h2 className="text-xl font-heading font-semibold text-foreground">Achievements & Badges</h2>
      </div>
      {/* Stats Overview */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <StatCard
          icon="Trophy"
          label="Achievements"
          value={achievements?.filter(a => a?.earned)?.length}
          color="text-primary"
        />
        <StatCard
          icon="Award"
          label="Badges"
          value={badges?.filter(b => b?.earned)?.length}
          color="text-accent"
        />
        <StatCard
          icon="Star"
          label="Total Points"
          value={[...achievements, ...badges]?.filter(item => item?.earned)?.reduce((sum, item) => sum + (item?.points || 0), 0)}
          color="text-warning"
        />
        <StatCard
          icon="Target"
          label="Completion"
          value={`${completionPercentage}%`}
          color="text-success"
        />
      </div>
      {/* Tab Navigation and Filters */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="flex bg-muted rounded-lg p-1">
          {tabs?.map((tab) => (
            <Button
              key={tab?.id}
              variant={activeTab === tab?.id ? 'default' : 'ghost'}
              size="sm"
              onClick={() => setActiveTab(tab?.id)}
              className="flex items-center gap-2"
            >
              <Icon name={tab?.icon} size={16} />
              <span>{tab?.label}</span>
              <span className="bg-background/20 text-xs px-1.5 py-0.5 rounded-full">
                {tab?.count}
              </span>
            </Button>
          ))}
        </div>
        
        <div className="flex gap-2">
          {filterOptions?.map((option) => (
            <Button
              key={option?.value}
              variant={filter === option?.value ? 'default' : 'outline'}
              size="sm"
              onClick={() => setFilter(option?.value)}
            >
              {option?.label}
            </Button>
          ))}
        </div>
      </div>
      {/* Progress Overview */}
      <div className="bg-card rounded-lg border border-border p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-foreground">
            {activeTab === 'achievements' ? 'Achievement' : 'Badge'} Progress
          </h3>
          <span className="text-sm text-muted-foreground">
            {earnedCount} of {totalCount} earned
          </span>
        </div>
        <div className="w-full bg-muted rounded-full h-3 mb-2">
          <div
            className="bg-gradient-to-r from-primary to-accent h-3 rounded-full transition-all duration-500"
            style={{ width: `${completionPercentage}%` }}
          />
        </div>
        <div className="text-sm text-muted-foreground">
          {completionPercentage}% complete
        </div>
      </div>
      {/* Items Grid */}
      {filteredItems?.length === 0 ? (
        <div className="text-center py-12">
          <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
            <Icon name={activeTab === 'achievements' ? 'Trophy' : 'Award'} size={24} color="var(--color-muted-foreground)" />
          </div>
          <h3 className="text-lg font-semibold text-foreground mb-2">
            No {filter === 'all' ? '' : filter} {activeTab} found
          </h3>
          <p className="text-muted-foreground mb-4">
            {filter === 'earned' ? `You haven't earned any ${activeTab} yet. Keep writing and reading to unlock them!`
              : filter === 'locked'
              ? `All ${activeTab} are unlocked! Great job!`
              : `No ${activeTab} available at the moment.`
            }
          </p>
          {filter !== 'all' && (
            <Button variant="outline" onClick={() => setFilter('all')}>
              View All {activeTab}
            </Button>
          )}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {filteredItems?.map((item) => (
            <AchievementCard key={item?.id} item={item} />
          ))}
        </div>
      )}
      {/* Recent Achievements */}
      {activeTab === 'achievements' && (
        <div className="bg-card rounded-lg border border-border p-6">
          <h3 className="text-lg font-semibold text-foreground mb-4">Recent Achievements</h3>
          <div className="space-y-3">
            {achievements?.filter(a => a?.earned)?.sort((a, b) => new Date(b.earnedDate) - new Date(a.earnedDate))?.slice(0, 3)?.map((achievement) => (
                <div key={achievement?.id} className="flex items-center gap-3 p-3 bg-muted rounded-lg">
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center bg-gradient-to-br ${getBadgeColor(achievement?.rarity)} text-white`}>
                    <Icon name={achievement?.icon} size={16} />
                  </div>
                  <div className="flex-1">
                    <div className="font-medium text-foreground">{achievement?.title}</div>
                    <div className="text-sm text-muted-foreground">Earned {achievement?.earnedDate}</div>
                  </div>
                  {achievement?.points && (
                    <div className="text-sm font-medium text-warning">+{achievement?.points} pts</div>
                  )}
                </div>
              ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default AchievementsBadges;