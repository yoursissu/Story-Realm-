import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import { Checkbox } from '../../../components/ui/Checkbox';

const AccountSettings = ({ settings, onUpdateSettings }) => {
  const [activeSection, setActiveSection] = useState('profile');
  const [formData, setFormData] = useState(settings);
  const [showPasswordForm, setShowPasswordForm] = useState(false);
  const [passwordData, setPasswordData] = useState({
    currentPassword: '',
    newPassword: '',
    confirmPassword: ''
  });

  const handleSave = (section) => {
    onUpdateSettings(section, formData?.[section]);
  };

  const handlePasswordChange = () => {
    // Mock password change logic
    if (passwordData?.newPassword === passwordData?.confirmPassword) {
      alert('Password updated successfully!');
      setPasswordData({ currentPassword: '', newPassword: '', confirmPassword: '' });
      setShowPasswordForm(false);
    } else {
      alert('Passwords do not match!');
    }
  };

  const sections = [
    { id: 'profile', label: 'Profile Settings', icon: 'User' },
    { id: 'privacy', label: 'Privacy & Security', icon: 'Shield' },
    { id: 'notifications', label: 'Notifications', icon: 'Bell' },
    { id: 'preferences', label: 'Reading Preferences', icon: 'Settings' },
    { id: 'account', label: 'Account Management', icon: 'UserCog' }
  ];

  const ProfileSettings = () => (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-semibold text-foreground mb-4">Profile Information</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Input
            label="Display Name"
            value={formData?.profile?.displayName}
            onChange={(e) => setFormData({
              ...formData,
              profile: { ...formData?.profile, displayName: e?.target?.value }
            })}
          />
          <Input
            label="Username"
            value={formData?.profile?.username}
            onChange={(e) => setFormData({
              ...formData,
              profile: { ...formData?.profile, username: e?.target?.value }
            })}
          />
          <Input
            label="Email Address"
            type="email"
            value={formData?.profile?.email}
            onChange={(e) => setFormData({
              ...formData,
              profile: { ...formData?.profile, email: e?.target?.value }
            })}
          />
          <Input
            label="Location"
            value={formData?.profile?.location}
            onChange={(e) => setFormData({
              ...formData,
              profile: { ...formData?.profile, location: e?.target?.value }
            })}
          />
        </div>
        <div className="mt-4">
          <label className="block text-sm font-medium text-foreground mb-2">Bio</label>
          <textarea
            value={formData?.profile?.bio}
            onChange={(e) => setFormData({
              ...formData,
              profile: { ...formData?.profile, bio: e?.target?.value }
            })}
            rows={4}
            className="w-full px-3 py-2 bg-input border border-border rounded-md text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring"
            placeholder="Tell us about yourself..."
          />
        </div>
        <Button 
          variant="default" 
          onClick={() => handleSave('profile')}
          className="mt-4"
        >
          Save Profile Changes
        </Button>
      </div>
    </div>
  );

  const PrivacySettings = () => (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-semibold text-foreground mb-4">Privacy Controls</h3>
        <div className="space-y-4">
          <Checkbox
            label="Make my profile public"
            description="Allow others to find and view your profile"
            checked={formData?.privacy?.publicProfile}
            onChange={(e) => setFormData({
              ...formData,
              privacy: { ...formData?.privacy, publicProfile: e?.target?.checked }
            })}
          />
          <Checkbox
            label="Show my reading activity"
            description="Display your reading history to followers"
            checked={formData?.privacy?.showReadingActivity}
            onChange={(e) => setFormData({
              ...formData,
              privacy: { ...formData?.privacy, showReadingActivity: e?.target?.checked }
            })}
          />
          <Checkbox
            label="Allow story recommendations"
            description="Let others recommend stories to you"
            checked={formData?.privacy?.allowRecommendations}
            onChange={(e) => setFormData({
              ...formData,
              privacy: { ...formData?.privacy, allowRecommendations: e?.target?.checked }
            })}
          />
        </div>
      </div>

      <div>
        <h3 className="text-lg font-semibold text-foreground mb-4">Security Settings</h3>
        <div className="space-y-4">
          <div className="flex items-center justify-between p-4 bg-card border border-border rounded-lg">
            <div>
              <div className="font-medium text-foreground">Password</div>
              <div className="text-sm text-muted-foreground">Last changed 3 months ago</div>
            </div>
            <Button 
              variant="outline" 
              onClick={() => setShowPasswordForm(!showPasswordForm)}
            >
              Change Password
            </Button>
          </div>

          {showPasswordForm && (
            <div className="bg-muted p-4 rounded-lg space-y-4">
              <Input
                label="Current Password"
                type="password"
                value={passwordData?.currentPassword}
                onChange={(e) => setPasswordData({
                  ...passwordData,
                  currentPassword: e?.target?.value
                })}
              />
              <Input
                label="New Password"
                type="password"
                value={passwordData?.newPassword}
                onChange={(e) => setPasswordData({
                  ...passwordData,
                  newPassword: e?.target?.value
                })}
              />
              <Input
                label="Confirm New Password"
                type="password"
                value={passwordData?.confirmPassword}
                onChange={(e) => setPasswordData({
                  ...passwordData,
                  confirmPassword: e?.target?.value
                })}
              />
              <div className="flex gap-2">
                <Button variant="default" onClick={handlePasswordChange}>
                  Update Password
                </Button>
                <Button variant="outline" onClick={() => setShowPasswordForm(false)}>
                  Cancel
                </Button>
              </div>
            </div>
          )}

          <div className="flex items-center justify-between p-4 bg-card border border-border rounded-lg">
            <div>
              <div className="font-medium text-foreground">Two-Factor Authentication</div>
              <div className="text-sm text-muted-foreground">
                {formData?.privacy?.twoFactorEnabled ? 'Enabled' : 'Not enabled'}
              </div>
            </div>
            <Button 
              variant={formData?.privacy?.twoFactorEnabled ? 'outline' : 'default'}
              onClick={() => setFormData({
                ...formData,
                privacy: { ...formData?.privacy, twoFactorEnabled: !formData?.privacy?.twoFactorEnabled }
              })}
            >
              {formData?.privacy?.twoFactorEnabled ? 'Disable' : 'Enable'}
            </Button>
          </div>
        </div>
        <Button 
          variant="default" 
          onClick={() => handleSave('privacy')}
          className="mt-4"
        >
          Save Privacy Settings
        </Button>
      </div>
    </div>
  );

  const NotificationSettings = () => (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-semibold text-foreground mb-4">Email Notifications</h3>
        <div className="space-y-4">
          <Checkbox
            label="New follower notifications"
            description="Get notified when someone follows you"
            checked={formData?.notifications?.newFollower}
            onChange={(e) => setFormData({
              ...formData,
              notifications: { ...formData?.notifications, newFollower: e?.target?.checked }
            })}
          />
          <Checkbox
            label="Story comments"
            description="Get notified when someone comments on your stories"
            checked={formData?.notifications?.storyComments}
            onChange={(e) => setFormData({
              ...formData,
              notifications: { ...formData?.notifications, storyComments: e?.target?.checked }
            })}
          />
          <Checkbox
            label="Story likes and ratings"
            description="Get notified when someone likes or rates your stories"
            checked={formData?.notifications?.storyLikes}
            onChange={(e) => setFormData({
              ...formData,
              notifications: { ...formData?.notifications, storyLikes: e?.target?.checked }
            })}
          />
          <Checkbox
            label="Weekly digest"
            description="Receive a weekly summary of your activity"
            checked={formData?.notifications?.weeklyDigest}
            onChange={(e) => setFormData({
              ...formData,
              notifications: { ...formData?.notifications, weeklyDigest: e?.target?.checked }
            })}
          />
        </div>
      </div>

      <div>
        <h3 className="text-lg font-semibold text-foreground mb-4">Push Notifications</h3>
        <div className="space-y-4">
          <Checkbox
            label="Real-time messages"
            description="Get instant notifications for direct messages"
            checked={formData?.notifications?.pushMessages}
            onChange={(e) => setFormData({
              ...formData,
              notifications: { ...formData?.notifications, pushMessages: e?.target?.checked }
            })}
          />
          <Checkbox
            label="Story updates"
            description="Get notified when followed authors publish new chapters"
            checked={formData?.notifications?.storyUpdates}
            onChange={(e) => setFormData({
              ...formData,
              notifications: { ...formData?.notifications, storyUpdates: e?.target?.checked }
            })}
          />
        </div>
        <Button 
          variant="default" 
          onClick={() => handleSave('notifications')}
          className="mt-4"
        >
          Save Notification Settings
        </Button>
      </div>
    </div>
  );

  const ReadingPreferences = () => (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-semibold text-foreground mb-4">Content Preferences</h3>
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-foreground mb-2">Preferred Genres</label>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
              {['Fantasy', 'Romance', 'Mystery', 'Sci-Fi', 'Horror', 'Drama']?.map((genre) => (
                <Checkbox
                  key={genre}
                  label={genre}
                  checked={formData?.preferences?.preferredGenres?.includes(genre)}
                  onChange={(e) => {
                    const genres = formData?.preferences?.preferredGenres;
                    const updatedGenres = e?.target?.checked
                      ? [...genres, genre]
                      : genres?.filter(g => g !== genre);
                    setFormData({
                      ...formData,
                      preferences: { ...formData?.preferences, preferredGenres: updatedGenres }
                    });
                  }}
                />
              ))}
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-foreground mb-2">Content Rating</label>
            <select
              value={formData?.preferences?.contentRating}
              onChange={(e) => setFormData({
                ...formData,
                preferences: { ...formData?.preferences, contentRating: e?.target?.value }
              })}
              className="w-full px-3 py-2 bg-input border border-border rounded-md text-foreground"
            >
              <option value="all">All Content</option>
              <option value="teen">Teen and Above</option>
              <option value="mature">Mature Content Only</option>
            </select>
          </div>

          <Checkbox
            label="Auto-bookmark reading progress"
            description="Automatically save your reading position"
            checked={formData?.preferences?.autoBookmark}
            onChange={(e) => setFormData({
              ...formData,
              preferences: { ...formData?.preferences, autoBookmark: e?.target?.checked }
            })}
          />
        </div>
        <Button 
          variant="default" 
          onClick={() => handleSave('preferences')}
          className="mt-4"
        >
          Save Reading Preferences
        </Button>
      </div>
    </div>
  );

  const AccountManagement = () => (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-semibold text-foreground mb-4">Data Management</h3>
        <div className="space-y-4">
          <div className="flex items-center justify-between p-4 bg-card border border-border rounded-lg">
            <div>
              <div className="font-medium text-foreground">Export Data</div>
              <div className="text-sm text-muted-foreground">Download all your stories and reading data</div>
            </div>
            <Button variant="outline" iconName="Download" iconPosition="left">
              Export
            </Button>
          </div>

          <div className="flex items-center justify-between p-4 bg-card border border-border rounded-lg">
            <div>
              <div className="font-medium text-foreground">Account Backup</div>
              <div className="text-sm text-muted-foreground">Create a backup of your account settings</div>
            </div>
            <Button variant="outline" iconName="Archive" iconPosition="left">
              Backup
            </Button>
          </div>
        </div>
      </div>

      <div>
        <h3 className="text-lg font-semibold text-error mb-4">Danger Zone</h3>
        <div className="space-y-4">
          <div className="flex items-center justify-between p-4 bg-error/5 border border-error/20 rounded-lg">
            <div>
              <div className="font-medium text-error">Deactivate Account</div>
              <div className="text-sm text-muted-foreground">Temporarily disable your account</div>
            </div>
            <Button variant="outline" className="border-error text-error hover:bg-error hover:text-error-foreground">
              Deactivate
            </Button>
          </div>

          <div className="flex items-center justify-between p-4 bg-error/5 border border-error/20 rounded-lg">
            <div>
              <div className="font-medium text-error">Delete Account</div>
              <div className="text-sm text-muted-foreground">Permanently delete your account and all data</div>
            </div>
            <Button variant="destructive">
              Delete Account
            </Button>
          </div>
        </div>
      </div>
    </div>
  );

  const renderSection = () => {
    switch (activeSection) {
      case 'profile':
        return <ProfileSettings />;
      case 'privacy':
        return <PrivacySettings />;
      case 'notifications':
        return <NotificationSettings />;
      case 'preferences':
        return <ReadingPreferences />;
      case 'account':
        return <AccountManagement />;
      default:
        return <ProfileSettings />;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-2 mb-4">
        <Icon name="Settings" size={20} color="var(--color-primary)" />
        <h2 className="text-xl font-heading font-semibold text-foreground">Account Settings</h2>
      </div>
      <div className="flex flex-col lg:flex-row gap-6">
        {/* Settings Navigation */}
        <div className="lg:w-64 flex-shrink-0">
          <div className="bg-card rounded-lg border border-border p-2">
            {sections?.map((section) => (
              <Button
                key={section?.id}
                variant={activeSection === section?.id ? 'default' : 'ghost'}
                onClick={() => setActiveSection(section?.id)}
                className="w-full justify-start mb-1"
                iconName={section?.icon}
                iconPosition="left"
              >
                {section?.label}
              </Button>
            ))}
          </div>
        </div>

        {/* Settings Content */}
        <div className="flex-1">
          <div className="bg-card rounded-lg border border-border p-6">
            {renderSection()}
          </div>
        </div>
      </div>
    </div>
  );
};

export default AccountSettings;