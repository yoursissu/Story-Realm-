import React, { useState } from 'react';
import Image from '../../../components/AppImage';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const ReadingHistory = ({ history }) => {
  const [filter, setFilter] = useState('all'); // 'all', 'completed', 'reading', 'bookmarked'
  const [searchTerm, setSearchTerm] = useState('');

  const filteredHistory = history?.filter(item => {
    const matchesFilter = filter === 'all' || item?.status === filter;
    const matchesSearch = item?.title?.toLowerCase()?.includes(searchTerm?.toLowerCase()) ||
                         item?.author?.toLowerCase()?.includes(searchTerm?.toLowerCase());
    return matchesFilter && matchesSearch;
  });

  const getStatusColor = (status) => {
    switch (status) {
      case 'completed':
        return 'bg-success text-success-foreground';
      case 'reading':
        return 'bg-primary text-primary-foreground';
      case 'bookmarked':
        return 'bg-warning text-warning-foreground';
      default:
        return 'bg-muted text-muted-foreground';
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'completed':
        return 'CheckCircle';
      case 'reading':
        return 'BookOpen';
      case 'bookmarked':
        return 'Bookmark';
      default:
        return 'Clock';
    }
  };

  const HistoryItem = ({ item }) => (
    <div className="bg-card rounded-lg border border-border p-4 hover:shadow-md transition-shadow">
      <div className="flex items-start gap-4">
        <div className="w-16 h-20 rounded-lg overflow-hidden flex-shrink-0">
          <Image
            src={item?.coverImage}
            alt={item?.title}
            className="w-full h-full object-cover"
          />
        </div>
        
        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between mb-2">
            <div>
              <h3 className="font-semibold text-foreground line-clamp-1">{item?.title}</h3>
              <p className="text-sm text-muted-foreground">by {item?.author}</p>
            </div>
            <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(item?.status)}`}>
              {item?.status}
            </span>
          </div>
          
          <div className="flex items-center gap-4 mb-3 text-sm text-muted-foreground">
            <div className="flex items-center gap-1">
              <Icon name="Tag" size={14} />
              <span>{item?.genre}</span>
            </div>
            <div className="flex items-center gap-1">
              <Icon name="Clock" size={14} />
              <span>{item?.readingTime}</span>
            </div>
            <div className="flex items-center gap-1">
              <Icon name="Star" size={14} />
              <span>{item?.rating}</span>
            </div>
          </div>
          
          {item?.status === 'reading' && (
            <div className="mb-3">
              <div className="flex justify-between text-sm mb-1">
                <span className="text-foreground">Progress</span>
                <span className="text-muted-foreground">{item?.progress}%</span>
              </div>
              <div className="w-full bg-muted rounded-full h-2">
                <div
                  className="bg-primary h-2 rounded-full transition-all duration-300"
                  style={{ width: `${item?.progress}%` }}
                />
              </div>
            </div>
          )}
          
          <div className="flex items-center justify-between">
            <div className="text-xs text-muted-foreground">
              {item?.status === 'completed' ? 'Completed' : 'Last read'}: {item?.lastRead}
            </div>
            <div className="flex items-center gap-1">
              <Button variant="ghost" size="icon">
                <Icon name="MoreHorizontal" size={16} />
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  const filterOptions = [
    { value: 'all', label: 'All Stories', count: history?.length },
    { value: 'reading', label: 'Currently Reading', count: history?.filter(h => h?.status === 'reading')?.length },
    { value: 'completed', label: 'Completed', count: history?.filter(h => h?.status === 'completed')?.length },
    { value: 'bookmarked', label: 'Bookmarked', count: history?.filter(h => h?.status === 'bookmarked')?.length }
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-2 mb-4">
        <Icon name="History" size={20} color="var(--color-primary)" />
        <h2 className="text-xl font-heading font-semibold text-foreground">Reading History</h2>
      </div>
      {/* Search and Filter */}
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Icon 
            name="Search" 
            size={16} 
            className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground" 
          />
          <input
            type="text"
            placeholder="Search stories or authors..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e?.target?.value)}
            className="w-full pl-10 pr-4 py-2 bg-input border border-border rounded-md text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring"
          />
        </div>
        
        <div className="flex gap-2 overflow-x-auto">
          {filterOptions?.map((option) => (
            <Button
              key={option?.value}
              variant={filter === option?.value ? 'default' : 'outline'}
              size="sm"
              onClick={() => setFilter(option?.value)}
              className="whitespace-nowrap"
            >
              {option?.label} ({option?.count})
            </Button>
          ))}
        </div>
      </div>
      {/* Reading Statistics */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-card rounded-lg border border-border p-4 text-center">
          <div className="text-2xl font-semibold text-primary mb-1">
            {history?.filter(h => h?.status === 'completed')?.length}
          </div>
          <div className="text-sm text-muted-foreground">Completed</div>
        </div>
        <div className="bg-card rounded-lg border border-border p-4 text-center">
          <div className="text-2xl font-semibold text-accent mb-1">
            {history?.filter(h => h?.status === 'reading')?.length}
          </div>
          <div className="text-sm text-muted-foreground">Reading</div>
        </div>
        <div className="bg-card rounded-lg border border-border p-4 text-center">
          <div className="text-2xl font-semibold text-warning mb-1">
            {history?.filter(h => h?.status === 'bookmarked')?.length}
          </div>
          <div className="text-sm text-muted-foreground">Bookmarked</div>
        </div>
        <div className="bg-card rounded-lg border border-border p-4 text-center">
          <div className="text-2xl font-semibold text-success mb-1">
            {Math.round(history?.reduce((acc, h) => acc + (h?.rating || 0), 0) / history?.length * 10) / 10}
          </div>
          <div className="text-sm text-muted-foreground">Avg Rating</div>
        </div>
      </div>
      {/* History List */}
      {filteredHistory?.length === 0 ? (
        <div className="text-center py-12">
          <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
            <Icon name="BookOpen" size={24} color="var(--color-muted-foreground)" />
          </div>
          <h3 className="text-lg font-semibold text-foreground mb-2">
            {searchTerm ? 'No matching stories found' : 'No reading history yet'}
          </h3>
          <p className="text-muted-foreground mb-4">
            {searchTerm 
              ? 'Try adjusting your search terms or filters' :'Start exploring stories to build your reading history.'
            }
          </p>
          {!searchTerm && (
            <Button variant="default" iconName="Compass" iconPosition="left">
              Discover Stories
            </Button>
          )}
        </div>
      ) : (
        <div className="space-y-4">
          {filteredHistory?.map((item) => (
            <HistoryItem key={item?.id} item={item} />
          ))}
        </div>
      )}
    </div>
  );
};

export default ReadingHistory;