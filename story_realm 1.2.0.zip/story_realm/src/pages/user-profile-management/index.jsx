import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import ProfileHeader from './components/ProfileHeader';
import ReadingStats from './components/ReadingStats';
import CreatedStories from './components/CreatedStories';
import ReadingHistory from './components/ReadingHistory';
import SocialConnections from './components/SocialConnections';
import AccountSettings from './components/AccountSettings';
import AchievementsBadges from './components/AchievementsBadges';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';

const UserProfileManagement = () => {
  const [activeTab, setActiveTab] = useState('overview');

  // Mock user data
  const userData = {
    id: 'user-1',
    displayName: 'Alexandra Chen',
    username: 'alexwrites',
    email: 'alex.chen@email.com',
    avatar: 'https://images.unsplash.com/photo-1494790108755-2616b612b786?w=400',
    bio: `Passionate storyteller with a love for fantasy and mystery genres. I believe every story has the power to transport readers to new worlds and inspire imagination. Currently working on my debut fantasy series "The Crystal Realms".`,
    location: 'San Francisco, CA',
    joinDate: 'March 2023',
    isVerified: true,
    followersCount: 1247,
    followingCount: 389,
    totalReads: 15420,
    storiesCount: 12
  };

  // Mock reading statistics
  const readingStats = {
    storiesRead: 156,
    readingHours: 342,
    currentStreak: 12,
    bestStreak: 45,
    monthlyProgress: {
      current: 8,
      target: 12
    },
    yearlyProgress: {
      current: 89,
      target: 120
    },
    favoriteGenres: [
      { name: 'Fantasy', count: 45, percentage: 35 },
      { name: 'Mystery', count: 32, percentage: 25 },
      { name: 'Romance', count: 28, percentage: 22 },
      { name: 'Sci-Fi', count: 23, percentage: 18 }
    ],
    recentActivity: [
      {
        icon: 'BookOpen',
        action: 'Finished reading "The Dragon\'s Crown"',
        time: '2 hours ago'
      },
      {
        icon: 'Heart',
        action: 'Liked "Midnight in the Garden"',
        time: '5 hours ago'
      },
      {
        icon: 'MessageCircle',
        action: 'Commented on "The Lost Kingdom"',
        time: '1 day ago'
      }
    ]
  };

  // Mock created stories
  const createdStories = [
    {
      id: 'story-1',
      title: 'The Crystal Realms: Awakening',
      description: 'A young mage discovers her true power in a world where magic is forbidden and ancient secrets threaten to destroy everything she holds dear.',
      coverImage: 'https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=400',
      genre: 'Fantasy',
      status: 'published',
      chapters: 15,
      views: 12450,
      likes: 892,
      comments: 156,
      rating: 4.7,
      lastUpdated: 'Dec 15, 2024'
    },
    {
      id: 'story-2',
      title: 'Shadows of Tomorrow',
      description: 'In a dystopian future, a group of rebels fights against an oppressive regime using advanced technology and unwavering determination.',
      coverImage: 'https://images.unsplash.com/photo-1518709268805-4e9042af2176?w=400',
      genre: 'Sci-Fi',
      status: 'draft',
      chapters: 8,
      views: 3240,
      likes: 234,
      comments: 45,
      rating: 4.3,
      lastUpdated: 'Dec 10, 2024'
    },
    {
      id: 'story-3',
      title: 'The Midnight Detective',
      description: 'A detective with supernatural abilities investigates mysterious crimes that occur only during the witching hour.',
      coverImage: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400',
      genre: 'Mystery',
      status: 'published',
      chapters: 22,
      views: 8760,
      likes: 567,
      comments: 89,
      rating: 4.5,
      lastUpdated: 'Dec 8, 2024'
    }
  ];

  // Mock reading history
  const readingHistory = [
    {
      id: 'read-1',
      title: 'The Dragon\'s Crown',
      author: 'Marcus Thompson',
      coverImage: 'https://images.unsplash.com/photo-1544947950-fa07a98d237f?w=200',
      genre: 'Fantasy',
      status: 'completed',
      progress: 100,
      rating: 5.0,
      readingTime: '6h 30m',
      lastRead: 'Dec 16, 2024'
    },
    {
      id: 'read-2',
      title: 'Stellar Horizons',
      author: 'Sarah Kim',
      coverImage: 'https://images.unsplash.com/photo-1446776877081-d282a0f896e2?w=200',
      genre: 'Sci-Fi',
      status: 'reading',
      progress: 67,
      rating: 4.2,
      readingTime: '4h 15m',
      lastRead: 'Dec 15, 2024'
    },
    {
      id: 'read-3',
      title: 'Whispers in the Dark',
      author: 'Elena Rodriguez',
      coverImage: 'https://images.unsplash.com/photo-1481627834876-b7833e8f5570?w=200',
      genre: 'Mystery',
      status: 'bookmarked',
      progress: 0,
      rating: 0,
      readingTime: '0m',
      lastRead: 'Dec 12, 2024'
    }
  ];

  // Mock social connections
  const followers = [
    {
      id: 'follower-1',
      displayName: 'Emma Wilson',
      username: 'emmawrites',
      avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150',
      bio: 'Romance novelist and coffee enthusiast',
      storiesCount: 8,
      followersCount: 567,
      joinDate: 'Jan 2024',
      isVerified: false,
      isOnline: true,
      recentStory: 'Love in the Time of Magic'
    },
    {
      id: 'follower-2',
      displayName: 'David Park',
      username: 'davidp',
      avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150',
      bio: 'Sci-fi writer exploring the boundaries of imagination',
      storiesCount: 15,
      followersCount: 1203,
      joinDate: 'Nov 2023',
      isVerified: true,
      isOnline: false,
      recentStory: 'The Quantum Paradox'
    }
  ];

  const following = [
    {
      id: 'following-1',
      displayName: 'Maya Patel',
      username: 'mayastories',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150',
      bio: 'Fantasy author and world-building expert',
      storiesCount: 23,
      followersCount: 2890,
      joinDate: 'Aug 2023',
      isVerified: true,
      isOnline: true,
      isFollowing: true,
      mutualFollowers: 12,
      recentStory: 'The Elemental Wars'
    }
  ];

  // Mock account settings
  const accountSettings = {
    profile: {
      displayName: userData?.displayName,
      username: userData?.username,
      email: userData?.email,
      bio: userData?.bio,
      location: userData?.location
    },
    privacy: {
      publicProfile: true,
      showReadingActivity: true,
      allowRecommendations: true,
      twoFactorEnabled: false
    },
    notifications: {
      newFollower: true,
      storyComments: true,
      storyLikes: false,
      weeklyDigest: true,
      pushMessages: true,
      storyUpdates: true
    },
    preferences: {
      preferredGenres: ['Fantasy', 'Mystery', 'Sci-Fi'],
      contentRating: 'all',
      autoBookmark: true
    }
  };

  // Mock achievements and badges
  const achievements = [
    {
      id: 'ach-1',
      title: 'First Story',
      description: 'Published your very first story on Story Realm',
      icon: 'BookOpen',
      rarity: 'common',
      earned: true,
      earnedDate: 'Mar 15, 2023',
      points: 50
    },
    {
      id: 'ach-2',
      title: 'Rising Star',
      description: 'Reached 1,000 total story views',
      icon: 'Star',
      rarity: 'rare',
      earned: true,
      earnedDate: 'Jun 22, 2023',
      points: 200
    },
    {
      id: 'ach-3',
      title: 'Master Storyteller',
      description: 'Published 10 complete stories',
      icon: 'Crown',
      rarity: 'epic',
      earned: false,
      progress: 80,
      current: 8,
      target: 10,
      points: 500
    },
    {
      id: 'ach-4',
      title: 'Legend of the Realm',
      description: 'Reached 100,000 total story views',
      icon: 'Trophy',
      rarity: 'legendary',
      earned: false,
      progress: 15,
      current: 15420,
      target: 100000,
      points: 1000
    }
  ];

  const badges = [
    {
      id: 'badge-1',
      title: 'Fantasy Master',
      description: 'Specialized in fantasy genre writing',
      icon: 'Wand2',
      rarity: 'rare',
      earned: true,
      earnedDate: 'Aug 10, 2023',
      points: 150
    },
    {
      id: 'badge-2',
      title: 'Community Favorite',
      description: 'Received 500+ likes across all stories',
      icon: 'Heart',
      rarity: 'epic',
      earned: true,
      earnedDate: 'Nov 5, 2023',
      points: 300
    },
    {
      id: 'badge-3',
      title: 'Prolific Writer',
      description: 'Published 20 stories in a single year',
      icon: 'PenTool',
      rarity: 'legendary',
      earned: false,
      progress: 60,
      current: 12,
      target: 20,
      points: 750
    }
  ];

  const handleUpdateProfile = (updatedData) => {
    console.log('Profile updated:', updatedData);
    // Mock update logic
  };

  const handleEditStory = (storyId) => {
    console.log('Edit story:', storyId);
    // Navigate to story editor
  };

  const handleDeleteStory = (storyId) => {
    console.log('Delete story:', storyId);
    // Mock delete logic
  };

  const handleFollow = (userId) => {
    console.log('Follow user:', userId);
    // Mock follow logic
  };

  const handleUnfollow = (userId) => {
    console.log('Unfollow user:', userId);
    // Mock unfollow logic
  };

  const handleUpdateSettings = (section, data) => {
    console.log('Update settings:', section, data);
    // Mock settings update logic
  };

  const tabs = [
    { id: 'overview', label: 'Overview', icon: 'User' },
    { id: 'stories', label: 'My Stories', icon: 'BookOpen' },
    { id: 'reading', label: 'Reading History', icon: 'History' },
    { id: 'social', label: 'Social', icon: 'Users' },
    { id: 'achievements', label: 'Achievements', icon: 'Trophy' },
    { id: 'settings', label: 'Settings', icon: 'Settings' }
  ];

  const renderTabContent = () => {
    switch (activeTab) {
      case 'overview':
        return <ReadingStats stats={readingStats} />;
      case 'stories':
        return (
          <CreatedStories
            stories={createdStories}
            onEditStory={handleEditStory}
            onDeleteStory={handleDeleteStory}
          />
        );
      case 'reading':
        return <ReadingHistory history={readingHistory} />;
      case 'social':
        return (
          <SocialConnections
            followers={followers}
            following={following}
            onFollow={handleFollow}
            onUnfollow={handleUnfollow}
          />
        );
      case 'achievements':
        return (
          <AchievementsBadges
            achievements={achievements}
            badges={badges}
          />
        );
      case 'settings':
        return (
          <AccountSettings
            settings={accountSettings}
            onUpdateSettings={handleUpdateSettings}
          />
        );
      default:
        return <ReadingStats stats={readingStats} />;
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <title>Profile Management - Story Realm</title>
        <meta name="description" content="Manage your Story Realm profile, view your stories, reading history, and account settings." />
      </Helmet>
      <div className="container mx-auto px-4 py-8 max-w-7xl">
        {/* Profile Header */}
        <ProfileHeader user={userData} onUpdateProfile={handleUpdateProfile} />

        {/* Navigation Tabs */}
        <div className="mb-8">
          <div className="border-b border-border">
            <div className="flex overflow-x-auto">
              {tabs?.map((tab) => (
                <Button
                  key={tab?.id}
                  variant="ghost"
                  onClick={() => setActiveTab(tab?.id)}
                  className={`flex items-center gap-2 px-4 py-3 border-b-2 transition-colors whitespace-nowrap ${
                    activeTab === tab?.id
                      ? 'border-primary text-primary' :'border-transparent text-muted-foreground hover:text-foreground'
                  }`}
                >
                  <Icon name={tab?.icon} size={18} />
                  <span>{tab?.label}</span>
                </Button>
              ))}
            </div>
          </div>
        </div>

        {/* Tab Content */}
        <div className="min-h-[600px]">
          {renderTabContent()}
        </div>
      </div>
    </div>
  );
};

export default UserProfileManagement;