import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import LoginHeader from './components/LoginHeader';
import LoginForm from './components/LoginForm';
import SecurityNotice from './components/SecurityNotice';

const UserLogin = () => {
  const navigate = useNavigate();

  useEffect(() => {
    // Check if user is already authenticated
    const isAuthenticated = localStorage.getItem('isAuthenticated');
    if (isAuthenticated === 'true') {
      navigate('/story-discovery-dashboard');
    }

    // Update last activity timestamp
    localStorage.setItem('lastActivity', Date.now()?.toString());
  }, [navigate]);

  return (
    <div className="min-h-screen bg-background">
      <LoginHeader />
      <main className="flex-1 flex items-center justify-center px-4 py-12">
        <div className="w-full max-w-6xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            {/* Left Side - Branding */}
            <div className="hidden lg:block">
              <div className="text-center lg:text-left">
                <h2 className="text-4xl font-heading font-bold text-foreground mb-6">
                  Your Stories Await
                </h2>
                <p className="text-lg text-muted-foreground mb-8 leading-relaxed">
                  Join thousands of writers and readers in our vibrant storytelling community. 
                  Create, share, and discover amazing interactive stories that captivate and inspire.
                </p>
                
                <div className="grid grid-cols-2 gap-6 mb-8">
                  <div className="text-center p-4 bg-card rounded-lg border border-border">
                    <div className="text-2xl font-bold text-primary mb-1">50K+</div>
                    <div className="text-sm text-muted-foreground">Active Writers</div>
                  </div>
                  <div className="text-center p-4 bg-card rounded-lg border border-border">
                    <div className="text-2xl font-bold text-primary mb-1">1M+</div>
                    <div className="text-sm text-muted-foreground">Stories Published</div>
                  </div>
                </div>

                <div className="bg-gradient-to-r from-primary/10 to-accent/10 rounded-lg p-6 border border-border">
                  <h3 className="font-semibold text-foreground mb-2">Featured This Week</h3>
                  <p className="text-sm text-muted-foreground mb-3">
                    "The Digital Dreamscape" - An interactive sci-fi adventure that adapts to your choices
                  </p>
                  <div className="flex items-center space-x-2 text-xs text-muted-foreground">
                    <span>⭐ 4.9 rating</span>
                    <span>•</span>
                    <span>12K reads</span>
                    <span>•</span>
                    <span>Fantasy</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Right Side - Login Form */}
            <div className="w-full">
              <LoginForm />
            </div>
          </div>
        </div>
      </main>
      <SecurityNotice />
      {/* Footer */}
      <footer className="border-t border-border bg-card">
        <div className="container mx-auto px-4 py-6">
          <div className="flex flex-col sm:flex-row items-center justify-between space-y-4 sm:space-y-0">
            <div className="text-sm text-muted-foreground">
              © {new Date()?.getFullYear()} Story Realm. All rights reserved.
            </div>
            <div className="flex items-center space-x-6 text-sm">
              <a href="#" className="text-muted-foreground hover:text-foreground transition-colors">
                Privacy Policy
              </a>
              <a href="#" className="text-muted-foreground hover:text-foreground transition-colors">
                Terms of Service
              </a>
              <a href="#" className="text-muted-foreground hover:text-foreground transition-colors">
                Help Center
              </a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default UserLogin;