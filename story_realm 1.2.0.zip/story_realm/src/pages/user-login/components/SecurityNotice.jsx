import React, { useState, useEffect } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const SecurityNotice = () => {
  const [showNotice, setShowNotice] = useState(false);
  const [timeLeft, setTimeLeft] = useState(0);

  useEffect(() => {
    // Check if user has been inactive
    const lastActivity = localStorage.getItem('lastActivity');
    const currentTime = Date.now();
    const inactiveTime = currentTime - (lastActivity || currentTime);
    
    // Show security notice if inactive for more than 30 minutes (simulated as 5 seconds for demo)
    if (inactiveTime > 5000) {
      setShowNotice(true);
      setTimeLeft(300); // 5 minutes countdown
    }
  }, []);

  useEffect(() => {
    if (timeLeft > 0) {
      const timer = setTimeout(() => setTimeLeft(timeLeft - 1), 1000);
      return () => clearTimeout(timer);
    } else if (showNotice && timeLeft === 0) {
      // Auto logout
      localStorage.removeItem('isAuthenticated');
      localStorage.removeItem('userEmail');
      setShowNotice(false);
    }
  }, [timeLeft, showNotice]);

  const handleContinueSession = () => {
    localStorage.setItem('lastActivity', Date.now()?.toString());
    setShowNotice(false);
    setTimeLeft(0);
  };

  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs?.toString()?.padStart(2, '0')}`;
  };

  if (!showNotice) return null;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-card rounded-lg shadow-warm-lg p-6 max-w-md w-full border border-border">
        <div className="flex items-center space-x-3 mb-4">
          <div className="w-10 h-10 bg-warning/10 rounded-full flex items-center justify-center">
            <Icon name="Shield" size={20} color="var(--color-warning)" />
          </div>
          <div>
            <h3 className="font-semibold text-foreground">Security Notice</h3>
            <p className="text-sm text-muted-foreground">Session timeout warning</p>
          </div>
        </div>

        <div className="mb-6">
          <p className="text-sm text-foreground mb-2">
            For your security, you'll be automatically logged out in:
          </p>
          <div className="text-2xl font-mono font-semibold text-warning text-center py-2">
            {formatTime(timeLeft)}
          </div>
          <p className="text-xs text-muted-foreground text-center">
            Click "Continue Session" to stay logged in
          </p>
        </div>

        <div className="flex space-x-3">
          <Button
            variant="outline"
            size="sm"
            fullWidth
            onClick={() => {
              localStorage.removeItem('isAuthenticated');
              localStorage.removeItem('userEmail');
              setShowNotice(false);
            }}
          >
            Logout Now
          </Button>
          <Button
            variant="default"
            size="sm"
            fullWidth
            onClick={handleContinueSession}
          >
            Continue Session
          </Button>
        </div>

        <div className="mt-4 p-3 bg-muted rounded-md">
          <div className="flex items-start space-x-2">
            <Icon name="Info" size={14} color="var(--color-muted-foreground)" className="mt-0.5" />
            <p className="text-xs text-muted-foreground">
              We automatically log you out after periods of inactivity to protect your account and stories.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SecurityNotice;