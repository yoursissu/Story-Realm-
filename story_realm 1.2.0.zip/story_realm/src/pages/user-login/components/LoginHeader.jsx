import React from 'react';
import { Link } from 'react-router-dom';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const LoginHeader = () => {
  return (
    <header className="w-full bg-background border-b border-border">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <Link to="/story-discovery-dashboard" className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
              <Icon name="BookOpen" size={20} color="var(--color-primary-foreground)" />
            </div>
            <span className="font-heading font-semibold text-xl text-foreground">
              Story Realm
            </span>
          </Link>

          {/* Registration Link */}
          <div className="flex items-center space-x-4">
            <span className="text-sm text-muted-foreground hidden sm:inline">
              New to Story Realm?
            </span>
            <Button
              variant="outline"
              size="sm"
              asChild
            >
              <Link to="/user-registration">
                Create Account
              </Link>
            </Button>
          </div>
        </div>
      </div>
    </header>
  );
};

export default LoginHeader;