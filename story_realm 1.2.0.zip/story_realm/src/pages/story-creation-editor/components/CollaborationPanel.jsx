import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import Image from '../../../components/AppImage';

const CollaborationPanel = ({ collaborators, comments, onInviteCollaborator, onAddComment, isVisible, onToggle }) => {
  const [inviteEmail, setInviteEmail] = useState('');
  const [newComment, setNewComment] = useState('');

  const mockCollaborators = [
    {
      id: 1,
      name: "Sarah Johnson",
      email: "sarah.johnson@email.com",
      avatar: "https://images.unsplash.com/photo-1494790108755-2616b612b786?w=150",
      role: "Co-Author",
      status: "online",
      lastActive: new Date()
    },
    {
      id: 2,
      name: "Michael Chen",
      email: "michael.chen@email.com",
      avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150",
      role: "Editor",
      status: "offline",
      lastActive: new Date(Date.now() - 3600000)
    }
  ];

  const mockComments = [
    {
      id: 1,
      author: "Sarah Johnson",
      avatar: "https://images.unsplash.com/photo-1494790108755-2616b612b786?w=150",
      content: "I think this chapter needs more character development. The dialogue feels a bit rushed.",
      timestamp: new Date(Date.now() - 1800000),
      chapterId: 1,
      resolved: false
    },
    {
      id: 2,
      author: "Michael Chen",
      avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150",
      content: "Great work on the world-building! The descriptions are vivid and engaging.",
      timestamp: new Date(Date.now() - 3600000),
      chapterId: 1,
      resolved: true
    },
    {
      id: 3,
      author: "You",
      avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150",
      content: "Thanks for the feedback! I\'ll work on expanding the character interactions.",
      timestamp: new Date(Date.now() - 900000),
      chapterId: 1,
      resolved: false
    }
  ];

  const handleInvite = () => {
    if (inviteEmail?.trim()) {
      onInviteCollaborator(inviteEmail);
      setInviteEmail('');
    }
  };

  const handleAddComment = () => {
    if (newComment?.trim()) {
      onAddComment(newComment);
      setNewComment('');
    }
  };

  if (!isVisible) {
    return (
      <Button
        variant="ghost"
        size="icon"
        onClick={onToggle}
        className="fixed top-32 right-4 z-40 lg:hidden"
      >
        <Icon name="Users" size={20} />
      </Button>
    );
  }

  return (
    <div className="w-80 bg-card border-l border-border flex flex-col">
      <div className="p-4 border-b border-border">
        <div className="flex items-center justify-between">
          <h3 className="font-heading font-semibold text-lg text-card-foreground">Collaboration</h3>
          <Button
            variant="ghost"
            size="icon"
            onClick={onToggle}
            className="lg:hidden"
          >
            <Icon name="X" size={16} />
          </Button>
        </div>
      </div>
      <div className="flex-1 overflow-y-auto">
        {/* Collaborators Section */}
        <div className="p-4 border-b border-border">
          <h4 className="font-medium text-card-foreground mb-3">Collaborators</h4>
          
          {/* Invite New Collaborator */}
          <div className="mb-4">
            <div className="flex space-x-2">
              <Input
                type="email"
                placeholder="Enter email address"
                value={inviteEmail}
                onChange={(e) => setInviteEmail(e?.target?.value)}
                className="flex-1"
              />
              <Button size="sm" onClick={handleInvite}>
                <Icon name="UserPlus" size={14} />
              </Button>
            </div>
          </div>

          {/* Collaborator List */}
          <div className="space-y-3">
            {mockCollaborators?.map((collaborator) => (
              <div key={collaborator?.id} className="flex items-center space-x-3">
                <div className="relative">
                  <Image
                    src={collaborator?.avatar}
                    alt={collaborator?.name}
                    className="w-8 h-8 rounded-full"
                  />
                  <div className={`absolute -bottom-1 -right-1 w-3 h-3 rounded-full border-2 border-card ${
                    collaborator?.status === 'online' ? 'bg-success' : 'bg-muted-foreground'
                  }`} />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-card-foreground truncate">
                    {collaborator?.name}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    {collaborator?.role}
                  </p>
                </div>
                <Button variant="ghost" size="icon" className="h-6 w-6">
                  <Icon name="MoreVertical" size={12} />
                </Button>
              </div>
            ))}
          </div>
        </div>

        {/* Comments Section */}
        <div className="p-4">
          <h4 className="font-medium text-card-foreground mb-3">Comments</h4>
          
          {/* Add Comment */}
          <div className="mb-4">
            <textarea
              value={newComment}
              onChange={(e) => setNewComment(e?.target?.value)}
              placeholder="Add a comment..."
              rows={3}
              className="w-full px-3 py-2 border border-border rounded-md bg-input text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring focus:border-transparent resize-none text-sm"
            />
            <div className="flex justify-end mt-2">
              <Button size="sm" onClick={handleAddComment} disabled={!newComment?.trim()}>
                <Icon name="Send" size={14} className="mr-1" />
                Comment
              </Button>
            </div>
          </div>

          {/* Comments List */}
          <div className="space-y-4">
            {mockComments?.map((comment) => (
              <div key={comment?.id} className={`p-3 rounded-lg border ${
                comment?.resolved ? 'bg-muted/50 border-muted' : 'bg-background border-border'
              }`}>
                <div className="flex items-start space-x-3">
                  <Image
                    src={comment?.avatar}
                    alt={comment?.author}
                    className="w-6 h-6 rounded-full flex-shrink-0"
                  />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center space-x-2 mb-1">
                      <p className="text-sm font-medium text-card-foreground">
                        {comment?.author}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {new Date(comment.timestamp)?.toLocaleTimeString()}
                      </p>
                      {comment?.resolved && (
                        <Icon name="Check" size={12} className="text-success" />
                      )}
                    </div>
                    <p className="text-sm text-card-foreground">
                      {comment?.content}
                    </p>
                    <div className="flex items-center space-x-2 mt-2">
                      <Button variant="ghost" size="sm" className="h-6 px-2 text-xs">
                        Reply
                      </Button>
                      {!comment?.resolved && (
                        <Button variant="ghost" size="sm" className="h-6 px-2 text-xs">
                          Resolve
                        </Button>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default CollaborationPanel;