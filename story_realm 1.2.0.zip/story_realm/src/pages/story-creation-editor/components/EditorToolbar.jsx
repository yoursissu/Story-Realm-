import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const EditorToolbar = ({ onFormat, onInsertMedia, onPreview, onSave, isSaving, lastSaved }) => {
  const [isFloating, setIsFloating] = useState(false);

  const formatButtons = [
    { name: 'Bold', icon: 'Bold', action: 'bold' },
    { name: 'Italic', icon: 'Italic', action: 'italic' },
    { name: 'Underline', icon: 'Underline', action: 'underline' },
    { name: 'Strikethrough', icon: 'Strikethrough', action: 'strikethrough' }
  ];

  const headingButtons = [
    { name: 'Heading 1', icon: 'Heading1', action: 'h1' },
    { name: 'Heading 2', icon: 'Heading2', action: 'h2' },
    { name: 'Heading 3', icon: 'Heading3', action: 'h3' }
  ];

  const listButtons = [
    { name: 'Bullet List', icon: 'List', action: 'ul' },
    { name: 'Numbered List', icon: 'ListOrdered', action: 'ol' }
  ];

  const mediaButtons = [
    { name: 'Insert Image', icon: 'Image', action: 'image' },
    { name: 'Insert Audio', icon: 'Music', action: 'audio' },
    { name: 'Insert Video', icon: 'Video', action: 'video' }
  ];

  const handleFormat = (action) => {
    onFormat(action);
  };

  const handleMediaInsert = (type) => {
    onInsertMedia(type);
  };

  return (
    <>
      {/* Desktop Toolbar */}
      <div className="hidden lg:flex items-center justify-between p-4 bg-card border-b border-border">
        <div className="flex items-center space-x-6">
          {/* Text Formatting */}
          <div className="flex items-center space-x-1">
            {formatButtons?.map((button) => (
              <Button
                key={button?.action}
                variant="ghost"
                size="icon"
                onClick={() => handleFormat(button?.action)}
                title={button?.name}
              >
                <Icon name={button?.icon} size={16} />
              </Button>
            ))}
          </div>

          <div className="w-px h-6 bg-border" />

          {/* Headings */}
          <div className="flex items-center space-x-1">
            {headingButtons?.map((button) => (
              <Button
                key={button?.action}
                variant="ghost"
                size="icon"
                onClick={() => handleFormat(button?.action)}
                title={button?.name}
              >
                <Icon name={button?.icon} size={16} />
              </Button>
            ))}
          </div>

          <div className="w-px h-6 bg-border" />

          {/* Lists */}
          <div className="flex items-center space-x-1">
            {listButtons?.map((button) => (
              <Button
                key={button?.action}
                variant="ghost"
                size="icon"
                onClick={() => handleFormat(button?.action)}
                title={button?.name}
              >
                <Icon name={button?.icon} size={16} />
              </Button>
            ))}
          </div>

          <div className="w-px h-6 bg-border" />

          {/* Media */}
          <div className="flex items-center space-x-1">
            {mediaButtons?.map((button) => (
              <Button
                key={button?.action}
                variant="ghost"
                size="icon"
                onClick={() => handleMediaInsert(button?.action)}
                title={button?.name}
              >
                <Icon name={button?.icon} size={16} />
              </Button>
            ))}
          </div>
        </div>

        <div className="flex items-center space-x-4">
          {/* Save Status */}
          <div className="flex items-center space-x-2 text-sm text-muted-foreground">
            {isSaving ? (
              <>
                <Icon name="Loader2" size={14} className="animate-spin" />
                <span>Saving...</span>
              </>
            ) : lastSaved ? (
              <>
                <Icon name="Check" size={14} className="text-success" />
                <span>Saved {new Date(lastSaved)?.toLocaleTimeString()}</span>
              </>
            ) : null}
          </div>

          {/* Action Buttons */}
          <div className="flex items-center space-x-2">
            <Button variant="outline" onClick={onPreview}>
              <Icon name="Eye" size={16} className="mr-2" />
              Preview
            </Button>
            <Button onClick={onSave} loading={isSaving}>
              <Icon name="Save" size={16} className="mr-2" />
              Save
            </Button>
          </div>
        </div>
      </div>
      {/* Mobile Floating Toolbar */}
      <div className="lg:hidden">
        <Button
          variant="default"
          size="icon"
          onClick={() => setIsFloating(!isFloating)}
          className="fixed bottom-4 right-4 z-50 w-12 h-12 rounded-full shadow-lg"
        >
          <Icon name={isFloating ? "X" : "Type"} size={20} />
        </Button>

        {isFloating && (
          <div className="fixed bottom-20 right-4 z-40 bg-card border border-border rounded-lg shadow-lg p-3 max-w-xs">
            <div className="grid grid-cols-4 gap-2 mb-3">
              {formatButtons?.map((button) => (
                <Button
                  key={button?.action}
                  variant="ghost"
                  size="icon"
                  onClick={() => handleFormat(button?.action)}
                  className="h-8 w-8"
                >
                  <Icon name={button?.icon} size={14} />
                </Button>
              ))}
            </div>

            <div className="grid grid-cols-3 gap-2 mb-3">
              {headingButtons?.map((button) => (
                <Button
                  key={button?.action}
                  variant="ghost"
                  size="icon"
                  onClick={() => handleFormat(button?.action)}
                  className="h-8 w-8"
                >
                  <Icon name={button?.icon} size={14} />
                </Button>
              ))}
            </div>

            <div className="grid grid-cols-2 gap-2 mb-3">
              {listButtons?.map((button) => (
                <Button
                  key={button?.action}
                  variant="ghost"
                  size="icon"
                  onClick={() => handleFormat(button?.action)}
                  className="h-8 w-8"
                >
                  <Icon name={button?.icon} size={14} />
                </Button>
              ))}
            </div>

            <div className="grid grid-cols-3 gap-2 mb-3">
              {mediaButtons?.map((button) => (
                <Button
                  key={button?.action}
                  variant="ghost"
                  size="icon"
                  onClick={() => handleMediaInsert(button?.action)}
                  className="h-8 w-8"
                >
                  <Icon name={button?.icon} size={14} />
                </Button>
              ))}
            </div>

            <div className="flex space-x-2">
              <Button variant="outline" size="sm" onClick={onPreview} className="flex-1">
                Preview
              </Button>
              <Button size="sm" onClick={onSave} loading={isSaving} className="flex-1">
                Save
              </Button>
            </div>
          </div>
        )}
      </div>
    </>
  );
};

export default EditorToolbar;