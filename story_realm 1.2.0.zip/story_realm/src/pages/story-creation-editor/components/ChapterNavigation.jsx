import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const ChapterNavigation = ({ chapters, activeChapter, onChapterSelect, onAddChapter, onDeleteChapter, onReorderChapters }) => {
  const [draggedChapter, setDraggedChapter] = useState(null);
  const [isCollapsed, setIsCollapsed] = useState(false);

  const handleDragStart = (e, chapterId) => {
    setDraggedChapter(chapterId);
    e.dataTransfer.effectAllowed = 'move';
  };

  const handleDragOver = (e) => {
    e?.preventDefault();
    e.dataTransfer.dropEffect = 'move';
  };

  const handleDrop = (e, targetChapterId) => {
    e?.preventDefault();
    if (draggedChapter && draggedChapter !== targetChapterId) {
      const draggedIndex = chapters?.findIndex(ch => ch?.id === draggedChapter);
      const targetIndex = chapters?.findIndex(ch => ch?.id === targetChapterId);
      
      const reorderedChapters = [...chapters];
      const [draggedItem] = reorderedChapters?.splice(draggedIndex, 1);
      reorderedChapters?.splice(targetIndex, 0, draggedItem);
      
      onReorderChapters(reorderedChapters);
    }
    setDraggedChapter(null);
  };

  if (isCollapsed) {
    return (
      <div className="w-12 bg-card border-r border-border flex flex-col items-center py-4">
        <Button
          variant="ghost"
          size="icon"
          onClick={() => setIsCollapsed(false)}
          className="mb-4"
        >
          <Icon name="ChevronRight" size={16} />
        </Button>
        <div className="flex flex-col space-y-2">
          {chapters?.map((chapter, index) => (
            <button
              key={chapter?.id}
              onClick={() => onChapterSelect(chapter?.id)}
              className={`w-8 h-8 rounded-md flex items-center justify-center text-xs font-medium transition-colors ${
                activeChapter === chapter?.id
                  ? 'bg-primary text-primary-foreground'
                  : 'bg-muted text-muted-foreground hover:bg-muted/80'
              }`}
            >
              {index + 1}
            </button>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="w-80 bg-card border-r border-border flex flex-col">
      <div className="p-4 border-b border-border">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-heading font-semibold text-lg text-card-foreground">Chapters</h3>
          <div className="flex items-center space-x-2">
            <Button
              variant="ghost"
              size="icon"
              onClick={onAddChapter}
            >
              <Icon name="Plus" size={16} />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setIsCollapsed(true)}
            >
              <Icon name="ChevronLeft" size={16} />
            </Button>
          </div>
        </div>
      </div>
      <div className="flex-1 overflow-y-auto p-2">
        {chapters?.map((chapter, index) => (
          <div
            key={chapter?.id}
            draggable
            onDragStart={(e) => handleDragStart(e, chapter?.id)}
            onDragOver={handleDragOver}
            onDrop={(e) => handleDrop(e, chapter?.id)}
            className={`group p-3 mb-2 rounded-lg border cursor-pointer transition-all ${
              activeChapter === chapter?.id
                ? 'bg-primary/10 border-primary text-primary' :'bg-background border-border hover:bg-muted'
            } ${draggedChapter === chapter?.id ? 'opacity-50' : ''}`}
            onClick={() => onChapterSelect(chapter?.id)}
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3 flex-1 min-w-0">
                <Icon name="GripVertical" size={14} className="text-muted-foreground group-hover:text-foreground" />
                <div className="flex-1 min-w-0">
                  <div className="flex items-center space-x-2">
                    <span className="text-xs font-medium text-muted-foreground">
                      Chapter {index + 1}
                    </span>
                    {chapter?.wordCount > 0 && (
                      <span className="text-xs text-muted-foreground">
                        {chapter?.wordCount} words
                      </span>
                    )}
                  </div>
                  <h4 className="font-medium text-sm truncate mt-1">
                    {chapter?.title || 'Untitled Chapter'}
                  </h4>
                </div>
              </div>
              <Button
                variant="ghost"
                size="icon"
                onClick={(e) => {
                  e?.stopPropagation();
                  onDeleteChapter(chapter?.id);
                }}
                className="opacity-0 group-hover:opacity-100 transition-opacity"
              >
                <Icon name="Trash2" size={14} />
              </Button>
            </div>
            
            {chapter?.lastModified && (
              <div className="mt-2 text-xs text-muted-foreground">
                Modified {new Date(chapter.lastModified)?.toLocaleDateString()}
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

export default ChapterNavigation;