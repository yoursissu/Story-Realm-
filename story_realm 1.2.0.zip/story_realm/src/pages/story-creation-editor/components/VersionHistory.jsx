import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const VersionHistory = ({ versions, onRestore, onCompare, isVisible, onToggle }) => {
  const [selectedVersions, setSelectedVersions] = useState([]);

  const mockVersions = [
    {
      id: 1,
      title: "Current Version",
      timestamp: new Date(),
      author: "You",
      changes: "Added new chapter introduction",
      wordCount: 2847,
      isCurrent: true
    },
    {
      id: 2,
      title: "Auto-save",
      timestamp: new Date(Date.now() - 300000),
      author: "System",
      changes: "Auto-saved changes",
      wordCount: 2834,
      isCurrent: false
    },
    {
      id: 3,
      title: "Chapter 3 Complete",
      timestamp: new Date(Date.now() - 3600000),
      author: "You",
      changes: "Completed chapter 3 draft",
      wordCount: 2756,
      isCurrent: false
    },
    {
      id: 4,
      title: "Character Development",
      timestamp: new Date(Date.now() - 7200000),
      author: "Sarah Johnson",
      changes: "Enhanced character dialogue and motivations",
      wordCount: 2689,
      isCurrent: false
    },
    {
      id: 5,
      title: "Initial Draft",
      timestamp: new Date(Date.now() - 86400000),
      author: "You",
      changes: "Created initial story structure",
      wordCount: 2234,
      isCurrent: false
    }
  ];

  const handleVersionSelect = (versionId) => {
    setSelectedVersions(prev => {
      if (prev?.includes(versionId)) {
        return prev?.filter(id => id !== versionId);
      } else if (prev?.length < 2) {
        return [...prev, versionId];
      } else {
        return [prev?.[1], versionId];
      }
    });
  };

  const handleCompare = () => {
    if (selectedVersions?.length === 2) {
      onCompare(selectedVersions);
    }
  };

  if (!isVisible) {
    return (
      <Button
        variant="ghost"
        size="icon"
        onClick={onToggle}
        className="fixed top-44 right-4 z-40 lg:hidden"
      >
        <Icon name="History" size={20} />
      </Button>
    );
  }

  return (
    <div className="w-80 bg-card border-l border-border flex flex-col">
      <div className="p-4 border-b border-border">
        <div className="flex items-center justify-between">
          <h3 className="font-heading font-semibold text-lg text-card-foreground">Version History</h3>
          <Button
            variant="ghost"
            size="icon"
            onClick={onToggle}
            className="lg:hidden"
          >
            <Icon name="X" size={16} />
          </Button>
        </div>
      </div>
      <div className="flex-1 overflow-y-auto">
        {/* Compare Actions */}
        {selectedVersions?.length > 0 && (
          <div className="p-4 bg-muted/50 border-b border-border">
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">
                {selectedVersions?.length} version{selectedVersions?.length > 1 ? 's' : ''} selected
              </span>
              <div className="flex space-x-2">
                {selectedVersions?.length === 2 && (
                  <Button size="sm" onClick={handleCompare}>
                    <Icon name="GitCompare" size={14} className="mr-1" />
                    Compare
                  </Button>
                )}
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setSelectedVersions([])}
                >
                  Clear
                </Button>
              </div>
            </div>
          </div>
        )}

        {/* Version List */}
        <div className="p-4 space-y-3">
          {mockVersions?.map((version) => (
            <div
              key={version?.id}
              className={`p-3 rounded-lg border cursor-pointer transition-all ${
                version?.isCurrent
                  ? 'bg-primary/10 border-primary'
                  : selectedVersions?.includes(version?.id)
                  ? 'bg-secondary/50 border-secondary' :'bg-background border-border hover:bg-muted/50'
              }`}
              onClick={() => !version?.isCurrent && handleVersionSelect(version?.id)}
            >
              <div className="flex items-start justify-between">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center space-x-2 mb-1">
                    <h4 className="font-medium text-sm text-card-foreground truncate">
                      {version?.title}
                    </h4>
                    {version?.isCurrent && (
                      <span className="px-2 py-0.5 bg-primary text-primary-foreground text-xs rounded-full">
                        Current
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-muted-foreground mb-2">
                    {version?.changes}
                  </p>
                  <div className="flex items-center space-x-3 text-xs text-muted-foreground">
                    <span>{version?.author}</span>
                    <span>{version?.wordCount} words</span>
                    <span>{new Date(version.timestamp)?.toLocaleString()}</span>
                  </div>
                </div>
                
                {!version?.isCurrent && (
                  <div className="flex flex-col space-y-1 ml-2">
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={(e) => {
                        e?.stopPropagation();
                        onRestore(version?.id);
                      }}
                      className="h-6 w-6"
                    >
                      <Icon name="RotateCcw" size={12} />
                    </Button>
                    {selectedVersions?.includes(version?.id) && (
                      <Icon name="Check" size={12} className="text-primary mx-auto" />
                    )}
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>

        {/* Auto-save Settings */}
        <div className="p-4 border-t border-border">
          <h4 className="font-medium text-card-foreground mb-3">Auto-save Settings</h4>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm text-card-foreground">Auto-save enabled</span>
              <div className="w-10 h-6 bg-primary rounded-full relative">
                <div className="w-4 h-4 bg-white rounded-full absolute top-1 right-1 transition-transform" />
              </div>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-card-foreground">Save interval</span>
              <span className="text-sm text-muted-foreground">5 minutes</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-card-foreground">Keep versions</span>
              <span className="text-sm text-muted-foreground">30 days</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default VersionHistory;