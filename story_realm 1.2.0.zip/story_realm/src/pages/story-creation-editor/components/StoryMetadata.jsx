import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';
import Image from '../../../components/AppImage';

const StoryMetadata = ({ metadata, onUpdate, isVisible, onToggle }) => {
  const [localMetadata, setLocalMetadata] = useState(metadata);

  const genreOptions = [
    { value: 'fantasy', label: 'Fantasy' },
    { value: 'romance', label: 'Romance' },
    { value: 'mystery', label: 'Mystery' },
    { value: 'thriller', label: 'Thriller' },
    { value: 'sci-fi', label: 'Science Fiction' },
    { value: 'horror', label: 'Horror' },
    { value: 'adventure', label: 'Adventure' },
    { value: 'drama', label: 'Drama' },
    { value: 'comedy', label: 'Comedy' },
    { value: 'historical', label: 'Historical Fiction' },
    { value: 'young-adult', label: 'Young Adult' },
    { value: 'literary', label: 'Literary Fiction' }
  ];

  const statusOptions = [
    { value: 'draft', label: 'Draft' },
    { value: 'in-progress', label: 'In Progress' },
    { value: 'completed', label: 'Completed' },
    { value: 'published', label: 'Published' }
  ];

  const handleInputChange = (field, value) => {
    const updated = { ...localMetadata, [field]: value };
    setLocalMetadata(updated);
    onUpdate(updated);
  };

  const handleTagAdd = (tag) => {
    if (tag && !localMetadata?.tags?.includes(tag)) {
      const updated = { ...localMetadata, tags: [...localMetadata?.tags, tag] };
      setLocalMetadata(updated);
      onUpdate(updated);
    }
  };

  const handleTagRemove = (tagToRemove) => {
    const updated = { ...localMetadata, tags: localMetadata?.tags?.filter(tag => tag !== tagToRemove) };
    setLocalMetadata(updated);
    onUpdate(updated);
  };

  const handleCoverUpload = (event) => {
    const file = event?.target?.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        handleInputChange('coverImage', e?.target?.result);
      };
      reader?.readAsDataURL(file);
    }
  };

  if (!isVisible) {
    return (
      <Button
        variant="ghost"
        size="icon"
        onClick={onToggle}
        className="fixed top-20 right-4 z-40 lg:hidden"
      >
        <Icon name="Settings" size={20} />
      </Button>
    );
  }

  return (
    <div className="w-80 bg-card border-l border-border flex flex-col">
      <div className="p-4 border-b border-border">
        <div className="flex items-center justify-between">
          <h3 className="font-heading font-semibold text-lg text-card-foreground">Story Details</h3>
          <Button
            variant="ghost"
            size="icon"
            onClick={onToggle}
            className="lg:hidden"
          >
            <Icon name="X" size={16} />
          </Button>
        </div>
      </div>
      <div className="flex-1 overflow-y-auto p-4 space-y-6">
        {/* Cover Image */}
        <div>
          <label className="block text-sm font-medium text-card-foreground mb-2">
            Cover Image
          </label>
          <div className="relative">
            {localMetadata?.coverImage ? (
              <div className="relative w-full h-48 rounded-lg overflow-hidden border border-border">
                <Image
                  src={localMetadata?.coverImage}
                  alt="Story cover"
                  className="w-full h-full object-cover"
                />
                <Button
                  variant="destructive"
                  size="icon"
                  onClick={() => handleInputChange('coverImage', '')}
                  className="absolute top-2 right-2"
                >
                  <Icon name="Trash2" size={14} />
                </Button>
              </div>
            ) : (
              <label className="flex flex-col items-center justify-center w-full h-48 border-2 border-dashed border-border rounded-lg cursor-pointer hover:bg-muted/50 transition-colors">
                <Icon name="ImagePlus" size={32} className="text-muted-foreground mb-2" />
                <span className="text-sm text-muted-foreground">Upload cover image</span>
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleCoverUpload}
                  className="hidden"
                />
              </label>
            )}
          </div>
        </div>

        {/* Title */}
        <Input
          label="Story Title"
          type="text"
          value={localMetadata?.title}
          onChange={(e) => handleInputChange('title', e?.target?.value)}
          placeholder="Enter your story title"
          required
        />

        {/* Description */}
        <div>
          <label className="block text-sm font-medium text-card-foreground mb-2">
            Description
          </label>
          <textarea
            value={localMetadata?.description}
            onChange={(e) => handleInputChange('description', e?.target?.value)}
            placeholder="Write a compelling description of your story..."
            rows={4}
            className="w-full px-3 py-2 border border-border rounded-md bg-input text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring focus:border-transparent resize-none"
          />
        </div>

        {/* Genre */}
        <Select
          label="Genre"
          options={genreOptions}
          value={localMetadata?.genre}
          onChange={(value) => handleInputChange('genre', value)}
          placeholder="Select a genre"
        />

        {/* Status */}
        <Select
          label="Status"
          options={statusOptions}
          value={localMetadata?.status}
          onChange={(value) => handleInputChange('status', value)}
          placeholder="Select status"
        />

        {/* Tags */}
        <div>
          <label className="block text-sm font-medium text-card-foreground mb-2">
            Tags
          </label>
          <div className="flex flex-wrap gap-2 mb-2">
            {localMetadata?.tags?.map((tag, index) => (
              <span
                key={index}
                className="inline-flex items-center px-2 py-1 rounded-full text-xs bg-secondary text-secondary-foreground"
              >
                {tag}
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => handleTagRemove(tag)}
                  className="ml-1 h-4 w-4 p-0 hover:bg-transparent"
                >
                  <Icon name="X" size={12} />
                </Button>
              </span>
            ))}
          </div>
          <div className="flex space-x-2">
            <Input
              type="text"
              placeholder="Add a tag"
              onKeyPress={(e) => {
                if (e?.key === 'Enter') {
                  e?.preventDefault();
                  handleTagAdd(e?.target?.value?.trim());
                  e.target.value = '';
                }
              }}
              className="flex-1"
            />
          </div>
        </div>

        {/* Target Audience */}
        <div>
          <label className="block text-sm font-medium text-card-foreground mb-2">
            Target Audience
          </label>
          <div className="space-y-2">
            {['General', 'Young Adult', 'Adult', 'Children']?.map((audience) => (
              <label key={audience} className="flex items-center space-x-2">
                <input
                  type="radio"
                  name="audience"
                  value={audience?.toLowerCase()}
                  checked={localMetadata?.targetAudience === audience?.toLowerCase()}
                  onChange={(e) => handleInputChange('targetAudience', e?.target?.value)}
                  className="w-4 h-4 text-primary border-border focus:ring-ring"
                />
                <span className="text-sm text-card-foreground">{audience}</span>
              </label>
            ))}
          </div>
        </div>

        {/* Language */}
        <Input
          label="Language"
          type="text"
          value={localMetadata?.language}
          onChange={(e) => handleInputChange('language', e?.target?.value)}
          placeholder="English"
        />

        {/* Estimated Reading Time */}
        <div className="p-3 bg-muted rounded-lg">
          <div className="flex items-center justify-between text-sm">
            <span className="text-muted-foreground">Estimated Reading Time</span>
            <span className="font-medium text-foreground">{localMetadata?.estimatedReadingTime} minutes</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default StoryMetadata;