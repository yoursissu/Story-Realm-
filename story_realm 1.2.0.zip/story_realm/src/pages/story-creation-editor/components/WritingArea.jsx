import React, { useRef, useEffect } from 'react';
import Icon from '../../../components/AppIcon';

const WritingArea = ({ content, onChange, wordCount, readingTime, placeholder }) => {
  const editorRef = useRef(null);

  useEffect(() => {
    if (editorRef?.current && content !== editorRef?.current?.innerHTML) {
      editorRef.current.innerHTML = content;
    }
  }, [content]);

  const handleInput = () => {
    if (editorRef?.current) {
      onChange(editorRef?.current?.innerHTML);
    }
  };

  const handleKeyDown = (e) => {
    // Handle keyboard shortcuts
    if (e?.ctrlKey || e?.metaKey) {
      switch (e?.key) {
        case 'b':
          e?.preventDefault();
          document.execCommand('bold');
          break;
        case 'i':
          e?.preventDefault();
          document.execCommand('italic');
          break;
        case 'u':
          e?.preventDefault();
          document.execCommand('underline');
          break;
        default:
          break;
      }
    }
  };

  return (
    <div className="flex-1 flex flex-col bg-background">
      {/* Stats Bar */}
      <div className="flex items-center justify-between p-4 bg-card border-b border-border">
        <div className="flex items-center space-x-6 text-sm text-muted-foreground">
          <div className="flex items-center space-x-2">
            <Icon name="FileText" size={16} />
            <span>{wordCount} words</span>
          </div>
          <div className="flex items-center space-x-2">
            <Icon name="Clock" size={16} />
            <span>{readingTime} min read</span>
          </div>
        </div>
        
        <div className="flex items-center space-x-4 text-sm text-muted-foreground">
          <div className="flex items-center space-x-2">
            <Icon name="Target" size={16} />
            <span>Goal: 2,000 words</span>
          </div>
          <div className="w-24 h-2 bg-muted rounded-full overflow-hidden">
            <div 
              className="h-full bg-primary transition-all duration-300"
              style={{ width: `${Math.min((wordCount / 2000) * 100, 100)}%` }}
            />
          </div>
        </div>
      </div>

      {/* Writing Area */}
      <div className="flex-1 p-6 overflow-y-auto">
        <div className="max-w-4xl mx-auto">
          <div
            ref={editorRef}
            contentEditable
            onInput={handleInput}
            onKeyDown={handleKeyDown}
            className="min-h-96 p-6 bg-card rounded-lg border border-border focus:outline-none focus:ring-2 focus:ring-ring focus:border-transparent prose prose-lg max-w-none"
            style={{
              fontFamily: 'var(--font-body)',
              lineHeight: '1.7',
              fontSize: '16px'
            }}
            data-placeholder={placeholder}
          />
          
          {content === '' && (
            <div className="absolute inset-6 pointer-events-none">
              <div className="p-6 text-muted-foreground text-lg">
                {placeholder}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Focus Mode Toggle */}
      <div className="hidden lg:block fixed bottom-6 left-1/2 transform -translate-x-1/2">
        <div className="bg-card border border-border rounded-full px-4 py-2 shadow-lg">
          <div className="flex items-center space-x-3 text-sm">
            <Icon name="Focus" size={16} className="text-muted-foreground" />
            <span className="text-muted-foreground">Press F11 for focus mode</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default WritingArea;