import React from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Image from '../../../components/AppImage';

const PreviewModal = ({ isOpen, onClose, story, chapters, activeChapter }) => {
  if (!isOpen) return null;

  const currentChapter = chapters?.find(ch => ch?.id === activeChapter);

  return (
    <div className="fixed inset-0 z-50 bg-background/80 backdrop-blur-sm">
      <div className="fixed inset-4 bg-card border border-border rounded-lg shadow-lg overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-border">
          <div className="flex items-center space-x-3">
            <Icon name="Eye" size={20} className="text-primary" />
            <h2 className="font-heading font-semibold text-lg text-card-foreground">
              Story Preview
            </h2>
          </div>
          <Button variant="ghost" size="icon" onClick={onClose}>
            <Icon name="X" size={20} />
          </Button>
        </div>

        {/* Preview Content */}
        <div className="flex-1 overflow-hidden">
          <div className="h-full overflow-y-auto">
            <div className="max-w-4xl mx-auto p-8">
              {/* Story Header */}
              <div className="text-center mb-8">
                {story?.coverImage && (
                  <div className="w-48 h-64 mx-auto mb-6 rounded-lg overflow-hidden shadow-lg">
                    <Image
                      src={story?.coverImage}
                      alt={story?.title}
                      className="w-full h-full object-cover"
                    />
                  </div>
                )}
                <h1 className="font-heading font-bold text-3xl text-foreground mb-2">
                  {story?.title || 'Untitled Story'}
                </h1>
                {story?.description && (
                  <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
                    {story?.description}
                  </p>
                )}
                <div className="flex items-center justify-center space-x-4 mt-4 text-sm text-muted-foreground">
                  {story?.genre && (
                    <span className="px-3 py-1 bg-secondary text-secondary-foreground rounded-full">
                      {story?.genre}
                    </span>
                  )}
                  <span>{story?.estimatedReadingTime} min read</span>
                  <span>{chapters?.reduce((total, ch) => total + ch?.wordCount, 0)} words</span>
                </div>
              </div>

              {/* Chapter Navigation */}
              {chapters?.length > 1 && (
                <div className="flex items-center justify-center space-x-2 mb-8">
                  {chapters?.map((chapter, index) => (
                    <button
                      key={chapter?.id}
                      className={`px-3 py-1 rounded-md text-sm transition-colors ${
                        chapter?.id === activeChapter
                          ? 'bg-primary text-primary-foreground'
                          : 'bg-muted text-muted-foreground hover:bg-muted/80'
                      }`}
                    >
                      Chapter {index + 1}
                    </button>
                  ))}
                </div>
              )}

              {/* Chapter Content */}
              {currentChapter && (
                <div className="prose prose-lg max-w-none">
                  <h2 className="font-heading font-semibold text-2xl text-foreground mb-6">
                    {currentChapter?.title || `Chapter ${chapters?.findIndex(ch => ch?.id === activeChapter) + 1}`}
                  </h2>
                  <div
                    className="text-foreground leading-relaxed"
                    dangerouslySetInnerHTML={{ __html: currentChapter?.content }}
                  />
                </div>
              )}

              {/* Chapter Navigation Buttons */}
              <div className="flex items-center justify-between mt-12 pt-8 border-t border-border">
                <Button
                  variant="outline"
                  disabled={chapters?.findIndex(ch => ch?.id === activeChapter) === 0}
                  className="flex items-center space-x-2"
                >
                  <Icon name="ChevronLeft" size={16} />
                  <span>Previous Chapter</span>
                </Button>
                <Button
                  variant="outline"
                  disabled={chapters?.findIndex(ch => ch?.id === activeChapter) === chapters?.length - 1}
                  className="flex items-center space-x-2"
                >
                  <span>Next Chapter</span>
                  <Icon name="ChevronRight" size={16} />
                </Button>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-border bg-muted/50">
          <div className="flex items-center justify-between">
            <div className="text-sm text-muted-foreground">
              Preview mode - Changes are not saved automatically
            </div>
            <div className="flex items-center space-x-2">
              <Button variant="outline" onClick={onClose}>
                Close Preview
              </Button>
              <Button>
                <Icon name="Share" size={16} className="mr-2" />
                Share Story
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PreviewModal;