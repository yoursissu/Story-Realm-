import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import ChapterNavigation from './components/ChapterNavigation';
import EditorToolbar from './components/EditorToolbar';
import WritingArea from './components/WritingArea';
import StoryMetadata from './components/StoryMetadata';
import PreviewModal from './components/PreviewModal';
import CollaborationPanel from './components/CollaborationPanel';
import VersionHistory from './components/VersionHistory';

const StoryCreationEditor = () => {
  const navigate = useNavigate();
  
  // Story state
  const [story, setStory] = useState({
    id: 1,
    title: "The Chronicles of Eldoria",
    description: "An epic fantasy adventure following a young mage\'s journey to save her realm from an ancient darkness that threatens to consume everything she holds dear.",
    genre: "fantasy",
    status: "in-progress",
    coverImage: "https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=400",
    tags: ["fantasy", "magic", "adventure", "coming-of-age"],
    targetAudience: "young-adult",
    language: "English",
    estimatedReadingTime: 45,
    createdAt: new Date(Date.now() - 86400000 * 7),
    lastModified: new Date()
  });

  // Chapters state
  const [chapters, setChapters] = useState([
    {
      id: 1,
      title: "The Awakening",
      content: `<h2>Chapter 1: The Awakening</h2>\n\n<p>The morning mist clung to the cobblestone streets of Eldoria like a shroud, obscuring the ancient towers that pierced the sky. Lyra Moonwhisper pressed her face against the cold window of her dormitory, watching as the first rays of sunlight began to burn away the ethereal veil.</p>\n\n<p>Today was different. She could feel it in the very air she breathed, a tingling sensation that made her fingertips spark with an energy she had never experienced before. The Academy of Mystical Arts had been her home for three years, but this morning, everything felt new and strange.</p>\n\n<p>"Lyra, you're going to be late for Professor Thornwick's class again," called her roommate, Aria, from across the room. The red-haired girl was already dressed in her academy robes, her books neatly stacked and ready.</p>\n\n<p>But Lyra couldn't move. The sparks dancing between her fingers were growing stronger, more vibrant. They pulsed with a silver light that seemed to respond to her heartbeat. This wasn't the simple cantrip magic they had been learning in their first-year classes. This was something else entirely.</p>\n\n<p>Something powerful.</p>\n\n<p>Something dangerous.</p>`,
      wordCount: 187,
      lastModified: new Date(Date.now() - 3600000)
    },
    {
      id: 2,
      title: "The Discovery",
      content: `<h2>Chapter 2: The Discovery</h2>\n\n<p>The ancient library of the Academy stretched endlessly in all directions, its towering shelves disappearing into shadows that seemed to move of their own accord. Lyra had always found solace among the dusty tomes and forgotten scrolls, but today she searched with desperate purpose.</p>\n\n<p>The incident in Professor Thornwick's class had left her shaken. When she had attempted the simple illumination spell they had practiced dozens of times before, instead of the gentle golden glow expected, her magic had erupted in a brilliant silver flame that had scorched the practice dummy to ash in seconds.</p>\n\n<p>The other students had stared in a mixture of awe and fear. Professor Thornwick had dismissed the class early, his weathered face grave with concern. "Miss Moonwhisper," he had said quietly, "perhaps you should visit the Restricted Section. There are... older texts there that might provide some insight."</p>\n\n<p>Now, as she traced her fingers along the spines of books that predated the Academy itself, Lyra felt that familiar tingling in her fingertips. The silver sparks seemed to be drawn to one particular volume, bound in midnight-blue leather with silver clasps that gleamed despite their obvious age.</p>\n\n<p>The title, written in an ancient script she somehow understood, read: "The Lunar Codex: A Guide to Moon Magic and Its Practitioners."</p>`,
      wordCount: 234,
      lastModified: new Date(Date.now() - 7200000)
    },
    {
      id: 3,
      title: "The Revelation",
      content: `<h2>Chapter 3: The Revelation</h2>\n\n<p>The pages of the Lunar Codex seemed to glow with their own inner light as Lyra carefully turned each one. The text spoke of a rare form of magic, one that drew its power directly from the moon itself. Moon mages, the book explained, were born perhaps once in a generation, their abilities manifesting during times of great celestial alignment.</p>\n\n<p>Lyra's breath caught in her throat as she read about the signs: the silver sparks, the uncontrollable surges of power, the way magic seemed to respond to emotions rather than careful incantation. Everything described her experiences perfectly.</p>\n\n<p>But there was more. The book spoke of a prophecy, written in the earliest days of the Academy:</p>\n\n<blockquote><em>"When shadow threatens to devour light, and ancient evils stir in forgotten depths, a child of the moon shall rise. Born of silver fire and starlight dreams, she shall stand as guardian between the worlds, wielding power that flows from the celestial dance itself."</em></blockquote>\n\n<p>A chill ran down Lyra's spine. Outside the library windows, storm clouds were gathering, blocking out the afternoon sun and casting the world into an unnatural twilight. In the distance, she could hear the tolling of the Academy's warning bells.</p>\n\n<p>Something was coming.</p>\n\n<p>And somehow, she knew her life would never be the same.</p>`,
      wordCount: 256,
      lastModified: new Date(Date.now() - 10800000)
    }
  ]);

  // Editor state
  const [activeChapter, setActiveChapter] = useState(1);
  const [isSaving, setIsSaving] = useState(false);
  const [lastSaved, setLastSaved] = useState(new Date());
  const [isPreviewOpen, setIsPreviewOpen] = useState(false);
  const [metadataPanelVisible, setMetadataPanelVisible] = useState(false);
  const [collaborationPanelVisible, setCollaborationPanelVisible] = useState(false);
  const [versionHistoryVisible, setVersionHistoryVisible] = useState(false);

  // Auto-save functionality
  useEffect(() => {
    const autoSave = setInterval(() => {
      handleSave(true);
    }, 300000); // Auto-save every 5 minutes

    return () => clearInterval(autoSave);
  }, []);

  // Calculate word count and reading time
  const calculateStats = useCallback((content) => {
    const text = content?.replace(/<[^>]*>/g, ''); // Remove HTML tags
    const words = text?.trim()?.split(/\s+/)?.filter(word => word?.length > 0);
    const wordCount = words?.length;
    const readingTime = Math.ceil(wordCount / 200); // Average reading speed
    return { wordCount, readingTime };
  }, []);

  // Update story metadata
  const handleMetadataUpdate = (updatedMetadata) => {
    setStory(prev => ({
      ...prev,
      ...updatedMetadata,
      lastModified: new Date()
    }));
  };

  // Chapter management
  const handleChapterSelect = (chapterId) => {
    setActiveChapter(chapterId);
  };

  const handleAddChapter = () => {
    const newChapter = {
      id: Date.now(),
      title: `Chapter ${chapters?.length + 1}`,
      content: '',
      wordCount: 0,
      lastModified: new Date()
    };
    setChapters(prev => [...prev, newChapter]);
    setActiveChapter(newChapter?.id);
  };

  const handleDeleteChapter = (chapterId) => {
    if (chapters?.length > 1) {
      setChapters(prev => prev?.filter(ch => ch?.id !== chapterId));
      if (activeChapter === chapterId) {
        setActiveChapter(chapters?.[0]?.id);
      }
    }
  };

  const handleReorderChapters = (reorderedChapters) => {
    setChapters(reorderedChapters);
  };

  // Content editing
  const handleContentChange = (content) => {
    const stats = calculateStats(content);
    setChapters(prev => prev?.map(ch => 
      ch?.id === activeChapter 
        ? { ...ch, content, wordCount: stats?.wordCount, lastModified: new Date() }
        : ch
    ));
    
    // Update story reading time
    const totalWords = chapters?.reduce((total, ch) => 
      ch?.id === activeChapter ? total + stats?.wordCount : total + ch?.wordCount, 0
    );
    setStory(prev => ({
      ...prev,
      estimatedReadingTime: Math.ceil(totalWords / 200),
      lastModified: new Date()
    }));
  };

  // Formatting functions
  const handleFormat = (action) => {
    document.execCommand(action, false, null);
  };

  const handleInsertMedia = (type) => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = type === 'image' ? 'image/*' : type === 'audio' ? 'audio/*' : 'video/*';
    input.onchange = (e) => {
      const file = e?.target?.files?.[0];
      if (file) {
        const reader = new FileReader();
        reader.onload = (event) => {
          const mediaElement = type === 'image' 
            ? `<img src="${event?.target?.result}" alt="Uploaded ${type}" style="max-width: 100%; height: auto;" />`
            : type === 'audio'
            ? `<audio controls><source src="${event?.target?.result}" type="${file?.type}">Your browser does not support the audio element.</audio>`
            : `<video controls style="max-width: 100%; height: auto;"><source src="${event?.target?.result}" type="${file?.type}">Your browser does not support the video element.</video>`;
          
          document.execCommand('insertHTML', false, mediaElement);
        };
        reader?.readAsDataURL(file);
      }
    };
    input?.click();
  };

  // Save functionality
  const handleSave = async (isAutoSave = false) => {
    setIsSaving(true);
    
    // Simulate save operation
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    setLastSaved(new Date());
    setIsSaving(false);
    
    if (!isAutoSave) {
      // Show success message for manual saves
      console.log('Story saved successfully!');
    }
  };

  // Preview functionality
  const handlePreview = () => {
    setIsPreviewOpen(true);
  };

  // Collaboration functions
  const handleInviteCollaborator = (email) => {
    console.log('Inviting collaborator:', email);
  };

  const handleAddComment = (comment) => {
    console.log('Adding comment:', comment);
  };

  // Version history functions
  const handleRestoreVersion = (versionId) => {
    console.log('Restoring version:', versionId);
  };

  const handleCompareVersions = (versionIds) => {
    console.log('Comparing versions:', versionIds);
  };

  const currentChapter = chapters?.find(ch => ch?.id === activeChapter);
  const totalWordCount = chapters?.reduce((total, ch) => total + ch?.wordCount, 0);
  const estimatedReadingTime = Math.ceil(totalWordCount / 200);

  return (
    <div className="min-h-screen bg-background">
      <div className="flex h-screen">
        {/* Chapter Navigation */}
        <ChapterNavigation
          chapters={chapters}
          activeChapter={activeChapter}
          onChapterSelect={handleChapterSelect}
          onAddChapter={handleAddChapter}
          onDeleteChapter={handleDeleteChapter}
          onReorderChapters={handleReorderChapters}
        />

        {/* Main Editor Area */}
        <div className="flex-1 flex flex-col">
          <EditorToolbar
            onFormat={handleFormat}
            onInsertMedia={handleInsertMedia}
            onPreview={handlePreview}
            onSave={() => handleSave(false)}
            isSaving={isSaving}
            lastSaved={lastSaved}
          />

          <WritingArea
            content={currentChapter?.content || ''}
            onChange={handleContentChange}
            wordCount={currentChapter?.wordCount || 0}
            readingTime={Math.ceil((currentChapter?.wordCount || 0) / 200)}
            placeholder="Begin writing your story here..."
          />
        </div>

        {/* Side Panels */}
        {metadataPanelVisible && (
          <StoryMetadata
            metadata={story}
            onUpdate={handleMetadataUpdate}
            isVisible={metadataPanelVisible}
            onToggle={() => setMetadataPanelVisible(!metadataPanelVisible)}
          />
        )}

        {collaborationPanelVisible && (
          <CollaborationPanel
            collaborators={[]}
            comments={[]}
            onInviteCollaborator={handleInviteCollaborator}
            onAddComment={handleAddComment}
            isVisible={collaborationPanelVisible}
            onToggle={() => setCollaborationPanelVisible(!collaborationPanelVisible)}
          />
        )}

        {versionHistoryVisible && (
          <VersionHistory
            versions={[]}
            onRestore={handleRestoreVersion}
            onCompare={handleCompareVersions}
            isVisible={versionHistoryVisible}
            onToggle={() => setVersionHistoryVisible(!versionHistoryVisible)}
          />
        )}
      </div>

      {/* Mobile Panel Toggles */}
      <div className="lg:hidden fixed top-20 right-4 z-30 flex flex-col space-y-2">
        <StoryMetadata
          metadata={story}
          onUpdate={handleMetadataUpdate}
          isVisible={metadataPanelVisible}
          onToggle={() => setMetadataPanelVisible(!metadataPanelVisible)}
        />
        <CollaborationPanel
          collaborators={[]}
          comments={[]}
          onInviteCollaborator={handleInviteCollaborator}
          onAddComment={handleAddComment}
          isVisible={collaborationPanelVisible}
          onToggle={() => setCollaborationPanelVisible(!collaborationPanelVisible)}
        />
        <VersionHistory
          versions={[]}
          onRestore={handleRestoreVersion}
          onCompare={handleCompareVersions}
          isVisible={versionHistoryVisible}
          onToggle={() => setVersionHistoryVisible(!versionHistoryVisible)}
        />
      </div>

      {/* Preview Modal */}
      <PreviewModal
        isOpen={isPreviewOpen}
        onClose={() => setIsPreviewOpen(false)}
        story={story}
        chapters={chapters}
        activeChapter={activeChapter}
      />
    </div>
  );
};

export default StoryCreationEditor;