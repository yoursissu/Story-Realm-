import React, { useState, useEffect, useCallback } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import StoryHeader from './components/StoryHeader';
import ReadingControls from './components/ReadingControls';
import StoryContent from './components/StoryContent';
import ReadingSettings from './components/ReadingSettings';
import CommentsPanel from './components/CommentsPanel';
import ChapterNavigation from './components/ChapterNavigation';
import ShareModal from './components/ShareModal';

const InteractiveStoryReader = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  
  // Story state
  const [story, setStory] = useState(null);
  const [currentChapter, setCurrentChapter] = useState(1);
  const [chapters, setChapters] = useState([]);
  
  // UI state
  const [headerVisible, setHeaderVisible] = useState(true);
  const [controlsVisible, setControlsVisible] = useState(false);
  const [settingsVisible, setSettingsVisible] = useState(false);
  const [commentsVisible, setCommentsVisible] = useState(false);
  const [navigationVisible, setNavigationVisible] = useState(false);
  const [shareModalVisible, setShareModalVisible] = useState(false);
  
  // Reading preferences
  const [fontSize, setFontSize] = useState(18);
  const [lineHeight, setLineHeight] = useState(1.6);
  const [theme, setTheme] = useState('light');
  const [fontFamily, setFontFamily] = useState('serif');
  
  // Interaction state
  const [bookmarkedChapters, setBookmarkedChapters] = useState(new Set());
  const [readingProgress, setReadingProgress] = useState({});
  const [lastScrollY, setLastScrollY] = useState(0);

  // Mock story data
  const mockStory = {
    id: "epic-fantasy-adventure",
    title: "The Chronicles of Eldoria: The Last Guardian",
    author: {
      name: "Sarah Mitchell",
      avatar: "https://images.unsplash.com/photo-1494790108755-2616b612b786?w=150&h=150&fit=crop"
    },
    description: "An epic fantasy adventure following Lyra, the last guardian of an ancient magical realm, as she embarks on a perilous journey to save her world from eternal darkness.",
    genre: "Fantasy",
    rating: 4.8,
    totalChapters: 12,
    estimatedReadTime: "2h 30m",
    coverImage: "https://images.unsplash.com/photo-1518709268805-4e9042af2176?w=800&h=600&fit=crop"
  };

  const mockChapters = [
    {
      id: 1,
      title: "The Awakening",
      content: `The morning mist clung to the ancient stones of Eldoria like whispered secrets from a forgotten age. Lyra stood at the edge of the Whispering Cliffs, her emerald eyes scanning the horizon where the first rays of dawn painted the sky in shades of gold and crimson.\n\nShe had always known this day would come. The dreams had been growing stronger, more vivid, pulling her consciousness into realms she had never seen yet somehow remembered. The pendant around her neck—a gift from her grandmother—pulsed with a warm, otherworldly light.\n\n"The time of choosing approaches," her grandmother's voice echoed in her memory. "When the old magic stirs, the guardian must rise."\n\nLyra closed her eyes and felt the ancient power flowing through the ley lines beneath her feet. The very earth seemed to hum with anticipation. Something was coming, something that would change everything she thought she knew about her world and her destiny.\n\nAs she opened her eyes, a figure emerged from the morning mist—tall, cloaked, and unmistakably magical. The stranger's presence sent ripples through the fabric of reality itself.`,
      wordCount: 1247,
      image: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=800&h=400&fit=crop",
      views: 2847,
      likes: 156,
      bookmarks: 89,
      comments: 23,
      isCompleted: true,
      isBookmarked: false,
      hasChoices: true,
      authorNote: "Welcome to the world of Eldoria! This opening chapter sets the stage for Lyra's incredible journey. I've been working on this world for over three years, and I'm excited to finally share it with you.",
      interactiveElements: [
        {
          type: 'choice',
          question: 'How should Lyra respond to the mysterious stranger?',
          options: [
            {
              id: 'approach',
              text: 'Approach the stranger with caution',
              consequence: 'This choice leads to immediate dialogue and potential alliance'
            },
            {
              id: 'hide',
              text: 'Hide and observe from a distance',
              consequence: 'This choice provides more information but delays the encounter'
            },
            {
              id: 'challenge',
              text: 'Challenge the stranger boldly',
              consequence: 'This choice demonstrates courage but may provoke conflict'
            }
          ]
        }
      ]
    },
    {
      id: 2,
      title: "The Stranger\'s Warning",
      content: `The cloaked figure moved with fluid grace, each step seeming to bend the very air around them. As they drew closer, Lyra could see that beneath the hood lay features both ancient and ageless—eyes that held the wisdom of centuries and the weight of terrible knowledge.\n\n"Guardian," the stranger spoke, their voice carrying the resonance of distant thunder. "The Shadowlands stir. The Void Seekers have found a way to breach the barriers your ancestors died to maintain."\n\nLyra's hand instinctively moved to her pendant, which now pulsed with urgent crimson light. She had heard whispers of the Void Seekers in her grandmother's stories—beings of pure darkness who sought to consume all light and life from the world.\n\n"I don't understand," Lyra said, though even as the words left her lips, she knew they weren't entirely true. Deep within her soul, ancient memories were awakening. "I'm just a village girl. I'm not a guardian of anything."\n\nThe stranger's laugh was like wind through autumn leaves. "Your bloodline carries the power of the First Guardians. The magic in your veins is older than the kingdoms of men, older than the great libraries of the elves. You are the last of your kind, Lyra of Eldoria, and the fate of all realms rests upon your shoulders."\n\nAs if summoned by the stranger's words, the sky began to darken unnaturally. In the distance, Lyra could see shadows moving against the natural order of things—shadows that moved independently of any object that might cast them.`,
      wordCount: 1456,
      image: "https://images.unsplash.com/photo-1518709268805-4e9042af2176?w=800&h=400&fit=crop",
      views: 2234,
      likes: 134,
      bookmarks: 67,
      comments: 18,
      isCompleted: true,
      isBookmarked: true,
      hasChoices: false,
      authorNote: "The mythology of the Guardians is central to this story. I drew inspiration from Celtic and Norse mythology to create the magical system you\'ll see throughout the series."
    },
    {
      id: 3,
      title: "The First Trial",
      content: `The journey to the Temple of Echoing Stones took three days through terrain that seemed to shift and change with each step. Lyra's companion, who had revealed himself to be Theron, the last of the Mage-Knights, proved to be both guide and teacher.\n\n"Magic is not about power," Theron explained as they made camp on the second night. "It is about understanding the connections between all things. The Void Seekers have forgotten this truth, and that is why they can only destroy, never create."\n\nLyra practiced the basic exercises he taught her, feeling the energy flow through her body like liquid starlight. Each success brought with it flashes of memory—not her own, but those of the Guardians who had come before her.\n\nOn the morning of the third day, they reached the temple. It was not the grand structure Lyra had imagined, but rather a simple circle of standing stones, each one carved with symbols that seemed to shift and dance when she wasn't looking directly at them.\n\n"Your first trial awaits within," Theron said solemnly. "I cannot accompany you beyond this point. The temple will test not just your magical abilities, but your heart, your courage, and your wisdom. Many who enter never return."\n\nLyra stepped forward, her pendant now blazing with pure white light. As she crossed the threshold between the stones, the world around her dissolved into swirling mists of possibility.`,
      wordCount: 1189,
      image: "https://images.unsplash.com/photo-1551632436-cbf8dd35adfa?w=800&h=400&fit=crop",
      views: 1987,
      likes: 112,
      bookmarks: 45,
      comments: 15,
      isCompleted: false,
      isBookmarked: false,
      hasChoices: true,
      interactiveElements: [
        {
          type: 'media',title: 'Temple Ambience',description: 'Listen to the mystical sounds of the Temple of Echoing Stones',mediaType: 'audio',url: '/audio/temple-ambience.mp3'
        }
      ]
    }
  ];

  const mockComments = [
    {
      id: 1,
      user: {
        name: "BookLover92",
        avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop&crop=face"
      },
      text: "This is absolutely incredible! The world-building is so immersive. I can practically see the Whispering Cliffs in my mind.",
      timestamp: new Date(Date.now() - 1800000), // 30 minutes ago
      likes: 12,
      replies: [
        {
          id: 11,
          user: {
            name: "FantasyFan",
            avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150&h=150&fit=crop&crop=face"
          },
          text: "I completely agree! Sarah\'s descriptions are so vivid.",
          timestamp: new Date(Date.now() - 1200000) // 20 minutes ago
        }
      ]
    },
    {
      id: 2,
      user: {
        name: "MagicReader",
        avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face"
      },
      text: "The magic system is so well thought out. I love how it\'s connected to understanding rather than just raw power.",
      timestamp: new Date(Date.now() - 3600000), // 1 hour ago
      likes: 8,
      replies: []
    },
    {
      id: 3,
      user: {
        name: "StorySeeker",
        avatar: "https://images.unsplash.com/photo-1494790108755-2616b612b786?w=150&h=150&fit=crop&crop=face"
      },
      text: "Can\'t wait to see what happens in the temple! The interactive choices make this so much more engaging than regular books.",
      timestamp: new Date(Date.now() - 7200000), // 2 hours ago
      likes: 15,
      replies: []
    }
  ];

  // Initialize story data
  useEffect(() => {
    const storyId = searchParams?.get('story') || 'epic-fantasy-adventure';
    const chapterParam = searchParams?.get('chapter');
    
    setStory(mockStory);
    setChapters(mockChapters);
    
    if (chapterParam) {
      setCurrentChapter(parseInt(chapterParam));
    }

    // Load reading preferences from localStorage
    const savedFontSize = localStorage.getItem('reader-font-size');
    const savedLineHeight = localStorage.getItem('reader-line-height');
    const savedTheme = localStorage.getItem('reader-theme');
    const savedFontFamily = localStorage.getItem('reader-font-family');

    if (savedFontSize) setFontSize(parseInt(savedFontSize));
    if (savedLineHeight) setLineHeight(parseFloat(savedLineHeight));
    if (savedTheme) setTheme(savedTheme);
    if (savedFontFamily) setFontFamily(savedFontFamily);
  }, [searchParams]);

  // Handle scroll for header visibility
  useEffect(() => {
    const handleScroll = () => {
      const currentScrollY = window.scrollY;
      
      if (currentScrollY > lastScrollY && currentScrollY > 100) {
        setHeaderVisible(false);
      } else {
        setHeaderVisible(true);
      }
      
      setLastScrollY(currentScrollY);
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, [lastScrollY]);

  // Save reading preferences
  useEffect(() => {
    localStorage.setItem('reader-font-size', fontSize?.toString());
    localStorage.setItem('reader-line-height', lineHeight?.toString());
    localStorage.setItem('reader-theme', theme);
    localStorage.setItem('reader-font-family', fontFamily);
  }, [fontSize, lineHeight, theme, fontFamily]);

  const handleChapterChange = useCallback((newChapter) => {
    if (newChapter >= 1 && newChapter <= chapters?.length) {
      setCurrentChapter(newChapter);
      setControlsVisible(false); // Hide controls when changing chapters
      window.scrollTo({ top: 0, behavior: 'smooth' });
      
      // Update URL
      const newSearchParams = new URLSearchParams(searchParams);
      newSearchParams?.set('chapter', newChapter?.toString());
      navigate(`?${newSearchParams?.toString()}`, { replace: true });
    }
  }, [chapters?.length, navigate, searchParams]);

  const handleContentTap = useCallback(() => {
    setControlsVisible(prev => !prev);
  }, []);

  const handleAddToLibrary = useCallback((actionId) => {
    console.log('Adding to library:', actionId);
    // Handle different library actions
    switch (actionId) {
      case 'reading': console.log('Added to reading list');
        break;
      case 'read-later': console.log('Added to read later list');
        break;
      case 'completed':
        console.log('Marked as completed');
        break;
      case 'trash': console.log('Moved to trash');
        break;
      case 'create-folder': console.log('Opening folder creation dialog');
        break;
      default:
        break;
    }
  }, []);

  const handleToggleBookmark = useCallback(() => {
    setBookmarkedChapters(prev => {
      const newSet = new Set(prev);
      if (newSet?.has(currentChapter)) {
        newSet?.delete(currentChapter);
      } else {
        newSet?.add(currentChapter);
      }
      return newSet;
    });
  }, [currentChapter]);

  const handleChoiceSelect = useCallback((choiceId, choiceText) => {
    console.log('Choice selected:', choiceId, choiceText);
  }, []);

  const handleMediaInteraction = useCallback((mediaType, url) => {
    console.log('Media interaction:', mediaType, url);
  }, []);

  const handleAddComment = useCallback((text, replyToId = null) => {
    console.log('Adding comment:', text, replyToId);
  }, []);

  const handleShare = useCallback(() => {
    setShareModalVisible(true);
  }, []);

  const handleToggleContents = useCallback(() => {
    setNavigationVisible(true);
    setControlsVisible(false);
  }, []);

  const currentChapterData = chapters?.[currentChapter - 1];
  const isBookmarked = bookmarkedChapters?.has(currentChapter);

  return (
    <div className={`min-h-screen ${
      theme === 'dark' ? 'bg-gray-900' : 
      theme === 'sepia'? 'bg-amber-50' : 'bg-background'
    }`}>
      {/* Story Header */}
      <StoryHeader
        story={story}
        currentChapter={currentChapter}
        totalChapters={chapters?.length}
        isVisible={headerVisible}
        onToggleSettings={() => setSettingsVisible(true)}
      />

      {/* Main Content */}
      <main className={`${headerVisible ? 'pt-20' : 'pt-4'} ${controlsVisible ? 'pb-48' : 'pb-20'} transition-all duration-300`}>
        <StoryContent
          chapter={currentChapterData}
          fontSize={fontSize}
          lineHeight={lineHeight}
          theme={theme}
          onChoiceSelect={handleChoiceSelect}
          onMediaInteraction={handleMediaInteraction}
          onContentTap={handleContentTap}
        />
      </main>

      {/* Reading Controls - Only visible on tap */}
      <ReadingControls
        isVisible={controlsVisible}
        onPreviousChapter={() => handleChapterChange(currentChapter - 1)}
        onNextChapter={() => handleChapterChange(currentChapter + 1)}
        canGoPrevious={currentChapter > 1}
        canGoNext={currentChapter < chapters?.length}
        onToggleComments={() => setCommentsVisible(true)}
        commentsVisible={commentsVisible}
        onShare={handleShare}
        onToggleContents={handleToggleContents}
        currentChapter={currentChapter}
        fontSize={fontSize}
        onFontSizeChange={setFontSize}
        lineHeight={lineHeight}
        onLineHeightChange={setLineHeight}
        theme={theme}
        onThemeChange={setTheme}
        fontFamily={fontFamily}
        onFontFamilyChange={setFontFamily}
        onAddToLibrary={handleAddToLibrary}
      />

      {/* Reading Settings Modal */}
      <ReadingSettings
        isVisible={settingsVisible}
        onClose={() => setSettingsVisible(false)}
        fontSize={fontSize}
        onFontSizeChange={setFontSize}
        lineHeight={lineHeight}
        onLineHeightChange={setLineHeight}
        theme={theme}
        onThemeChange={setTheme}
        fontFamily={fontFamily}
        onFontFamilyChange={setFontFamily}
      />

      {/* Comments Panel */}
      <CommentsPanel
        isVisible={commentsVisible}
        onClose={() => setCommentsVisible(false)}
        comments={mockComments}
        onAddComment={handleAddComment}
      />

      {/* Chapter Navigation */}
      <ChapterNavigation
        chapters={chapters}
        currentChapter={currentChapter}
        onChapterSelect={handleChapterChange}
        isVisible={navigationVisible}
        onClose={() => setNavigationVisible(false)}
      />

      {/* Share Modal */}
      <ShareModal
        isVisible={shareModalVisible}
        onClose={() => setShareModalVisible(false)}
        story={story}
        currentChapter={currentChapter}
      />
    </div>
  );
};

export default InteractiveStoryReader;
import React, { useState, useEffect, useCallback } from 'react';
// ... other imports
import GlossaryModal from './components/GlossaryModal'; // Import the new modal

const InteractiveStoryReader = () => {
  // ... existing states
  const [glossaryModalVisible, setGlossaryModalVisible] = useState(false);
  const [selectedTextForGlossary, setSelectedTextForGlossary] = useState('');
  const [glossaryTerms, setGlossaryTerms] = useState([
      { id: 1, original: '入门', replacement: 'Beginner', global: true, caseSensitive: false },
      { id: 2, original: '天武域', replacement: 'Tianwu Region', global: true, caseSensitive: false }
  ]);

  // ... existing useEffects and handlers

  const handleAddTermRequest = (selectedText) => {
    setSelectedTextForGlossary(selectedText);
    setGlossaryModalVisible(true);
  };
  
  const handleAddTerm = (newTerm) => {
    setGlossaryTerms(prev => [...prev, newTerm]);
  };

  const handleDeleteTerm = (termId) => {
    setGlossaryTerms(prev => prev.filter(term => term.id !== termId));
  };

  const currentChapterData = chapters?.[currentChapter - 1];

  return (
    <div className={`min-h-screen ${
      theme === 'dark' ? 'bg-gray-900' : 
      theme === 'sepia'? 'bg-amber-50' : 'bg-background'
    }`}>
      {/* Story Header ... */}
      
      <main className={`${headerVisible ? 'pt-20' : 'pt-4'} pb-20 transition-all duration-300`}>
        <StoryContent
          chapter={currentChapterData}
          fontSize={fontSize}
          lineHeight={lineHeight}
          theme={theme}
          onChoiceSelect={handleChoiceSelect}
          onMediaInteraction={handleMediaInteraction}
          onContentTap={handleContentTap}
          glossaryTerms={glossaryTerms}
          onAddTermRequest={handleAddTermRequest}
        />
      </main>

      {/* Reading Controls ... */}

      {/* Modals */}
      <GlossaryModal
        isVisible={glossaryModalVisible}
        onClose={() => setGlossaryModalVisible(false)}
        terms={glossaryTerms}
        onAddTerm={handleAddTerm}
        onDeleteTerm={handleDeleteTerm}
        selectedText={selectedTextForGlossary}
      />
      
      {/* Other modals (ReadingSettings, CommentsPanel, etc.) ... */}
    </div>
  );
};

export default InteractiveStoryReader;