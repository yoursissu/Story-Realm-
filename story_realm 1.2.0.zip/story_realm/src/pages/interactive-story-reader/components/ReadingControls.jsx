import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const ReadingControls = ({ 
  isVisible,
  onPreviousChapter, 
  onNextChapter, 
  canGoPrevious, 
  canGoNext,
  onToggleComments,
  commentsVisible,
  onShare,
  onToggleContents,
  currentChapter,
  fontSize,
  onFontSizeChange,
  lineHeight,
  onLineHeightChange,
  theme,
  onThemeChange,
  fontFamily,
  onFontFamilyChange,
  onAddToLibrary
}) => {
  const [showSettings, setShowSettings] = useState(false);
  const [showLibraryModal, setShowLibraryModal] = useState(false);

  const fontSizes = [14, 16, 18, 20, 22, 24];
  const themes = [
    { id: 'light', name: 'Light', icon: 'Sun' },
    { id: 'dark', name: 'Dark', icon: 'Moon' },
    { id: 'sepia', name: 'Sepia', icon: 'Coffee' }
  ];
  const fontFamilies = [
    { id: 'serif', name: 'Serif', family: 'Georgia, serif' },
    { id: 'sans', name: 'Sans Serif', family: 'Inter, sans-serif' },
    { id: 'mono', name: 'Monospace', family: 'JetBrains Mono, monospace' }
  ];

  const libraryOptions = [
    { id: 'reading', name: 'Reading', icon: 'Book', color: 'text-blue-600' },
    { id: 'read-later', name: 'Read Later', icon: 'Clock', color: 'text-orange-600' },
    { id: 'completed', name: 'Completed', icon: 'CheckCircle2', color: 'text-green-600' },
    { id: 'trash', name: 'Trash', icon: 'Trash2', color: 'text-red-600' },
    { id: 'create-folder', name: 'Create Folder', icon: 'FolderPlus', color: 'text-purple-600' }
  ];

  const handleLibraryAction = (actionId) => {
    onAddToLibrary?.(actionId);
    setShowLibraryModal(false);
  };

  if (!isVisible) return null;

  return (
    <>
      {/* Main Controls Overlay */}
      <div className="fixed inset-x-0 bottom-0 z-50 bg-background/95 backdrop-blur-sm border-t border-border">
        <div className="container mx-auto px-4 py-4">
          {/* Navigation Row */}
          <div className="flex items-center justify-between mb-4">
            <Button
              variant="ghost"
              size="sm"
              onClick={onPreviousChapter}
              disabled={!canGoPrevious}
              className="flex items-center space-x-2"
            >
              <Icon name="ChevronLeft" size={16} />
              <span className="hidden sm:inline">Prev</span>
            </Button>

            <div className="text-sm font-medium px-4 py-2 bg-muted rounded-full">
              Ch. {currentChapter}
            </div>

            <Button
              variant="ghost"
              size="sm"
              onClick={onNextChapter}
              disabled={!canGoNext}
              className="flex items-center space-x-2"
            >
              <span className="hidden sm:inline">Next</span>
              <Icon name="ChevronRight" size={16} />
            </Button>
          </div>

          {/* Main Controls Row */}
          <div className="flex items-center justify-between">
            <Button
              variant="ghost"
              size="sm"
              onClick={onToggleContents}
              className="flex items-center space-x-1"
            >
              <Icon name="List" size={16} />
              <span className="text-sm font-medium">Contents</span>
            </Button>

            <div className="flex items-center space-x-2">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setShowSettings(!showSettings)}
                className="flex items-center space-x-1"
              >
                <Icon name="Settings" size={16} />
                <span className="text-sm font-medium">Settings</span>
              </Button>

              <Button
                variant="ghost"
                size="sm"
                onClick={() => setShowLibraryModal(true)}
                className="flex items-center space-x-1 bg-primary/10 hover:bg-primary/20 text-primary"
              >
                <Icon name="BookmarkPlus" size={16} />
                <span className="text-sm font-medium">Add to Library</span>
              </Button>
            </div>

            <div className="flex items-center space-x-2">
              <Button
                variant="ghost"
                size="icon"
                onClick={onToggleComments}
                className={commentsVisible ? 'text-accent' : ''}
              >
                <Icon name="MessageCircle" size={16} />
              </Button>

              <Button
                variant="ghost"
                size="icon"
                onClick={onShare}
              >
                <Icon name="Share" size={16} />
              </Button>
            </div>
          </div>

          {/* Settings Panel */}
          {showSettings && (
            <div className="mt-4 p-4 bg-muted rounded-lg space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {/* Font Size */}
                <div>
                  <label className="text-xs font-medium mb-2 block">Font Size</label>
                  <div className="flex items-center space-x-2">
                    <input
                      type="range"
                      min={fontSizes?.[0]}
                      max={fontSizes?.[fontSizes?.length - 1]}
                      step="2"
                      value={fontSize}
                      onChange={(e) => onFontSizeChange(parseInt(e?.target?.value))}
                      className="flex-1 h-1 bg-background rounded appearance-none cursor-pointer"
                    />
                    <span className="text-xs w-8">{fontSize}px</span>
                  </div>
                </div>

                {/* Line Height */}
                <div>
                  <label className="text-xs font-medium mb-2 block">Line Spacing</label>
                  <div className="flex items-center space-x-2">
                    <input
                      type="range"
                      min="1.4"
                      max="2.0"
                      step="0.2"
                      value={lineHeight}
                      onChange={(e) => onLineHeightChange(parseFloat(e?.target?.value))}
                      className="flex-1 h-1 bg-background rounded appearance-none cursor-pointer"
                    />
                    <span className="text-xs w-8">{lineHeight}</span>
                  </div>
                </div>

                {/* Theme */}
                <div>
                  <label className="text-xs font-medium mb-2 block">Theme</label>
                  <div className="flex space-x-1">
                    {themes?.map((themeOption) => (
                      <Button
                        key={themeOption?.id}
                        variant={theme === themeOption?.id ? "default" : "outline"}
                        size="sm"
                        onClick={() => onThemeChange(themeOption?.id)}
                        className="flex-1 text-xs h-8"
                      >
                        <Icon name={themeOption?.icon} size={12} />
                      </Button>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Add to Library Modal */}
      {showLibraryModal && (
        <div className="fixed inset-0 z-60 bg-black/50 flex items-center justify-center p-4">
          <div className="bg-background border border-border rounded-lg w-full max-w-sm">
            <div className="flex items-center justify-between p-4 border-b border-border">
              <h3 className="text-lg font-semibold">Add to Library</h3>
              <Button 
                variant="ghost" 
                size="icon" 
                onClick={() => setShowLibraryModal(false)}
              >
                <Icon name="X" size={16} />
              </Button>
            </div>
            <div className="p-4 space-y-2">
              {libraryOptions?.map((option) => (
                <Button
                  key={option?.id}
                  variant="ghost"
                  onClick={() => handleLibraryAction(option?.id)}
                  className="w-full justify-start h-12 text-left"
                >
                  <Icon name={option?.icon} size={16} className={option?.color} />
                  <span className="ml-3">{option?.name}</span>
                </Button>
              ))}
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default ReadingControls;
import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const ReadingControls = ({ 
  isVisible,
  onPreviousChapter, 
  onNextChapter, 
  canGoPrevious, 
  canGoNext,
  onToggleComments,
  onShare,
  onToggleContents,
  currentChapter,
  totalChapters, // Added totalChapters prop
  // ... other props
}) => {
  // ... existing states and functions

  if (!isVisible) return null;

  return (
    <>
      <div className="fixed inset-x-0 bottom-0 z-50 bg-background/95 backdrop-blur-sm border-t border-border">
        <div className="container mx-auto px-4 py-3">
          <div className="flex items-center justify-between">
            <Button
              variant="outline"
              size="default"
              onClick={onPreviousChapter}
              disabled={!canGoPrevious}
            >
              <Icon name="ChevronLeft" size={16} className="mr-2" />
              Prev
            </Button>

            <div className="text-center">
              <div className="text-sm font-medium">
                Ch. {currentChapter} / {totalChapters}
              </div>
              <div className="text-xs text-muted-foreground">
                {totalChapters > 0 ? ((currentChapter / totalChapters) * 100).toFixed(1) : 0}%
              </div>
            </div>

            <Button
              variant="outline"
              size="default"
              onClick={onNextChapter}
              disabled={!canGoNext}
            >
              Next
              <Icon name="ChevronRight" size={16} className="ml-2" />
            </Button>
          </div>
          
          <div className="flex items-center justify-center space-x-4 mt-3 border-t border-border pt-3">
             <Button variant="ghost" size="sm" onClick={onToggleContents}>Contents</Button>
             <Button variant="ghost" size="sm" onClick={() => {/* Edit Terms opens glossary */}}>Edit Terms</Button>
             <Button variant="ghost" size="sm" onClick={() => {/* Add to Library */}}>Add to Library</Button>
          </div>
        </div>
      </div>
    </>
  );
};

export default ReadingControls;