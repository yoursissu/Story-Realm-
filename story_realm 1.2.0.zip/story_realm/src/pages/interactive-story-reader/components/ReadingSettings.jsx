import React from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const ReadingSettings = ({ 
  isVisible, 
  onClose, 
  fontSize, 
  onFontSizeChange, 
  lineHeight, 
  onLineHeightChange, 
  theme, 
  onThemeChange,
  fontFamily,
  onFontFamilyChange 
}) => {
  const fontSizes = [14, 16, 18, 20, 22, 24];
  const lineHeights = [1.4, 1.6, 1.8, 2.0];
  const themes = [
    { id: 'light', name: 'Light', icon: 'Sun' },
    { id: 'dark', name: 'Dark', icon: 'Moon' },
    { id: 'sepia', name: 'Sepia', icon: 'Coffee' }
  ];
  const fontFamilies = [
    { id: 'serif', name: 'Serif', family: 'Georgia, serif' },
    { id: 'sans', name: 'Sans Serif', family: 'Inter, sans-serif' },
    { id: 'mono', name: 'Monospace', family: 'JetBrains Mono, monospace' }
  ];

  if (!isVisible) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4">
      <div className="bg-background border border-border rounded-lg w-full max-w-md max-h-[80vh] overflow-y-auto">
        <div className="flex items-center justify-between p-6 border-b border-border">
          <h2 className="text-lg font-semibold">Reading Settings</h2>
          <Button variant="ghost" size="icon" onClick={onClose}>
            <Icon name="X" size={20} />
          </Button>
        </div>

        <div className="p-6 space-y-6">
          {/* Font Size */}
          <div>
            <label className="text-sm font-medium mb-3 block">Font Size</label>
            <div className="flex items-center space-x-2">
              <Icon name="Type" size={16} className="text-muted-foreground" />
              <div className="flex-1">
                <input
                  type="range"
                  min={fontSizes?.[0]}
                  max={fontSizes?.[fontSizes?.length - 1]}
                  step="2"
                  value={fontSize}
                  onChange={(e) => onFontSizeChange(parseInt(e?.target?.value))}
                  className="w-full h-2 bg-muted rounded-lg appearance-none cursor-pointer"
                />
              </div>
              <span className="text-sm text-muted-foreground w-8">{fontSize}px</span>
            </div>
            <div className="flex justify-between text-xs text-muted-foreground mt-1">
              <span>Small</span>
              <span>Large</span>
            </div>
          </div>

          {/* Line Height */}
          <div>
            <label className="text-sm font-medium mb-3 block">Line Spacing</label>
            <div className="flex items-center space-x-2">
              <Icon name="AlignJustify" size={16} className="text-muted-foreground" />
              <div className="flex-1">
                <input
                  type="range"
                  min="1.4"
                  max="2.0"
                  step="0.2"
                  value={lineHeight}
                  onChange={(e) => onLineHeightChange(parseFloat(e?.target?.value))}
                  className="w-full h-2 bg-muted rounded-lg appearance-none cursor-pointer"
                />
              </div>
              <span className="text-sm text-muted-foreground w-8">{lineHeight}</span>
            </div>
            <div className="flex justify-between text-xs text-muted-foreground mt-1">
              <span>Tight</span>
              <span>Loose</span>
            </div>
          </div>

          {/* Font Family */}
          <div>
            <label className="text-sm font-medium mb-3 block">Font Family</label>
            <div className="grid grid-cols-3 gap-2">
              {fontFamilies?.map((font) => (
                <Button
                  key={font?.id}
                  variant={fontFamily === font?.id ? "default" : "outline"}
                  size="sm"
                  onClick={() => onFontFamilyChange(font?.id)}
                  className="text-xs"
                  style={{ fontFamily: font?.family }}
                >
                  {font?.name}
                </Button>
              ))}
            </div>
          </div>

          {/* Theme */}
          <div>
            <label className="text-sm font-medium mb-3 block">Theme</label>
            <div className="grid grid-cols-3 gap-2">
              {themes?.map((themeOption) => (
                <Button
                  key={themeOption?.id}
                  variant={theme === themeOption?.id ? "default" : "outline"}
                  size="sm"
                  onClick={() => onThemeChange(themeOption?.id)}
                  className="flex flex-col items-center space-y-1 h-16"
                >
                  <Icon name={themeOption?.icon} size={16} />
                  <span className="text-xs">{themeOption?.name}</span>
                </Button>
              ))}
            </div>
          </div>

          {/* Preview Text */}
          <div>
            <label className="text-sm font-medium mb-3 block">Preview</label>
            <div 
              className={`p-4 border border-border rounded-lg ${
                theme === 'dark' ? 'bg-gray-900 text-white' : 
                theme === 'sepia'? 'bg-amber-50 text-amber-900' : 'bg-background text-foreground'
              }`}
              style={{ 
                fontSize: `${fontSize}px`, 
                lineHeight: lineHeight,
                fontFamily: fontFamilies?.find(f => f?.id === fontFamily)?.family
              }}
            >
              The quick brown fox jumps over the lazy dog. This is how your story text will appear with the current settings.
            </div>
          </div>
        </div>

        <div className="p-6 border-t border-border">
          <Button variant="default" onClick={onClose} className="w-full">
            Apply Settings
          </Button>
        </div>
      </div>
    </div>
  );
};

export default ReadingSettings;