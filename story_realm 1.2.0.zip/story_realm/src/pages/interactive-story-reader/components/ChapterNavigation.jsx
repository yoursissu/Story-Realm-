import React from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const ChapterNavigation = ({ 
  chapters, 
  currentChapter, 
  onChapterSelect, 
  isVisible, 
  onClose 
}) => {
  if (!isVisible) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4">
      <div className="bg-background border border-border rounded-lg w-full max-w-md max-h-[80vh] overflow-hidden">
        <div className="flex items-center justify-between p-4 border-b border-border">
          <h2 className="text-lg font-semibold">Chapters</h2>
          <Button variant="ghost" size="icon" onClick={onClose}>
            <Icon name="X" size={20} />
          </Button>
        </div>

        <div className="overflow-y-auto max-h-96">
          {chapters?.map((chapter, index) => (
            <button
              key={chapter?.id}
              onClick={() => {
                onChapterSelect(index + 1);
                onClose();
              }}
              className={`w-full text-left p-4 border-b border-border hover:bg-muted transition-colors ${
                currentChapter === index + 1 ? 'bg-primary/10 border-l-4 border-l-primary' : ''
              }`}
            >
              <div className="flex items-center justify-between">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center space-x-3">
                    <span className={`text-sm font-medium ${
                      currentChapter === index + 1 ? 'text-primary' : 'text-muted-foreground'
                    }`}>
                      Chapter {index + 1}
                    </span>
                    {chapter?.isCompleted && (
                      <Icon name="CheckCircle" size={16} className="text-success" />
                    )}
                    {chapter?.isBookmarked && (
                      <Icon name="Bookmark" size={16} className="text-accent" />
                    )}
                  </div>
                  <h3 className={`font-medium truncate ${
                    currentChapter === index + 1 ? 'text-foreground' : 'text-foreground'
                  }`}>
                    {chapter?.title}
                  </h3>
                  <div className="flex items-center space-x-4 mt-1 text-xs text-muted-foreground">
                    <span>{chapter?.wordCount || 1250} words</span>
                    <span>•</span>
                    <span>{Math.ceil((chapter?.wordCount || 1250) / 200)} min read</span>
                    {chapter?.hasChoices && (
                      <>
                        <span>•</span>
                        <div className="flex items-center space-x-1">
                          <Icon name="GitBranch" size={12} />
                          <span>Interactive</span>
                        </div>
                      </>
                    )}
                  </div>
                </div>
                {currentChapter === index + 1 && (
                  <Icon name="Play" size={16} className="text-primary" />
                )}
              </div>
            </button>
          ))}
        </div>

        <div className="p-4 border-t border-border bg-muted">
          <div className="flex items-center justify-between text-sm">
            <span className="text-muted-foreground">
              Progress: {currentChapter} of {chapters?.length}
            </span>
            <span className="font-medium">
              {Math.round((currentChapter / chapters?.length) * 100)}% Complete
            </span>
          </div>
          <div className="w-full bg-background rounded-full h-2 mt-2">
            <div 
              className="bg-primary h-2 rounded-full transition-all duration-300"
              style={{ width: `${(currentChapter / chapters?.length) * 100}%` }}
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default ChapterNavigation;