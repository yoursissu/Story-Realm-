import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const StoryHeader = ({ story, currentChapter, totalChapters, isVisible, onToggleSettings }) => {
  const navigate = useNavigate();
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    if (totalChapters > 0) {
      setProgress((currentChapter / totalChapters) * 100);
    }
  }, [currentChapter, totalChapters]);

  return (
    <div className={`fixed top-0 left-0 right-0 z-50 bg-background/95 backdrop-blur-sm border-b border-border transition-transform duration-300 ${
      isVisible ? 'translate-y-0' : '-translate-y-full'
    }`}>
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center space-x-3">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => navigate('/story-discovery-dashboard')}
            >
              <Icon name="ArrowLeft" size={20} />
            </Button>
            <div className="flex flex-col">
              <h1 className="text-sm font-semibold text-foreground truncate max-w-48">
                {story?.title || 'Story Title'}
              </h1>
              <span className="text-xs text-muted-foreground">
                Chapter {currentChapter} of {totalChapters}
              </span>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <Button
              variant="ghost"
              size="icon"
              onClick={onToggleSettings}
            >
              <Icon name="Settings" size={20} />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => navigate('/user-profile-management')}
            >
              <Icon name="User" size={20} />
            </Button>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="pb-2">
          <div className="w-full bg-muted rounded-full h-1">
            <div 
              className="bg-primary h-1 rounded-full transition-all duration-300"
              style={{ width: `${progress}%` }}
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default StoryHeader;
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const StoryHeader = ({ story, currentChapter, totalChapters, isVisible, onToggleSettings }) => {
  const navigate = useNavigate();
  const progress = totalChapters > 0 ? (currentChapter / totalChapters) * 100 : 0;

  return (
    <div className={`fixed top-0 left-0 right-0 z-50 bg-background/95 backdrop-blur-sm border-b border-border transition-transform duration-300 ${
      isVisible ? 'translate-y-0' : '-translate-y-full'
    }`}>
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center space-x-3">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => navigate('/story-discovery-dashboard')}
            >
              <Icon name="ArrowLeft" size={20} />
            </Button>
            <div>
              <h1 className="text-sm font-semibold text-foreground truncate max-w-48">
                {story?.title || 'Story Title'}
              </h1>
              <p className="text-xs text-muted-foreground">AI Model: gemini-2.5-flash</p>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            {/* AI/Web Toggle */}
            <div className="bg-muted p-1 rounded-lg flex items-center">
                <Button size="xs" variant="ghost" className="text-muted-foreground">Web</Button>
                <Button size="xs" variant="secondary" className="bg-background text-foreground shadow-sm">AI [Beta]</Button>
            </div>
            <Button variant="ghost" size="icon" onClick={onToggleSettings}>
              <Icon name="Settings" size={20} />
            </Button>
          </div>
        </div>
        
        {/* Progress Bar */}
        <div className="w-full bg-muted rounded-full h-1">
          <div 
            className="bg-primary h-1 rounded-full transition-all duration-300"
            style={{ width: `${progress}%` }}
          />
        </div>
      </div>
    </div>
  );
};

export default StoryHeader;