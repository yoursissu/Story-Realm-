import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import Image from '../../../components/AppImage';

const CommentsPanel = ({ isVisible, onClose, comments, onAddComment }) => {
  const [newComment, setNewComment] = useState('');
  const [replyTo, setReplyTo] = useState(null);
  const [replyText, setReplyText] = useState('');

  const handleSubmitComment = () => {
    if (newComment?.trim()) {
      onAddComment?.(newComment);
      setNewComment('');
    }
  };

  const handleSubmitReply = (commentId) => {
    if (replyText?.trim()) {
      onAddComment?.(replyText, commentId);
      setReplyText('');
      setReplyTo(null);
    }
  };

  const formatTimeAgo = (timestamp) => {
    const now = new Date();
    const commentTime = new Date(timestamp);
    const diffInMinutes = Math.floor((now - commentTime) / (1000 * 60));
    
    if (diffInMinutes < 1) return 'Just now';
    if (diffInMinutes < 60) return `${diffInMinutes}m ago`;
    if (diffInMinutes < 1440) return `${Math.floor(diffInMinutes / 60)}h ago`;
    return `${Math.floor(diffInMinutes / 1440)}d ago`;
  };

  if (!isVisible) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/50 flex items-end md:items-center justify-center">
      <div className="bg-background border border-border rounded-t-lg md:rounded-lg w-full md:w-96 max-h-[80vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-border">
          <div className="flex items-center space-x-2">
            <Icon name="MessageCircle" size={20} />
            <h2 className="text-lg font-semibold">Comments</h2>
            <span className="bg-muted text-muted-foreground text-xs px-2 py-1 rounded-full">
              {comments?.length || 0}
            </span>
          </div>
          <Button variant="ghost" size="icon" onClick={onClose}>
            <Icon name="X" size={20} />
          </Button>
        </div>

        {/* Comments List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {comments && comments?.length > 0 ? (
            comments?.map((comment) => (
              <div key={comment?.id} className="space-y-3">
                <div className="flex space-x-3">
                  <Image
                    src={comment?.user?.avatar}
                    alt={comment?.user?.name}
                    className="w-8 h-8 rounded-full object-cover"
                  />
                  <div className="flex-1 min-w-0">
                    <div className="bg-muted rounded-lg p-3">
                      <div className="flex items-center space-x-2 mb-1">
                        <span className="font-medium text-sm">{comment?.user?.name}</span>
                        <span className="text-xs text-muted-foreground">
                          {formatTimeAgo(comment?.timestamp)}
                        </span>
                      </div>
                      <p className="text-sm">{comment?.text}</p>
                    </div>
                    <div className="flex items-center space-x-4 mt-2">
                      <Button
                        variant="ghost"
                        size="sm"
                        className="text-xs h-6 px-2"
                        onClick={() => setReplyTo(replyTo === comment?.id ? null : comment?.id)}
                      >
                        <Icon name="Reply" size={12} className="mr-1" />
                        Reply
                      </Button>
                      <Button variant="ghost" size="sm" className="text-xs h-6 px-2">
                        <Icon name="Heart" size={12} className="mr-1" />
                        {comment?.likes || 0}
                      </Button>
                    </div>

                    {/* Reply Form */}
                    {replyTo === comment?.id && (
                      <div className="mt-3 flex space-x-2">
                        <Input
                          type="text"
                          placeholder="Write a reply..."
                          value={replyText}
                          onChange={(e) => setReplyText(e?.target?.value)}
                          className="flex-1"
                        />
                        <Button
                          size="sm"
                          onClick={() => handleSubmitReply(comment?.id)}
                          disabled={!replyText?.trim()}
                        >
                          <Icon name="Send" size={14} />
                        </Button>
                      </div>
                    )}

                    {/* Replies */}
                    {comment?.replies && comment?.replies?.length > 0 && (
                      <div className="mt-3 ml-4 space-y-2">
                        {comment?.replies?.map((reply) => (
                          <div key={reply?.id} className="flex space-x-2">
                            <Image
                              src={reply?.user?.avatar}
                              alt={reply?.user?.name}
                              className="w-6 h-6 rounded-full object-cover"
                            />
                            <div className="flex-1">
                              <div className="bg-card border border-border rounded-lg p-2">
                                <div className="flex items-center space-x-2 mb-1">
                                  <span className="font-medium text-xs">{reply?.user?.name}</span>
                                  <span className="text-xs text-muted-foreground">
                                    {formatTimeAgo(reply?.timestamp)}
                                  </span>
                                </div>
                                <p className="text-xs">{reply?.text}</p>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ))
          ) : (
            <div className="text-center py-8">
              <Icon name="MessageCircle" size={48} className="mx-auto mb-4 text-muted-foreground" />
              <p className="text-muted-foreground">No comments yet</p>
              <p className="text-sm text-muted-foreground">Be the first to share your thoughts!</p>
            </div>
          )}
        </div>

        {/* Comment Input */}
        <div className="p-4 border-t border-border">
          <div className="flex space-x-2">
            <Input
              type="text"
              placeholder="Add a comment..."
              value={newComment}
              onChange={(e) => setNewComment(e?.target?.value)}
              className="flex-1"
              onKeyPress={(e) => e?.key === 'Enter' && handleSubmitComment()}
            />
            <Button
              onClick={handleSubmitComment}
              disabled={!newComment?.trim()}
            >
              <Icon name="Send" size={16} />
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CommentsPanel;