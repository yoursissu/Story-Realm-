import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';

const GlossaryModal = ({
  isVisible,
  onClose,
  terms,
  onAddTerm,
  onDeleteTerm,
  selectedText = ''
}) => {
  const [view, setView] = useState('list'); // 'list' or 'add'
  const [originalText, setOriginalText] = useState(selectedText);
  const [replacementText, setReplacementText] = useState('');
  const [isGlobal, setIsGlobal] = useState(true);
  const [isCaseSensitive, setIsCaseSensitive] = useState(false);

  React.useEffect(() => {
    setOriginalText(selectedText);
  }, [selectedText]);

  const handleAddClick = () => {
    setOriginalText(selectedText);
    setReplacementText('');
    setView('add');
  };

  const handleSaveTerm = () => {
    if (originalText.trim() && replacementText.trim()) {
      onAddTerm({
        id: Date.now(),
        original: originalText,
        replacement: replacementText,
        global: isGlobal,
        caseSensitive: isCaseSensitive,
      });
      setView('list');
      setOriginalText('');
      setReplacementText('');
    }
  };

  if (!isVisible) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center p-4">
      <div className="bg-card rounded-lg w-full max-w-md max-h-[90vh] flex flex-col border border-border">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-border">
          <div className="flex items-center space-x-2">
            <h2 className="text-lg font-semibold text-foreground">
              {view === 'list' ? 'Your Terms List' : 'Add New Term'}
            </h2>
            {view === 'add' && (
              <Button variant="link" size="sm" onClick={() => setView('list')}>
                Your Terms List
              </Button>
            )}
          </div>
          <Button variant="ghost" size="icon" onClick={onClose}>
            <Icon name="X" size={20} />
          </Button>
        </div>

        {/* Content */}
        {view === 'list' ? (
          <div className="flex-1 overflow-y-auto p-4 space-y-3">
            {terms.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                <p>Your glossary is empty.</p>
                <p className="text-sm">Select text in the reader to add a new term.</p>
              </div>
            ) : (
              terms.map((term) => (
                <div key={term.id} className="bg-muted/50 p-3 rounded-lg flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">From: <span className="font-mono text-foreground">{term.original}</span></p>
                    <p className="text-sm text-muted-foreground">To: <span className="font-mono text-foreground">{term.replacement}</span></p>
                  </div>
                  <div className="flex items-center">
                    {term.global && (
                       <span className="text-xs bg-accent text-accent-foreground px-2 py-1 rounded-full mr-2">Global</span>
                    )}
                    <Button variant="ghost" size="sm" onClick={() => onDeleteTerm(term.id)}>Delete</Button>
                  </div>
                </div>
              ))
            )}
          </div>
        ) : (
          <div className="p-4 space-y-4">
            <Input
              label="Original Text"
              value={originalText}
              onChange={(e) => setOriginalText(e.target.value)}
              placeholder="Text to replace"
            />
            <Input
              label="Replacement Text"
              value={replacementText}
              onChange={(e) => setReplacementText(e.target.value)}
              placeholder="Text to replace with"
            />
            <div className="flex items-center justify-between">
                <label className="text-sm font-medium text-foreground flex items-center">
                    Case Sensitive
                </label>
                <input type="checkbox" className="toggle-checkbox" checked={isCaseSensitive} onChange={() => setIsCaseSensitive(!isCaseSensitive)} />
            </div>
            <div className="flex items-center justify-between">
                <label className="text-sm font-medium text-foreground flex items-center">
                    Global Term (all novels)
                </label>
                <input type="checkbox" className="toggle-checkbox" checked={isGlobal} onChange={() => setIsGlobal(!isGlobal)} />
            </div>
          </div>
        )}
        
        {/* Footer */}
        <div className="p-4 border-t border-border flex justify-end space-x-2">
            {view === 'list' ? (
                <>
                    <Button variant="outline" onClick={onClose}>Close</Button>
                    <Button onClick={handleAddClick}>+ Add New Term</Button>
                </>
            ) : (
                 <>
                    <Button variant="outline" onClick={() => setView('list')}>Cancel</Button>
                    <Button onClick={handleSaveTerm}>Save Term</Button>
                </>
            )}
        </div>
      </div>
    </div>
  );
};

export default GlossaryModal;