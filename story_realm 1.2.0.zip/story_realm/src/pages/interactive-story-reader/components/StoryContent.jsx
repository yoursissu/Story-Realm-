import React, { useState, useEffect } from 'react';
import Image from '../../../components/AppImage';
import Button from '../../../components/ui/Button';
import Icon from '../../../components/AppIcon';

const StoryContent = ({ 
  chapter, 
  fontSize, 
  lineHeight, 
  theme, 
  onChoiceSelect,
  onMediaInteraction,
  onContentTap
}) => {
  const [selectedChoice, setSelectedChoice] = useState(null);
  const [readingTime, setReadingTime] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setReadingTime(prev => prev + 1);
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const handleChoiceSelect = (choiceId, choiceText) => {
    setSelectedChoice(choiceId);
    onChoiceSelect?.(choiceId, choiceText);
  };

  const formatReadingTime = (seconds) => {
    const minutes = Math.floor(seconds / 60);
    return `${minutes}m ${seconds % 60}s`;
  };

  const handleContentClick = () => {
    onContentTap?.();
  };

  if (!chapter) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <Icon name="BookOpen" size={48} className="mx-auto mb-4 text-muted-foreground" />
          <p className="text-muted-foreground">Loading chapter...</p>
        </div>
      </div>
    );
  }

  return (
    <div className={`max-w-4xl mx-auto px-4 py-8 ${theme === 'dark' ? 'text-white' : 'text-foreground'} cursor-pointer select-none`} onClick={handleContentClick}>
      {/* Chapter Header */}
      <div className="mb-8">
        <h1 className="text-2xl md:text-3xl font-bold mb-2">{chapter?.title}</h1>
        <div className="flex items-center space-x-4 text-sm text-muted-foreground">
          <span>Reading time: {formatReadingTime(readingTime)}</span>
          <span>•</span>
          <span>{chapter?.wordCount || 1250} words</span>
          <span>•</span>
          <span>Est. {Math.ceil((chapter?.wordCount || 1250) / 200)} min read</span>
        </div>
      </div>
      {/* Chapter Image */}
      {chapter?.image && (
        <div className="mb-8 rounded-lg overflow-hidden">
          <Image
            src={chapter?.image}
            alt={chapter?.title}
            className="w-full h-64 md:h-80 object-cover cursor-pointer hover:scale-105 transition-transform duration-300"
            onClick={() => onMediaInteraction?.('image', chapter?.image)}
          />
        </div>
      )}
      {/* Story Content */}
      <div 
        className="prose prose-lg max-w-none mb-8"
        style={{ 
          fontSize: `${fontSize}px`, 
          lineHeight: lineHeight,
          fontFamily: 'Georgia, serif'
        }}
      >
        {chapter?.content?.split('\n\n')?.map((paragraph, index) => (
          <p key={index} className="mb-6 leading-relaxed">
            {paragraph}
          </p>
        ))}
      </div>
      {/* Interactive Elements */}
      {chapter?.interactiveElements && chapter?.interactiveElements?.length > 0 && (
        <div className="mb-8">
          {chapter?.interactiveElements?.map((element, index) => (
            <div key={index} className="mb-6">
              {element?.type === 'choice' && (
                <div className="bg-card border border-border rounded-lg p-6">
                  <h3 className="text-lg font-semibold mb-4 text-card-foreground">
                    {element?.question}
                  </h3>
                  <div className="space-y-3">
                    {element?.options?.map((option) => (
                      <Button
                        key={option?.id}
                        variant={selectedChoice === option?.id ? "default" : "outline"}
                        className="w-full text-left justify-start p-4 h-auto"
                        onClick={() => handleChoiceSelect(option?.id, option?.text)}
                      >
                        <div className="flex items-start space-x-3">
                          <div className={`w-4 h-4 rounded-full border-2 mt-1 ${
                            selectedChoice === option?.id 
                              ? 'bg-primary border-primary' :'border-muted-foreground'
                          }`} />
                          <div>
                            <div className="font-medium">{option?.text}</div>
                            {option?.consequence && (
                              <div className="text-sm text-muted-foreground mt-1">
                                {option?.consequence}
                              </div>
                            )}
                          </div>
                        </div>
                      </Button>
                    ))}
                  </div>
                </div>
              )}

              {element?.type === 'media' && (
                <div className="bg-card border border-border rounded-lg p-6">
                  <div className="flex items-center space-x-3 mb-4">
                    <Icon name="Play" size={20} className="text-accent" />
                    <h3 className="text-lg font-semibold text-card-foreground">
                      {element?.title}
                    </h3>
                  </div>
                  <p className="text-muted-foreground mb-4">{element?.description}</p>
                  <Button
                    variant="outline"
                    onClick={() => onMediaInteraction?.(element?.mediaType, element?.url)}
                    className="flex items-center space-x-2"
                  >
                    <Icon name={element?.mediaType === 'audio' ? 'Volume2' : 'Play'} size={16} />
                    <span>Play {element?.mediaType}</span>
                  </Button>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
      {/* Chapter Stats */}
      <div className="bg-muted rounded-lg p-4 mb-8">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
          <div>
            <div className="text-2xl font-bold text-primary">{chapter?.views || 1247}</div>
            <div className="text-sm text-muted-foreground">Views</div>
          </div>
          <div>
            <div className="text-2xl font-bold text-accent">{chapter?.likes || 89}</div>
            <div className="text-sm text-muted-foreground">Likes</div>
          </div>
          <div>
            <div className="text-2xl font-bold text-success">{chapter?.bookmarks || 23}</div>
            <div className="text-sm text-muted-foreground">Bookmarks</div>
          </div>
          <div>
            <div className="text-2xl font-bold text-warning">{chapter?.comments || 15}</div>
            <div className="text-sm text-muted-foreground">Comments</div>
          </div>
        </div>
      </div>
      {/* Author Note */}
      {chapter?.authorNote && (
        <div className="bg-card border-l-4 border-primary p-6 rounded-r-lg">
          <div className="flex items-start space-x-3">
            <Icon name="MessageSquare" size={20} className="text-primary mt-1" />
            <div>
              <h4 className="font-semibold text-card-foreground mb-2">Author's Note</h4>
              <p className="text-muted-foreground">{chapter?.authorNote}</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default StoryContent;
import React, { useState, useEffect, useMemo } from 'react';
import Image from '../../../components/AppImage';
import Button from '../../../components/ui/Button';
import Icon from '../../../components/AppIcon';

const StoryContent = ({ 
  chapter, 
  fontSize, 
  lineHeight, 
  theme, 
  onChoiceSelect,
  onMediaInteraction,
  onContentTap,
  glossaryTerms,
  onAddTermRequest
}) => {
  const [selectedChoice, setSelectedChoice] = useState(null);
  const [addTermPopup, setAddTermPopup] = useState({ visible: false, x: 0, y: 0 });

  const handleTextSelection = () => {
    const selection = window.getSelection();
    if (selection && selection.toString().trim().length > 0) {
      const range = selection.getRangeAt(0);
      const rect = range.getBoundingClientRect();
      setAddTermPopup({
        visible: true,
        x: rect.left + window.scrollX + (rect.width / 2),
        y: rect.top + window.scrollY - 40, // Position above selection
      });
    } else {
      setAddTermPopup({ visible: false, x: 0, y: 0 });
    }
  };

  const handleAddTermClick = () => {
    const selection = window.getSelection();
    const selectedText = selection.toString().trim();
    if (selectedText) {
      onAddTermRequest(selectedText);
    }
    setAddTermPopup({ visible: false, x: 0, y: 0 });
    selection.removeAllRanges();
  };

  const applyGlossary = (text) => {
    if (!text) return '';
    let processedText = text;
    glossaryTerms.forEach(term => {
      // Simple replacement. For production, a more robust solution (e.g., regex with word boundaries) is better.
      const flags = term.caseSensitive ? 'g' : 'gi';
      const regex = new RegExp(term.original.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&'), flags);
      processedText = processedText.replace(regex, term.replacement);
    });
    return processedText;
  };

  const processedContent = useMemo(() => applyGlossary(chapter?.content), [chapter?.content, glossaryTerms]);
  
  if (!chapter) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <Icon name="BookOpen" size={48} className="mx-auto mb-4 text-muted-foreground" />
          <p className="text-muted-foreground">Loading chapter...</p>
        </div>
      </div>
    );
  }

  return (
    <div className={`max-w-4xl mx-auto px-4 py-8 ${theme === 'dark' ? 'text-white' : 'text-foreground'} select-text`} onMouseUp={handleTextSelection} onClick={onContentTap}>
      
      {addTermPopup.visible && (
        <div
          className="absolute z-10"
          style={{ top: `${addTermPopup.y}px`, left: `${addTermPopup.x}px`, transform: 'translateX(-50%)' }}
        >
          <Button size="sm" onClick={handleAddTermClick}>
            Add Term
          </Button>
        </div>
      )}

      {/* Chapter Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">{chapter?.title}</h1>
      </div>
      
      {/* Story Content with Glossary Applied */}
      <div 
        className="prose prose-lg max-w-none mb-8"
        style={{ fontSize: `${fontSize}px`, lineHeight: lineHeight }}
        dangerouslySetInnerHTML={{ __html: processedContent }}
      />

      {/* Interactive Elements and other components remain the same */}
      {/* ... (rest of the component) ... */}
    </div>
  );
};

export default StoryContent;