import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';

const ShareModal = ({ isVisible, onClose, story, currentChapter }) => {
  const [selectedQuote, setSelectedQuote] = useState('');
  const [customMessage, setCustomMessage] = useState('');

  const shareOptions = [
    { id: 'twitter', name: 'Twitter', icon: 'Twitter', color: 'text-blue-500' },
    { id: 'facebook', name: 'Facebook', icon: 'Facebook', color: 'text-blue-600' },
    { id: 'whatsapp', name: 'WhatsApp', icon: 'MessageCircle', color: 'text-green-500' },
    { id: 'telegram', name: 'Telegram', icon: 'Send', color: 'text-blue-400' },
    { id: 'copy', name: 'Copy Link', icon: 'Copy', color: 'text-gray-500' }
  ];

  const popularQuotes = [
    "The journey of a thousand miles begins with a single step.",
    "In the midst of winter, I found there was, within me, an invincible summer.",
    "The only way to do great work is to love what you do.",
    "Life is what happens to you while you're busy making other plans."
  ];

  const handleShare = (platform) => {
    const url = `${window.location?.origin}/interactive-story-reader?story=${story?.id}&chapter=${currentChapter}`;
    const text = customMessage || `Check out this amazing story: ${story?.title}`;
    
    switch (platform) {
      case 'twitter':
        window.open(`https://twitter.com/intent/tweet?text=${encodeURIComponent(text)}&url=${encodeURIComponent(url)}`);
        break;
      case 'facebook':
        window.open(`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}`);
        break;
      case 'whatsapp':
        window.open(`https://wa.me/?text=${encodeURIComponent(text + ' ' + url)}`);
        break;
      case 'telegram':
        window.open(`https://t.me/share/url?url=${encodeURIComponent(url)}&text=${encodeURIComponent(text)}`);
        break;
      case 'copy':
        navigator.clipboard?.writeText(url);
        // You could add a toast notification here
        break;
    }
    onClose();
  };

  if (!isVisible) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4">
      <div className="bg-background border border-border rounded-lg w-full max-w-md max-h-[80vh] overflow-y-auto">
        <div className="flex items-center justify-between p-6 border-b border-border">
          <h2 className="text-lg font-semibold">Share Story</h2>
          <Button variant="ghost" size="icon" onClick={onClose}>
            <Icon name="X" size={20} />
          </Button>
        </div>

        <div className="p-6 space-y-6">
          {/* Story Info */}
          <div className="text-center">
            <h3 className="font-semibold text-lg mb-1">{story?.title}</h3>
            <p className="text-muted-foreground text-sm">Chapter {currentChapter}</p>
          </div>

          {/* Custom Message */}
          <div>
            <label className="text-sm font-medium mb-2 block">Custom Message</label>
            <Input
              type="text"
              placeholder="Add your thoughts about this story..."
              value={customMessage}
              onChange={(e) => setCustomMessage(e?.target?.value)}
              className="w-full"
            />
          </div>

          {/* Popular Quotes */}
          <div>
            <label className="text-sm font-medium mb-3 block">Or share a quote</label>
            <div className="space-y-2">
              {popularQuotes?.map((quote, index) => (
                <button
                  key={index}
                  onClick={() => setCustomMessage(quote)}
                  className={`w-full text-left p-3 rounded-lg border transition-colors ${
                    customMessage === quote 
                      ? 'border-primary bg-primary/10' :'border-border hover:bg-muted'
                  }`}
                >
                  <p className="text-sm italic">"{quote}"</p>
                </button>
              ))}
            </div>
          </div>

          {/* Share Options */}
          <div>
            <label className="text-sm font-medium mb-3 block">Share on</label>
            <div className="grid grid-cols-2 gap-3">
              {shareOptions?.map((option) => (
                <Button
                  key={option?.id}
                  variant="outline"
                  onClick={() => handleShare(option?.id)}
                  className="flex items-center space-x-2 justify-start p-4 h-auto"
                >
                  <Icon name={option?.icon} size={20} className={option?.color} />
                  <span>{option?.name}</span>
                </Button>
              ))}
            </div>
          </div>

          {/* Quick Actions */}
          <div className="flex space-x-2">
            <Button
              variant="outline"
              onClick={() => handleShare('copy')}
              className="flex-1"
            >
              <Icon name="Copy" size={16} className="mr-2" />
              Copy Link
            </Button>
            <Button
              variant="default"
              onClick={() => handleShare('twitter')}
              className="flex-1"
            >
              <Icon name="Twitter" size={16} className="mr-2" />
              Tweet
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ShareModal;