import React from 'react';
import { Link } from 'react-router-dom';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';
import Button from '../../../components/ui/Button';

const FeaturedStories = () => {
  const featuredStory = {
    id: 1,
    title: "The Chronicles of Ethereal Realms",
    author: "Aria Moonwhisper",
    coverImage: "https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=800&h=600&fit=crop",
    rating: 4.9,
    readTime: "3 hours",
    genre: "Epic Fantasy",
    description: `Embark on an extraordinary journey through mystical realms where magic flows like rivers and ancient prophecies shape the destiny of worlds. Follow Lyra, a young mage who discovers she holds the key to preventing an eternal darkness from consuming all existence.\n\nThis award-winning interactive story features multiple branching paths, stunning visual elements, and choices that truly matter. Experience a tale where your decisions shape not just the story, but the very fabric of reality itself.`,
    tags: ["Interactive", "Multiple Endings", "Award Winner", "Visual Novel"],
    readers: 45000,
    chapters: 24,
    isComplete: true,
    awards: ["Best Fantasy Story 2024", "Reader\'s Choice Award"],
    features: ["Multiple Endings", "Character Customization", "Interactive Elements", "Rich Illustrations"]
  };

  return (
    <div className="mb-8">
      <div className="bg-gradient-to-r from-primary/10 via-accent/5 to-primary/10 rounded-2xl overflow-hidden shadow-warm-lg">
        <div className="flex flex-col lg:flex-row">
          {/* Image Section */}
          <div className="lg:w-2/5 relative">
            <div className="aspect-[4/3] lg:aspect-[3/4] relative overflow-hidden">
              <Image
                src={featuredStory?.coverImage}
                alt={featuredStory?.title}
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t lg:bg-gradient-to-r from-black/60 via-black/20 to-transparent" />
              
              {/* Featured Badge */}
              <div className="absolute top-4 left-4">
                <div className="flex items-center space-x-2 bg-accent text-accent-foreground px-3 py-1 rounded-full text-sm font-medium">
                  <Icon name="Star" size={16} />
                  <span>Featured Story</span>
                </div>
              </div>

              {/* Awards */}
              <div className="absolute bottom-4 left-4 right-4">
                <div className="flex flex-wrap gap-2">
                  {featuredStory?.awards?.map((award, index) => (
                    <div key={index} className="bg-warning/90 text-warning-foreground px-2 py-1 rounded text-xs font-medium">
                      <Icon name="Award" size={12} className="inline mr-1" />
                      {award}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Content Section */}
          <div className="lg:w-3/5 p-6 lg:p-8">
            <div className="flex items-center space-x-2 mb-3">
              <span className="text-sm font-medium text-accent bg-accent/10 px-3 py-1 rounded-full">
                {featuredStory?.genre}
              </span>
              {featuredStory?.isComplete && (
                <span className="text-sm font-medium text-success bg-success/10 px-3 py-1 rounded-full">
                  Complete
                </span>
              )}
            </div>

            <h1 className="text-3xl lg:text-4xl font-heading font-bold text-foreground mb-2">
              {featuredStory?.title}
            </h1>

            <p className="text-lg text-muted-foreground mb-4">by {featuredStory?.author}</p>

            {/* Stats */}
            <div className="flex flex-wrap items-center gap-4 mb-4 text-sm text-muted-foreground">
              <div className="flex items-center space-x-1">
                <Icon name="Star" size={16} color="#FFD700" />
                <span className="font-medium">{featuredStory?.rating}</span>
              </div>
              <div className="flex items-center space-x-1">
                <Icon name="Clock" size={16} />
                <span>{featuredStory?.readTime}</span>
              </div>
              <div className="flex items-center space-x-1">
                <Icon name="Users" size={16} />
                <span>{featuredStory?.readers?.toLocaleString()} readers</span>
              </div>
              <div className="flex items-center space-x-1">
                <Icon name="BookOpen" size={16} />
                <span>{featuredStory?.chapters} chapters</span>
              </div>
            </div>

            {/* Description */}
            <p className="text-muted-foreground mb-4 leading-relaxed">
              {featuredStory?.description?.split('\n')?.[0]}
            </p>

            <p className="text-muted-foreground mb-6 leading-relaxed">
              {featuredStory?.description?.split('\n')?.[2]}
            </p>

            {/* Features */}
            <div className="mb-6">
              <h3 className="font-heading font-semibold text-foreground mb-3">Story Features:</h3>
              <div className="grid grid-cols-2 gap-2">
                {featuredStory?.features?.map((feature, index) => (
                  <div key={index} className="flex items-center space-x-2 text-sm text-muted-foreground">
                    <Icon name="Check" size={14} className="text-success" />
                    <span>{feature}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Tags */}
            <div className="flex flex-wrap gap-2 mb-6">
              {featuredStory?.tags?.map((tag, index) => (
                <span 
                  key={index}
                  className="text-xs text-muted-foreground bg-muted/50 px-2 py-1 rounded-full"
                >
                  {tag}
                </span>
              ))}
            </div>

            {/* Action Buttons */}
            <div className="flex flex-col sm:flex-row gap-3">
              <Link to="/interactive-story-reader" className="flex-1">
                <Button variant="default" className="w-full" size="lg">
                  <Icon name="Play" size={18} className="mr-2" />
                  Start Reading
                </Button>
              </Link>
              <Button variant="outline" size="lg">
                <Icon name="BookmarkPlus" size={18} className="mr-2" />
                Add to Library
              </Button>
              <Button variant="ghost" size="lg">
                <Icon name="Share" size={18} className="mr-2" />
                Share
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FeaturedStories;