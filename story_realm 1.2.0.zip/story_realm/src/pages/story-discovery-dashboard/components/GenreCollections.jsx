import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';
import Button from '../../../components/ui/Button';

const GenreCollections = () => {
  const [activeGenre, setActiveGenre] = useState('Fantasy');

  const genres = [
    { name: 'Fantasy', icon: 'Sparkles', color: 'text-purple-600' },
    { name: 'Sci-Fi', icon: 'Rocket', color: 'text-blue-600' },
    { name: 'Romance', icon: 'Heart', color: 'text-pink-600' },
    { name: 'Mystery', icon: 'Search', color: 'text-indigo-600' },
    { name: 'Horror', icon: 'Ghost', color: 'text-red-600' },
    { name: 'Adventure', icon: 'Map', color: 'text-green-600' }
  ];

  const genreStories = {
    Fantasy: [
      {
        id: 1,
        title: "Dragon\'s Crown",
        author: "Emma Blackwood",
        coverImage: "https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=300&h=400&fit=crop",
        rating: 4.8,
        readTime: "52 min",
        description: "An epic tale of dragons, magic, and the crown that binds them all.",
        isNew: true
      },
      {
        id: 2,
        title: "The Mage\'s Apprentice",
        author: "Thomas Grey",
        coverImage: "https://images.pexels.com/photos/1261728/pexels-photo-1261728.jpeg?w=300&h=400&fit=crop",
        rating: 4.6,
        readTime: "41 min",
        description: "A young apprentice discovers powers beyond imagination.",
        isNew: false
      },
      {
        id: 3,
        title: "Realm of Shadows",
        author: "Victoria Stone",
        coverImage: "https://images.pixabay.com/photo/2016/11/29/05/45/astronomy-1867616_1280.jpg?w=300&h=400&fit=crop",
        rating: 4.7,
        readTime: "38 min",
        description: "Where light meets darkness, heroes are born.",
        isNew: false
      }
    ],
    'Sci-Fi': [
      {
        id: 4,
        title: "Stellar Odyssey",
        author: "Captain Nova",
        coverImage: "https://images.unsplash.com/photo-1446776877081-d282a0f896e2?w=300&h=400&fit=crop",
        rating: 4.9,
        readTime: "47 min",
        description: "A journey across galaxies to save humanity\'s future.",
        isNew: true
      },
      {
        id: 5,
        title: "Android Dreams",
        author: "Dr. Cipher",
        coverImage: "https://images.pexels.com/photos/1181467/pexels-photo-1181467.jpeg?w=300&h=400&fit=crop",
        rating: 4.5,
        readTime: "33 min",
        description: "When machines dream, what do they see?",
        isNew: false
      },
      {
        id: 6,
        title: "Quantum Leap",
        author: "Prof. Martinez",
        coverImage: "https://images.pixabay.com/photo/2017/08/30/01/05/milky-way-2695569_1280.jpg?w=300&h=400&fit=crop",
        rating: 4.7,
        readTime: "44 min",
        description: "Reality bends when quantum physics meets adventure.",
        isNew: false
      }
    ],
    Romance: [
      {
        id: 7,
        title: "Love in Paris",
        author: "Isabelle Laurent",
        coverImage: "https://images.unsplash.com/photo-1519904981063-b0cf448d479e?w=300&h=400&fit=crop",
        rating: 4.6,
        readTime: "36 min",
        description: "A chance encounter in the City of Love changes everything.",
        isNew: true
      },
      {
        id: 8,
        title: "Second Chances",
        author: "Michael Roberts",
        coverImage: "https://images.pexels.com/photos/1261728/pexels-photo-1261728.jpeg?w=300&h=400&fit=crop",
        rating: 4.4,
        readTime: "29 min",
        description: "Sometimes love deserves a second chance.",
        isNew: false
      },
      {
        id: 9,
        title: "The Wedding Planner",
        author: "Sophie Chen",
        coverImage: "https://images.pixabay.com/photo/2016/11/29/05/45/astronomy-1867616_1280.jpg?w=300&h=400&fit=crop",
        rating: 4.8,
        readTime: "42 min",
        description: "Planning weddings is easy, falling in love is complicated.",
        isNew: false
      }
    ],
    Mystery: [
      {
        id: 10,
        title: "The Missing Heir",
        author: "Detective Morgan",
        coverImage: "https://images.unsplash.com/photo-1481627834876-b7833e8f5570?w=300&h=400&fit=crop",
        rating: 4.7,
        readTime: "49 min",
        description: "A fortune, a family secret, and a disappearance that changes everything.",
        isNew: true
      },
      {
        id: 11,
        title: "Midnight Murders",
        author: "Inspector Blake",
        coverImage: "https://images.pexels.com/photos/1181467/pexels-photo-1181467.jpeg?w=300&h=400&fit=crop",
        rating: 4.8,
        readTime: "55 min",
        description: "When the clock strikes midnight, secrets are revealed.",
        isNew: false
      },
      {
        id: 12,
        title: "The Locked Room",
        author: "Sarah Holmes",
        coverImage: "https://images.pixabay.com/photo/2017/08/30/01/05/milky-way-2695569_1280.jpg?w=300&h=400&fit=crop",
        rating: 4.5,
        readTime: "37 min",
        description: "An impossible crime with an even more impossible solution.",
        isNew: false
      }
    ],
    Horror: [
      {
        id: 13,
        title: "The Haunted Manor",
        author: "Edgar Blackthorne",
        coverImage: "https://images.unsplash.com/photo-1520637836862-4d197d17c93a?w=300&h=400&fit=crop",
        rating: 4.3,
        readTime: "43 min",
        description: "Some houses hold secrets that should never be disturbed.",
        isNew: true
      },
      {
        id: 14,
        title: "Whispers in the Dark",
        author: "Raven Nightshade",
        coverImage: "https://images.pexels.com/photos/1261728/pexels-photo-1261728.jpeg?w=300&h=400&fit=crop",
        rating: 4.6,
        readTime: "38 min",
        description: "When darkness falls, the whispers begin.",
        isNew: false
      },
      {
        id: 15,
        title: "The Collector",
        author: "Vincent Grimm",
        coverImage: "https://images.pixabay.com/photo/2016/11/29/05/45/astronomy-1867616_1280.jpg?w=300&h=400&fit=crop",
        rating: 4.4,
        readTime: "51 min",
        description: "He collects more than just antiques.",
        isNew: false
      }
    ],
    Adventure: [
      {
        id: 16,
        title: "Treasure Island Redux",
        author: "Captain Adventure",
        coverImage: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=300&h=400&fit=crop",
        rating: 4.7,
        readTime: "46 min",
        description: "A modern twist on the classic treasure hunt adventure.",
        isNew: true
      },
      {
        id: 17,
        title: "Mountain Peak",
        author: "Alex Summit",
        coverImage: "https://images.pexels.com/photos/1181467/pexels-photo-1181467.jpeg?w=300&h=400&fit=crop",
        rating: 4.5,
        readTime: "41 min",
        description: "Climbing mountains teaches you about more than just altitude.",
        isNew: false
      },
      {
        id: 18,
        title: "Desert Crossing",
        author: "Nomad Walker",
        coverImage: "https://images.pixabay.com/photo/2017/08/30/01/05/milky-way-2695569_1280.jpg?w=300&h=400&fit=crop",
        rating: 4.6,
        readTime: "39 min",
        description: "Survival in the desert requires more than just water.",
        isNew: false
      }
    ]
  };

  const currentStories = genreStories?.[activeGenre] || [];

  return (
    <div className="mb-8">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-2xl font-heading font-semibold text-foreground">Browse by Genre</h2>
      </div>
      {/* Genre Tabs */}
      <div className="flex overflow-x-auto scrollbar-hide mb-6 pb-2">
        <div className="flex space-x-2 min-w-max">
          {genres?.map((genre) => (
            <button
              key={genre?.name}
              onClick={() => setActiveGenre(genre?.name)}
              className={`flex items-center space-x-2 px-4 py-2 rounded-full text-sm font-medium transition-all whitespace-nowrap ${
                activeGenre === genre?.name
                  ? 'bg-primary text-primary-foreground shadow-warm-md'
                  : 'bg-muted text-muted-foreground hover:bg-muted/80'
              }`}
            >
              <Icon name={genre?.icon} size={16} className={activeGenre === genre?.name ? '' : genre?.color} />
              <span>{genre?.name}</span>
            </button>
          ))}
        </div>
      </div>
      {/* Stories Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {currentStories?.map((story) => (
          <div key={story?.id} className="bg-card rounded-xl shadow-warm-md overflow-hidden group hover:shadow-warm-lg transition-all duration-300">
            <div className="relative aspect-[3/4] overflow-hidden">
              <Image
                src={story?.coverImage}
                alt={story?.title}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
              
              {/* New Badge */}
              {story?.isNew && (
                <div className="absolute top-3 left-3">
                  <span className="bg-success text-success-foreground text-xs font-medium px-2 py-1 rounded-full">
                    New
                  </span>
                </div>
              )}

              {/* Bookmark Button */}
              <Button
                variant="ghost"
                size="icon"
                className="absolute top-3 right-3 bg-background/80 hover:bg-background"
              >
                <Icon name="BookmarkPlus" size={18} color="var(--color-muted-foreground)" />
              </Button>

              {/* Story Info Overlay */}
              <div className="absolute bottom-3 left-3 right-3">
                <div className="flex items-center space-x-3 text-white text-sm">
                  <div className="flex items-center space-x-1">
                    <Icon name="Star" size={14} color="#FFD700" />
                    <span>{story?.rating}</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Icon name="Clock" size={14} />
                    <span>{story?.readTime}</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="p-4">
              <h3 className="font-heading font-semibold text-lg text-card-foreground mb-1 line-clamp-2">
                {story?.title}
              </h3>
              
              <p className="text-sm text-muted-foreground mb-2">by {story?.author}</p>
              
              <p className="text-sm text-muted-foreground line-clamp-2 mb-4">
                {story?.description}
              </p>

              <Link to="/interactive-story-reader">
                <Button variant="outline" className="w-full">
                  Read Story
                </Button>
              </Link>
            </div>
          </div>
        ))}
      </div>
      {/* View More Button */}
      <div className="text-center mt-6">
        <Link to="/story-discovery-dashboard">
          <Button variant="outline" className="px-8">
            View More {activeGenre} Stories
            <Icon name="ChevronRight" size={16} className="ml-2" />
          </Button>
        </Link>
      </div>
    </div>
  );
};

export default GenreCollections;