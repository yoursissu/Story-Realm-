import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';
import Button from '../../../components/ui/Button';

const TrendingStoriesCarousel = () => {
  const [currentSlide, setCurrentSlide] = useState(0);

  const trendingStories = [
    {
      id: 1,
      title: "The Last Guardian\'s Secret",
      author: "Elena Rodriguez",
      coverImage: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=600&fit=crop",
      rating: 4.8,
      readTime: "45 min",
      genre: "Fantasy",
      description: "A mystical tale of ancient guardians and hidden powers that will change everything you thought you knew about magic.",
      isBookmarked: false,
      readers: 12500
    },
    {
      id: 2,
      title: "Digital Hearts",
      author: "Marcus Chen",
      coverImage: "https://images.pexels.com/photos/1181467/pexels-photo-1181467.jpeg?w=400&h=600&fit=crop",
      rating: 4.6,
      readTime: "32 min",
      genre: "Sci-Fi Romance",
      description: "In a world where emotions can be digitized, two souls find connection beyond the virtual realm.",
      isBookmarked: true,
      readers: 8900
    },
    {
      id: 3,
      title: "Midnight in Tokyo",
      author: "Yuki Tanaka",
      coverImage: "https://images.pixabay.com/photo/2020/07/12/07/47/bee-5396362_1280.jpg?w=400&h=600&fit=crop",
      rating: 4.9,
      readTime: "28 min",
      genre: "Mystery",
      description: "A detective\'s journey through neon-lit streets uncovers secrets that threaten to unravel reality itself.",
      isBookmarked: false,
      readers: 15200
    }
  ];

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % trendingStories?.length);
  };

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + trendingStories?.length) % trendingStories?.length);
  };

  const toggleBookmark = (storyId) => {
    // Mock bookmark toggle functionality
    console.log(`Toggling bookmark for story ${storyId}`);
  };

  return (
    <div className="mb-8">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-2xl font-heading font-semibold text-foreground">Trending Stories</h2>
        <Link 
          to="/story-discovery-dashboard" 
          className="text-primary hover:text-primary/80 text-sm font-medium flex items-center space-x-1"
        >
          <span>View All</span>
          <Icon name="ChevronRight" size={16} />
        </Link>
      </div>
      <div className="relative">
        {/* Desktop Carousel */}
        <div className="hidden md:block">
          <div className="grid grid-cols-3 gap-6">
            {trendingStories?.map((story) => (
              <div key={story?.id} className="bg-card rounded-xl shadow-warm-md overflow-hidden group hover:shadow-warm-lg transition-all duration-300">
                <div className="relative aspect-[3/4] overflow-hidden">
                  <Image
                    src={story?.coverImage}
                    alt={story?.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
                  <Button
                    variant="ghost"
                    size="icon"
                    className="absolute top-3 right-3 bg-background/80 hover:bg-background"
                    onClick={() => toggleBookmark(story?.id)}
                  >
                    <Icon 
                      name={story?.isBookmarked ? "Bookmark" : "BookmarkPlus"} 
                      size={18}
                      color={story?.isBookmarked ? "var(--color-accent)" : "var(--color-muted-foreground)"}
                    />
                  </Button>
                  <div className="absolute bottom-3 left-3 right-3">
                    <div className="flex items-center space-x-2 text-white text-sm mb-2">
                      <div className="flex items-center space-x-1">
                        <Icon name="Star" size={14} color="#FFD700" />
                        <span>{story?.rating}</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <Icon name="Clock" size={14} />
                        <span>{story?.readTime}</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <Icon name="Users" size={14} />
                        <span>{story?.readers?.toLocaleString()}</span>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="p-4">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-medium text-accent bg-accent/10 px-2 py-1 rounded-full">
                      {story?.genre}
                    </span>
                  </div>
                  <h3 className="font-heading font-semibold text-lg text-card-foreground mb-1 line-clamp-2">
                    {story?.title}
                  </h3>
                  <p className="text-sm text-muted-foreground mb-2">by {story?.author}</p>
                  <p className="text-sm text-muted-foreground line-clamp-2 mb-3">
                    {story?.description}
                  </p>
                  <Link to="/interactive-story-reader">
                    <Button variant="default" className="w-full">
                      Start Reading
                    </Button>
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Mobile Carousel */}
        <div className="md:hidden relative">
          <div className="overflow-hidden rounded-xl">
            <div 
              className="flex transition-transform duration-300 ease-in-out"
              style={{ transform: `translateX(-${currentSlide * 100}%)` }}
            >
              {trendingStories?.map((story) => (
                <div key={story?.id} className="w-full flex-shrink-0">
                  <div className="bg-card rounded-xl shadow-warm-md overflow-hidden mx-2">
                    <div className="relative aspect-[3/4] overflow-hidden">
                      <Image
                        src={story?.coverImage}
                        alt={story?.title}
                        className="w-full h-full object-cover"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
                      <Button
                        variant="ghost"
                        size="icon"
                        className="absolute top-3 right-3 bg-background/80 hover:bg-background"
                        onClick={() => toggleBookmark(story?.id)}
                      >
                        <Icon 
                          name={story?.isBookmarked ? "Bookmark" : "BookmarkPlus"} 
                          size={18}
                          color={story?.isBookmarked ? "var(--color-accent)" : "var(--color-muted-foreground)"}
                        />
                      </Button>
                      <div className="absolute bottom-3 left-3 right-3">
                        <div className="flex items-center space-x-2 text-white text-sm mb-2">
                          <div className="flex items-center space-x-1">
                            <Icon name="Star" size={14} color="#FFD700" />
                            <span>{story?.rating}</span>
                          </div>
                          <div className="flex items-center space-x-1">
                            <Icon name="Clock" size={14} />
                            <span>{story?.readTime}</span>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="p-4">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-xs font-medium text-accent bg-accent/10 px-2 py-1 rounded-full">
                          {story?.genre}
                        </span>
                      </div>
                      <h3 className="font-heading font-semibold text-lg text-card-foreground mb-1">
                        {story?.title}
                      </h3>
                      <p className="text-sm text-muted-foreground mb-2">by {story?.author}</p>
                      <p className="text-sm text-muted-foreground line-clamp-2 mb-3">
                        {story?.description}
                      </p>
                      <Link to="/interactive-story-reader">
                        <Button variant="default" className="w-full">
                          Start Reading
                        </Button>
                      </Link>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Navigation Buttons */}
          <Button
            variant="ghost"
            size="icon"
            className="absolute left-2 top-1/2 -translate-y-1/2 bg-background/80 hover:bg-background shadow-warm-md"
            onClick={prevSlide}
          >
            <Icon name="ChevronLeft" size={20} />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="absolute right-2 top-1/2 -translate-y-1/2 bg-background/80 hover:bg-background shadow-warm-md"
            onClick={nextSlide}
          >
            <Icon name="ChevronRight" size={20} />
          </Button>

          {/* Dots Indicator */}
          <div className="flex justify-center space-x-2 mt-4">
            {trendingStories?.map((_, index) => (
              <button
                key={index}
                className={`w-2 h-2 rounded-full transition-colors ${
                  index === currentSlide ? 'bg-primary' : 'bg-muted'
                }`}
                onClick={() => setCurrentSlide(index)}
              />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default TrendingStoriesCarousel;