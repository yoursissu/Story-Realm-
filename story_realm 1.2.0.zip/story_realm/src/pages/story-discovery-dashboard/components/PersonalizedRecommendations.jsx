import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';
import Button from '../../../components/ui/Button';

const PersonalizedRecommendations = () => {
  const [bookmarkedStories, setBookmarkedStories] = useState(new Set([2, 5]));

  const recommendations = [
    {
      id: 1,
      title: "Echoes of Tomorrow",
      author: "Sarah Mitchell",
      coverImage: "https://images.unsplash.com/photo-1481627834876-b7833e8f5570?w=300&h=400&fit=crop",
      rating: 4.7,
      readTime: "38 min",
      genre: "Sci-Fi",
      description: "A time-traveling adventure that explores the consequences of changing the past.",
      completionStatus: "New",
      tags: ["Time Travel", "Adventure", "Drama"]
    },
    {
      id: 2,
      title: "The Whispering Woods",
      author: "James Patterson",
      coverImage: "https://images.pexels.com/photos/1261728/pexels-photo-1261728.jpeg?w=300&h=400&fit=crop",
      rating: 4.5,
      readTime: "42 min",
      genre: "Fantasy",
      description: "Deep in the enchanted forest, ancient secrets await those brave enough to listen.",
      completionStatus: "Complete",
      tags: ["Magic", "Mystery", "Nature"]
    },
    {
      id: 3,
      title: "City of Neon Dreams",
      author: "Alex Rivera",
      coverImage: "https://images.pixabay.com/photo/2016/11/29/05/45/astronomy-1867616_1280.jpg?w=300&h=400&fit=crop",
      rating: 4.8,
      readTime: "35 min",
      genre: "Cyberpunk",
      description: "In a dystopian future, a hacker discovers the truth behind the city's digital facade.",
      completionStatus: "Ongoing",
      tags: ["Cyberpunk", "Thriller", "Technology"]
    },
    {
      id: 4,
      title: "Hearts Across Oceans",
      author: "Maria Santos",
      coverImage: "https://images.unsplash.com/photo-1519904981063-b0cf448d479e?w=300&h=400&fit=crop",
      rating: 4.6,
      readTime: "29 min",
      genre: "Romance",
      description: "A love story that spans continents and challenges the boundaries of distance.",
      completionStatus: "New",
      tags: ["Romance", "Travel", "Drama"]
    },
    {
      id: 5,
      title: "The Detective\'s Dilemma",
      author: "Robert Kim",
      coverImage: "https://images.pexels.com/photos/1181467/pexels-photo-1181467.jpeg?w=300&h=400&fit=crop",
      rating: 4.9,
      readTime: "51 min",
      genre: "Mystery",
      description: "A seasoned detective faces their most challenging case yet in this gripping thriller.",
      completionStatus: "Complete",
      tags: ["Mystery", "Crime", "Suspense"]
    },
    {
      id: 6,
      title: "Quantum Entangled",
      author: "Dr. Lisa Chen",
      coverImage: "https://images.pixabay.com/photo/2017/08/30/01/05/milky-way-2695569_1280.jpg?w=300&h=400&fit=crop",
      rating: 4.4,
      readTime: "46 min",
      genre: "Hard Sci-Fi",
      description: "A physicist\'s groundbreaking discovery leads to unexpected consequences across dimensions.",
      completionStatus: "Ongoing",
      tags: ["Science", "Physics", "Adventure"]
    }
  ];

  const toggleBookmark = (storyId) => {
    setBookmarkedStories(prev => {
      const newSet = new Set(prev);
      if (newSet?.has(storyId)) {
        newSet?.delete(storyId);
      } else {
        newSet?.add(storyId);
      }
      return newSet;
    });
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'New':
        return 'bg-success/10 text-success';
      case 'Complete':
        return 'bg-primary/10 text-primary';
      case 'Ongoing':
        return 'bg-warning/10 text-warning';
      default:
        return 'bg-muted/10 text-muted-foreground';
    }
  };

  return (
    <div className="mb-8">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-2xl font-heading font-semibold text-foreground">Recommended for You</h2>
        <Link 
          to="/story-discovery-dashboard" 
          className="text-primary hover:text-primary/80 text-sm font-medium flex items-center space-x-1"
        >
          <span>View All</span>
          <Icon name="ChevronRight" size={16} />
        </Link>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {recommendations?.map((story) => (
          <div key={story?.id} className="bg-card rounded-xl shadow-warm-md overflow-hidden group hover:shadow-warm-lg transition-all duration-300">
            <div className="relative aspect-[3/4] overflow-hidden">
              <Image
                src={story?.coverImage}
                alt={story?.title}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
              
              {/* Status Badge */}
              <div className="absolute top-3 left-3">
                <span className={`text-xs font-medium px-2 py-1 rounded-full ${getStatusColor(story?.completionStatus)}`}>
                  {story?.completionStatus}
                </span>
              </div>

              {/* Bookmark Button */}
              <Button
                variant="ghost"
                size="icon"
                className="absolute top-3 right-3 bg-background/80 hover:bg-background"
                onClick={() => toggleBookmark(story?.id)}
              >
                <Icon 
                  name={bookmarkedStories?.has(story?.id) ? "Bookmark" : "BookmarkPlus"} 
                  size={18}
                  color={bookmarkedStories?.has(story?.id) ? "var(--color-accent)" : "var(--color-muted-foreground)"}
                />
              </Button>

              {/* Story Info Overlay */}
              <div className="absolute bottom-3 left-3 right-3">
                <div className="flex items-center space-x-3 text-white text-sm">
                  <div className="flex items-center space-x-1">
                    <Icon name="Star" size={14} color="#FFD700" />
                    <span>{story?.rating}</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Icon name="Clock" size={14} />
                    <span>{story?.readTime}</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="p-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-medium text-accent bg-accent/10 px-2 py-1 rounded-full">
                  {story?.genre}
                </span>
              </div>
              
              <h3 className="font-heading font-semibold text-lg text-card-foreground mb-1 line-clamp-2">
                {story?.title}
              </h3>
              
              <p className="text-sm text-muted-foreground mb-2">by {story?.author}</p>
              
              <p className="text-sm text-muted-foreground line-clamp-2 mb-3">
                {story?.description}
              </p>

              {/* Tags */}
              <div className="flex flex-wrap gap-1 mb-3">
                {story?.tags?.slice(0, 2)?.map((tag, index) => (
                  <span 
                    key={index}
                    className="text-xs text-muted-foreground bg-muted/50 px-2 py-1 rounded-full"
                  >
                    {tag}
                  </span>
                ))}
                {story?.tags?.length > 2 && (
                  <span className="text-xs text-muted-foreground bg-muted/50 px-2 py-1 rounded-full">
                    +{story?.tags?.length - 2}
                  </span>
                )}
              </div>

              <Link to="/interactive-story-reader">
                <Button variant="default" className="w-full">
                  Start Reading
                </Button>
              </Link>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default PersonalizedRecommendations;