import React from 'react';
import { Link } from 'react-router-dom';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';
import Button from '../../../components/ui/Button';

const ContinueReading = () => {
  const inProgressStories = [
    {
      id: 1,
      title: "The Enchanted Forest Chronicles",
      author: "Luna Silverleaf",
      coverImage: "https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=300&h=400&fit=crop",
      currentChapter: 7,
      totalChapters: 12,
      progress: 58,
      lastRead: "2 hours ago",
      genre: "Fantasy",
      estimatedTimeLeft: "25 min"
    },
    {
      id: 2,
      title: "Neon Nights Detective",
      author: "Jack Noir",
      coverImage: "https://images.pexels.com/photos/1181467/pexels-photo-1181467.jpeg?w=300&h=400&fit=crop",
      currentChapter: 3,
      totalChapters: 8,
      progress: 37,
      lastRead: "1 day ago",
      genre: "Mystery",
      estimatedTimeLeft: "42 min"
    },
    {
      id: 3,
      title: "Love Across Dimensions",
      author: "Sophia Hearts",
      coverImage: "https://images.pixabay.com/photo/2016/11/29/05/45/astronomy-1867616_1280.jpg?w=300&h=400&fit=crop",
      currentChapter: 15,
      totalChapters: 20,
      progress: 75,
      lastRead: "3 days ago",
      genre: "Romance",
      estimatedTimeLeft: "18 min"
    }
  ];

  const getProgressColor = (progress) => {
    if (progress < 30) return 'bg-error';
    if (progress < 70) return 'bg-warning';
    return 'bg-success';
  };

  const formatLastRead = (lastRead) => {
    return lastRead;
  };

  return (
    <div className="mb-8">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-2xl font-heading font-semibold text-foreground">Continue Reading</h2>
        <Link 
          to="/user-profile-management" 
          className="text-primary hover:text-primary/80 text-sm font-medium flex items-center space-x-1"
        >
          <span>View All</span>
          <Icon name="ChevronRight" size={16} />
        </Link>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {inProgressStories?.map((story) => (
          <div key={story?.id} className="bg-card rounded-xl shadow-warm-md overflow-hidden group hover:shadow-warm-lg transition-all duration-300">
            <div className="flex">
              {/* Cover Image */}
              <div className="relative w-24 h-32 flex-shrink-0 overflow-hidden">
                <Image
                  src={story?.coverImage}
                  alt={story?.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-gradient-to-r from-transparent to-black/20" />
              </div>

              {/* Story Info */}
              <div className="flex-1 p-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-medium text-accent bg-accent/10 px-2 py-1 rounded-full">
                    {story?.genre}
                  </span>
                  <span className="text-xs text-muted-foreground">
                    {formatLastRead(story?.lastRead)}
                  </span>
                </div>

                <h3 className="font-heading font-semibold text-base text-card-foreground mb-1 line-clamp-2">
                  {story?.title}
                </h3>

                <p className="text-sm text-muted-foreground mb-3">by {story?.author}</p>

                {/* Progress Info */}
                <div className="space-y-2 mb-3">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">
                      Chapter {story?.currentChapter} of {story?.totalChapters}
                    </span>
                    <span className="text-muted-foreground">
                      {story?.progress}%
                    </span>
                  </div>
                  
                  {/* Progress Bar */}
                  <div className="w-full bg-muted rounded-full h-2">
                    <div 
                      className={`h-2 rounded-full transition-all duration-300 ${getProgressColor(story?.progress)}`}
                      style={{ width: `${story?.progress}%` }}
                    />
                  </div>
                  
                  <div className="flex items-center justify-between text-xs text-muted-foreground">
                    <div className="flex items-center space-x-1">
                      <Icon name="Clock" size={12} />
                      <span>{story?.estimatedTimeLeft} left</span>
                    </div>
                  </div>
                </div>

                <Link to="/interactive-story-reader">
                  <Button variant="default" size="sm" className="w-full">
                    Continue Reading
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        ))}
      </div>
      {/* Empty State */}
      {inProgressStories?.length === 0 && (
        <div className="text-center py-12 bg-card rounded-xl">
          <Icon name="BookOpen" size={48} className="mx-auto text-muted-foreground mb-4" />
          <h3 className="text-lg font-heading font-semibold text-card-foreground mb-2">
            No stories in progress
          </h3>
          <p className="text-muted-foreground mb-4">
            Start reading a story to see your progress here
          </p>
          <Link to="/story-discovery-dashboard">
            <Button variant="default">
              Discover Stories
            </Button>
          </Link>
        </div>
      )}
    </div>
  );
};

export default ContinueReading;