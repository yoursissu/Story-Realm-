import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Input from '../../../components/ui/Input';
import Button from '../../../components/ui/Button';

const SearchAndFilters = ({ onSearch, onFilterChange }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeFilters, setActiveFilters] = useState([]);
  const [showFilters, setShowFilters] = useState(false);

  const filterOptions = [
    { id: 'fantasy', label: 'Fantasy', icon: 'Sparkles' },
    { id: 'sci-fi', label: 'Sci-Fi', icon: 'Rocket' },
    { id: 'romance', label: 'Romance', icon: 'Heart' },
    { id: 'mystery', label: 'Mystery', icon: 'Search' },
    { id: 'horror', label: 'Horror', icon: 'Ghost' },
    { id: 'adventure', label: 'Adventure', icon: 'Map' },
    { id: 'short', label: 'Short (&lt;30 min)', icon: 'Clock' },
    { id: 'medium', label: 'Medium (30-60 min)', icon: 'Clock' },
    { id: 'long', label: 'Long (&gt;60 min)', icon: 'Clock' },
    { id: 'complete', label: 'Complete', icon: 'CheckCircle' },
    { id: 'ongoing', label: 'Ongoing', icon: 'PlayCircle' },
    { id: 'new', label: 'New Releases', icon: 'Star' },
    { id: 'trending', label: 'Trending', icon: 'TrendingUp' },
    { id: 'high-rated', label: 'Highly Rated (4.5+)', icon: 'Award' }
  ];

  const searchSuggestions = [
    "Dragon adventures",
    "Time travel romance",
    "Detective mysteries",
    "Space exploration",
    "Magic academy",
    "Vampire stories",
    "Post-apocalyptic",
    "Historical fiction"
  ];

  const handleSearchChange = (e) => {
    const value = e?.target?.value;
    setSearchQuery(value);
    if (onSearch) {
      onSearch(value);
    }
  };

  const toggleFilter = (filterId) => {
    const newFilters = activeFilters?.includes(filterId)
      ? activeFilters?.filter(f => f !== filterId)
      : [...activeFilters, filterId];
    
    setActiveFilters(newFilters);
    if (onFilterChange) {
      onFilterChange(newFilters);
    }
  };

  const clearAllFilters = () => {
    setActiveFilters([]);
    if (onFilterChange) {
      onFilterChange([]);
    }
  };

  const clearSearch = () => {
    setSearchQuery('');
    if (onSearch) {
      onSearch('');
    }
  };

  return (
    <div className="mb-6">
      {/* Search Bar */}
      <div className="relative mb-4">
        <div className="relative">
          <Icon 
            name="Search" 
            size={20} 
            className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" 
          />
          <Input
            type="search"
            placeholder="Search stories, authors, or genres..."
            value={searchQuery}
            onChange={handleSearchChange}
            className="pl-10 pr-20"
          />
          {searchQuery && (
            <Button
              variant="ghost"
              size="icon"
              className="absolute right-12 top-1/2 -translate-y-1/2"
              onClick={clearSearch}
            >
              <Icon name="X" size={16} />
            </Button>
          )}
          <Button
            variant="ghost"
            size="icon"
            className="absolute right-2 top-1/2 -translate-y-1/2"
            onClick={() => setShowFilters(!showFilters)}
          >
            <Icon name="Filter" size={16} />
          </Button>
        </div>

        {/* Search Suggestions */}
        {searchQuery && (
          <div className="absolute top-full left-0 right-0 bg-popover border border-border rounded-lg shadow-warm-lg z-50 mt-1">
            <div className="p-2">
              {searchSuggestions?.filter(suggestion => 
                  suggestion?.toLowerCase()?.includes(searchQuery?.toLowerCase())
                )?.slice(0, 5)?.map((suggestion, index) => (
                  <button
                    key={index}
                    className="flex items-center space-x-2 w-full px-3 py-2 text-sm text-popover-foreground hover:bg-muted rounded-md transition-colors text-left"
                    onClick={() => {
                      setSearchQuery(suggestion);
                      if (onSearch) onSearch(suggestion);
                    }}
                  >
                    <Icon name="Search" size={14} />
                    <span>{suggestion}</span>
                  </button>
                ))}
            </div>
          </div>
        )}
      </div>
      {/* Active Filters Display */}
      {activeFilters?.length > 0 && (
        <div className="flex flex-wrap items-center gap-2 mb-4">
          <span className="text-sm text-muted-foreground">Active filters:</span>
          {activeFilters?.map((filterId) => {
            const filter = filterOptions?.find(f => f?.id === filterId);
            return (
              <div
                key={filterId}
                className="flex items-center space-x-1 bg-primary text-primary-foreground px-3 py-1 rounded-full text-sm"
              >
                <Icon name={filter?.icon || 'Tag'} size={14} />
                <span>{filter?.label}</span>
                <button
                  onClick={() => toggleFilter(filterId)}
                  className="ml-1 hover:bg-primary-foreground/20 rounded-full p-0.5"
                >
                  <Icon name="X" size={12} />
                </button>
              </div>
            );
          })}
          <Button
            variant="ghost"
            size="sm"
            onClick={clearAllFilters}
            className="text-muted-foreground hover:text-foreground"
          >
            Clear all
          </Button>
        </div>
      )}
      {/* Filter Options */}
      {showFilters && (
        <div className="bg-card border border-border rounded-lg p-4 shadow-warm-md">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-heading font-semibold text-card-foreground">Filter Stories</h3>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setShowFilters(false)}
            >
              <Icon name="X" size={16} />
            </Button>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-2">
            {filterOptions?.map((filter) => (
              <button
                key={filter?.id}
                onClick={() => toggleFilter(filter?.id)}
                className={`flex items-center space-x-2 px-3 py-2 rounded-lg text-sm font-medium transition-all ${
                  activeFilters?.includes(filter?.id)
                    ? 'bg-primary text-primary-foreground'
                    : 'bg-muted text-muted-foreground hover:bg-muted/80 hover:text-foreground'
                }`}
              >
                <Icon name={filter?.icon} size={14} />
                <span className="truncate">{filter?.label}</span>
              </button>
            ))}
          </div>

          <div className="flex justify-between items-center mt-4 pt-3 border-t border-border">
            <span className="text-sm text-muted-foreground">
              {activeFilters?.length} filter{activeFilters?.length !== 1 ? 's' : ''} selected
            </span>
            <div className="flex space-x-2">
              <Button variant="outline" size="sm" onClick={clearAllFilters}>
                Clear All
              </Button>
              <Button variant="default" size="sm" onClick={() => setShowFilters(false)}>
                Apply Filters
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default SearchAndFilters;