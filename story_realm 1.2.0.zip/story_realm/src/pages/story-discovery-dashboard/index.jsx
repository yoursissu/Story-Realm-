import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import TrendingStoriesCarousel from './components/TrendingStoriesCarousel';
import PersonalizedRecommendations from './components/PersonalizedRecommendations';
import GenreCollections from './components/GenreCollections';
import ContinueReading from './components/ContinueReading';
import SearchAndFilters from './components/SearchAndFilters';
import FeaturedStories from './components/FeaturedStories';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';

const StoryDiscoveryDashboard = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeFilters, setActiveFilters] = useState([]);
  const [refreshing, setRefreshing] = useState(false);
  const [currentLanguage, setCurrentLanguage] = useState('en');

  useEffect(() => {
    // Check for saved language preference
    const savedLanguage = localStorage.getItem('preferredLanguage') || 'en';
    setCurrentLanguage(savedLanguage);
  }, []);

  const handleSearch = (query) => {
    setSearchQuery(query);
    // Mock search functionality
    console.log('Searching for:', query);
  };

  const handleFilterChange = (filters) => {
    setActiveFilters(filters);
    // Mock filter functionality
    console.log('Active filters:', filters);
  };

  const handleRefresh = async () => {
    setRefreshing(true);
    // Mock refresh functionality
    setTimeout(() => {
      setRefreshing(false);
    }, 1000);
  };

  const quickActions = [
    { label: 'Create Story', icon: 'PenTool', path: '/story-creation-editor', color: 'bg-accent' },
    { label: 'Reading List', icon: 'BookOpen', path: '/user-profile-management', color: 'bg-primary' },
    { label: 'Bookmarks', icon: 'Bookmark', path: '/user-profile-management', color: 'bg-secondary' },
    { label: 'Profile', icon: 'User', path: '/user-profile-management', color: 'bg-success' }
  ];

  return (
    <>
      <Helmet>
        <title>Discover Stories - Story Realm</title>
        <meta name="description" content="Discover amazing interactive stories across all genres. Find your next favorite read with personalized recommendations and trending stories." />
        <meta name="keywords" content="interactive stories, reading, fiction, fantasy, sci-fi, romance, mystery" />
      </Helmet>
      <div className="min-h-screen bg-background">
        {/* Mobile Pull-to-Refresh Indicator */}
        {refreshing && (
          <div className="fixed top-16 left-0 right-0 z-50 bg-primary text-primary-foreground text-center py-2 text-sm">
            <Icon name="RefreshCw" size={16} className="inline mr-2 animate-spin" />
            Refreshing recommendations...
          </div>
        )}

        <div className="container mx-auto px-4 py-6">
          {/* Welcome Section */}
          <div className="mb-6">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h1 className="text-3xl font-heading font-bold text-foreground mb-2">
                  Welcome back, Reader!
                </h1>
                <p className="text-muted-foreground">
                  Discover your next favorite story from thousands of interactive tales
                </p>
              </div>
              
              {/* Desktop Quick Actions */}
              <div className="hidden lg:flex space-x-2">
                {quickActions?.map((action, index) => (
                  <Button
                    key={index}
                    variant="ghost"
                    size="sm"
                    className="flex items-center space-x-2"
                  >
                    <div className={`w-8 h-8 ${action?.color} rounded-lg flex items-center justify-center`}>
                      <Icon name={action?.icon} size={16} color="white" />
                    </div>
                    <span className="hidden xl:inline">{action?.label}</span>
                  </Button>
                ))}
              </div>
            </div>

            {/* Mobile Quick Actions */}
            <div className="lg:hidden grid grid-cols-4 gap-3 mb-6">
              {quickActions?.map((action, index) => (
                <button
                  key={index}
                  className="flex flex-col items-center space-y-2 p-3 bg-card rounded-xl hover:shadow-warm-md transition-all"
                >
                  <div className={`w-10 h-10 ${action?.color} rounded-lg flex items-center justify-center`}>
                    <Icon name={action?.icon} size={18} color="white" />
                  </div>
                  <span className="text-xs font-medium text-card-foreground">{action?.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Search and Filters */}
          <SearchAndFilters 
            onSearch={handleSearch}
            onFilterChange={handleFilterChange}
          />

          {/* Featured Story */}
          <FeaturedStories />

          {/* Continue Reading Section */}
          <ContinueReading />

          {/* Trending Stories */}
          <TrendingStoriesCarousel />

          {/* Personalized Recommendations */}
          <PersonalizedRecommendations />

          {/* Genre Collections */}
          <GenreCollections />

          {/* Community Section */}
          <div className="mb-8">
            <div className="bg-card rounded-xl p-6 shadow-warm-md">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-2xl font-heading font-semibold text-card-foreground">Join the Community</h2>
                <Icon name="Users" size={24} className="text-primary" />
              </div>
              
              <p className="text-muted-foreground mb-4">
                Connect with fellow readers, share your thoughts, and discover stories through community recommendations.
              </p>
              
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="text-center p-4 bg-muted/30 rounded-lg">
                  <Icon name="MessageCircle" size={32} className="mx-auto text-primary mb-2" />
                  <h3 className="font-semibold text-card-foreground mb-1">Discussions</h3>
                  <p className="text-sm text-muted-foreground">Join story discussions</p>
                </div>
                
                <div className="text-center p-4 bg-muted/30 rounded-lg">
                  <Icon name="Star" size={32} className="mx-auto text-accent mb-2" />
                  <h3 className="font-semibold text-card-foreground mb-1">Reviews</h3>
                  <p className="text-sm text-muted-foreground">Share your ratings</p>
                </div>
                
                <div className="text-center p-4 bg-muted/30 rounded-lg">
                  <Icon name="Trophy" size={32} className="mx-auto text-warning mb-2" />
                  <h3 className="font-semibold text-card-foreground mb-1">Challenges</h3>
                  <p className="text-sm text-muted-foreground">Reading challenges</p>
                </div>
              </div>
            </div>
          </div>

          {/* Stats Section */}
          <div className="mb-8">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="bg-card rounded-xl p-4 text-center shadow-warm-md">
                <Icon name="BookOpen" size={32} className="mx-auto text-primary mb-2" />
                <div className="text-2xl font-bold text-card-foreground">12,450</div>
                <div className="text-sm text-muted-foreground">Stories Available</div>
              </div>
              
              <div className="bg-card rounded-xl p-4 text-center shadow-warm-md">
                <Icon name="Users" size={32} className="mx-auto text-accent mb-2" />
                <div className="text-2xl font-bold text-card-foreground">89,234</div>
                <div className="text-sm text-muted-foreground">Active Readers</div>
              </div>
              
              <div className="bg-card rounded-xl p-4 text-center shadow-warm-md">
                <Icon name="PenTool" size={32} className="mx-auto text-success mb-2" />
                <div className="text-2xl font-bold text-card-foreground">3,567</div>
                <div className="text-sm text-muted-foreground">Authors</div>
              </div>
              
              <div className="bg-card rounded-xl p-4 text-center shadow-warm-md">
                <Icon name="Star" size={32} className="mx-auto text-warning mb-2" />
                <div className="text-2xl font-bold text-card-foreground">4.8</div>
                <div className="text-sm text-muted-foreground">Avg Rating</div>
              </div>
            </div>
          </div>

          {/* Mobile Bottom Spacing */}
          <div className="h-20 md:h-0" />
        </div>

        {/* Mobile Floating Action Button */}
        <div className="fixed bottom-6 right-6 md:hidden z-40">
          <Button
            variant="default"
            size="icon"
            className="w-14 h-14 rounded-full shadow-warm-lg"
            onClick={handleRefresh}
          >
            <Icon name={refreshing ? "RefreshCw" : "Plus"} size={24} className={refreshing ? "animate-spin" : ""} />
          </Button>
        </div>
      </div>
    </>
  );
};

export default StoryDiscoveryDashboard;