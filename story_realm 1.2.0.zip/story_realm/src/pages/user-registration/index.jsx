import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import Icon from '../../components/AppIcon';
import Image from '../../components/AppImage';
import Button from '../../components/ui/Button';
import SocialRegistration from './components/SocialRegistration';
import RegistrationForm from './components/RegistrationForm';
import EmailVerificationNotice from './components/EmailVerificationNotice';

const UserRegistration = () => {
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(false);
  const [registrationStep, setRegistrationStep] = useState('form'); // 'form' | 'verification'
  const [registeredEmail, setRegisteredEmail] = useState('');

  // Mock registration data for demonstration
  const mockExistingUsers = [
    'john_doe',
    'jane_smith',
    'storyteller123',
    'writer_pro',
    'bookworm_reader'
  ];

  const mockExistingEmails = [
    'john@example.com',
    'jane@example.com',
    'test@storyrealm.com',
    'demo@example.com'
  ];

  const handleSocialRegister = async (provider) => {
    setIsLoading(true);
    
    // Simulate social registration
    setTimeout(() => {
      setIsLoading(false);
      // Simulate successful social registration
      navigate('/story-discovery-dashboard');
    }, 2000);
  };

  const handleFormSubmit = async (formData) => {
    setIsLoading(true);

    // Simulate form validation and registration
    setTimeout(() => {
      // Check for existing username
      if (mockExistingUsers?.includes(formData?.username?.toLowerCase())) {
        setIsLoading(false);
        alert('Username already exists. Please choose a different one.');
        return;
      }

      // Check for existing email
      if (mockExistingEmails?.includes(formData?.email?.toLowerCase())) {
        setIsLoading(false);
        alert('Email already registered. Please use a different email or try logging in.');
        return;
      }

      // Simulate successful registration
      setRegisteredEmail(formData?.email);
      setRegistrationStep('verification');
      setIsLoading(false);
    }, 2000);
  };

  const handleResendVerification = () => {
    // Simulate resending verification email
    console.log('Resending verification email to:', registeredEmail);
  };

  const handleBackToRegistration = () => {
    setRegistrationStep('form');
    setRegisteredEmail('');
  };

  return (
    <>
      <Helmet>
        <title>Join Story Realm - Create Your Account</title>
        <meta name="description" content="Join Story Realm's interactive storytelling community. Create your account to start writing, sharing, and discovering amazing stories." />
      </Helmet>

      <div className="min-h-screen bg-background">
        {/* Header */}
        <header className="border-b border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
          <div className="container flex h-16 items-center justify-between">
            <Link to="/story-discovery-dashboard" className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                <Icon name="BookOpen" size={20} color="var(--color-primary-foreground)" />
              </div>
              <span className="font-heading font-semibold text-xl text-foreground">
                Story Realm
              </span>
            </Link>

            <div className="flex items-center space-x-4">
              <span className="text-sm text-muted-foreground hidden sm:inline">
                Already have an account?
              </span>
              <Button variant="outline" asChild>
                <Link to="/user-login">
                  <Icon name="LogIn" size={16} className="mr-2" />
                  Sign In
                </Link>
              </Button>
            </div>
          </div>
        </header>

        {/* Main Content */}
        <main className="container py-8 lg:py-12">
          <div className="flex flex-col lg:flex-row items-center justify-center min-h-[calc(100vh-8rem)] gap-8 lg:gap-16">
            
            {/* Left Side - Hero Content (Desktop) */}
            <div className="hidden lg:flex flex-col items-center text-center max-w-md space-y-6">
              <div className="relative">
                <Image
                  src="https://images.unsplash.com/photo-1481627834876-b7833e8f5570?w=400&h=300&fit=crop"
                  alt="Open book with magical elements"
                  className="w-80 h-60 object-cover rounded-2xl shadow-warm-lg"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-primary/20 to-transparent rounded-2xl" />
              </div>
              
              <div className="space-y-4">
                <h1 className="text-3xl font-heading font-bold text-foreground">
                  Welcome to Story Realm
                </h1>
                <p className="text-muted-foreground leading-relaxed">
                  Join thousands of writers and readers in our interactive storytelling community. 
                  Create, share, and discover amazing stories that come to life.
                </p>
                
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div className="flex items-center space-x-2">
                    <Icon name="Users" size={16} color="var(--color-primary)" />
                    <span className="text-muted-foreground">Active Community</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Icon name="BookOpen" size={16} color="var(--color-primary)" />
                    <span className="text-muted-foreground">Rich Stories</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Icon name="Edit3" size={16} color="var(--color-primary)" />
                    <span className="text-muted-foreground">Easy Writing</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Icon name="Heart" size={16} color="var(--color-primary)" />
                    <span className="text-muted-foreground">Reader Love</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Right Side - Registration Form */}
            <div className="w-full max-w-md">
              <div className="bg-card border border-border rounded-2xl shadow-warm-lg p-6 lg:p-8">
                
                {registrationStep === 'form' ? (
                  <>
                    {/* Mobile Hero */}
                    <div className="lg:hidden text-center mb-6">
                      <h1 className="text-2xl font-heading font-bold text-foreground mb-2">
                        Join Story Realm
                      </h1>
                      <p className="text-sm text-muted-foreground">
                        Create your account to start your storytelling journey
                      </p>
                    </div>

                    {/* Desktop Title */}
                    <div className="hidden lg:block text-center mb-6">
                      <h2 className="text-2xl font-heading font-bold text-foreground mb-2">
                        Create Your Account
                      </h2>
                      <p className="text-sm text-muted-foreground">
                        Start your storytelling journey today
                      </p>
                    </div>

                    {/* Social Registration */}
                    <SocialRegistration onSocialRegister={handleSocialRegister} />

                    {/* Registration Form */}
                    <RegistrationForm onSubmit={handleFormSubmit} isLoading={isLoading} />

                    {/* Login Link */}
                    <div className="text-center mt-6 pt-4 border-t border-border">
                      <p className="text-sm text-muted-foreground">
                        Already have an account?{' '}
                        <Link 
                          to="/user-login" 
                          className="font-medium text-primary hover:text-primary/80 transition-colors"
                        >
                          Sign in here
                        </Link>
                      </p>
                    </div>
                  </>
                ) : (
                  <EmailVerificationNotice
                    email={registeredEmail}
                    onResendVerification={handleResendVerification}
                    onBackToRegistration={handleBackToRegistration}
                  />
                )}
              </div>

              {/* Footer Links */}
              <div className="text-center mt-6 text-xs text-muted-foreground space-x-4">
                <button className="hover:text-foreground transition-colors">
                  Help Center
                </button>
                <span>•</span>
                <button className="hover:text-foreground transition-colors">
                  Contact Support
                </button>
                <span>•</span>
                <button className="hover:text-foreground transition-colors">
                  Community Guidelines
                </button>
              </div>
            </div>
          </div>
        </main>

        {/* Loading Overlay */}
        {isLoading && (
          <div className="fixed inset-0 bg-background/80 backdrop-blur-sm flex items-center justify-center z-50">
            <div className="bg-card border border-border rounded-lg p-6 flex items-center space-x-3">
              <div className="animate-spin">
                <Icon name="Loader2" size={20} color="var(--color-primary)" />
              </div>
              <span className="text-sm text-foreground">Creating your account...</span>
            </div>
          </div>
        )}
      </div>
    </>
  );
};

export default UserRegistration;