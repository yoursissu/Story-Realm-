import React from 'react';

const PasswordStrengthMeter = ({ password }) => {
  const calculateStrength = (pwd) => {
    if (!pwd) return { score: 0, label: '', color: '' };
    
    let score = 0;
    const checks = {
      length: pwd?.length >= 8,
      lowercase: /[a-z]/?.test(pwd),
      uppercase: /[A-Z]/?.test(pwd),
      numbers: /\d/?.test(pwd),
      special: /[!@#$%^&*(),.?":{}|<>]/?.test(pwd)
    };
    
    score = Object.values(checks)?.filter(Boolean)?.length;
    
    const strengthLevels = {
      0: { label: '', color: '', bgColor: '' },
      1: { label: 'Very Weak', color: 'text-red-600', bgColor: 'bg-red-200' },
      2: { label: 'Weak', color: 'text-orange-600', bgColor: 'bg-orange-200' },
      3: { label: 'Fair', color: 'text-yellow-600', bgColor: 'bg-yellow-200' },
      4: { label: 'Good', color: 'text-blue-600', bgColor: 'bg-blue-200' },
      5: { label: 'Strong', color: 'text-green-600', bgColor: 'bg-green-200' }
    };
    
    return { score, ...strengthLevels?.[score], checks };
  };

  const strength = calculateStrength(password);

  if (!password) return null;

  return (
    <div className="mt-2 space-y-2">
      <div className="flex items-center justify-between">
        <span className="text-xs text-muted-foreground">Password strength:</span>
        <span className={`text-xs font-medium ${strength?.color}`}>
          {strength?.label}
        </span>
      </div>
      <div className="w-full bg-muted rounded-full h-2">
        <div
          className={`h-2 rounded-full transition-all duration-300 ${strength?.bgColor}`}
          style={{ width: `${(strength?.score / 5) * 100}%` }}
        />
      </div>
      <div className="text-xs text-muted-foreground space-y-1">
        <div className="grid grid-cols-1 gap-1">
          <div className={`flex items-center ${strength?.checks?.length ? 'text-green-600' : 'text-muted-foreground'}`}>
            <span className="w-2 h-2 rounded-full bg-current mr-2" />
            At least 8 characters
          </div>
          <div className={`flex items-center ${strength?.checks?.lowercase && strength?.checks?.uppercase ? 'text-green-600' : 'text-muted-foreground'}`}>
            <span className="w-2 h-2 rounded-full bg-current mr-2" />
            Upper & lowercase letters
          </div>
          <div className={`flex items-center ${strength?.checks?.numbers ? 'text-green-600' : 'text-muted-foreground'}`}>
            <span className="w-2 h-2 rounded-full bg-current mr-2" />
            At least one number
          </div>
          <div className={`flex items-center ${strength?.checks?.special ? 'text-green-600' : 'text-muted-foreground'}`}>
            <span className="w-2 h-2 rounded-full bg-current mr-2" />
            Special character
          </div>
        </div>
      </div>
    </div>
  );
};

export default PasswordStrengthMeter;