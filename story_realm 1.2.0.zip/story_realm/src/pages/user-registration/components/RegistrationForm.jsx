import React, { useState } from 'react';
import Input from '../../../components/ui/Input';
import Button from '../../../components/ui/Button';
import { Checkbox } from '../../../components/ui/Checkbox';
import Select from '../../../components/ui/Select';
import PasswordStrengthMeter from './PasswordStrengthMeter';
import Icon from '../../../components/AppIcon';

const RegistrationForm = ({ onSubmit, isLoading }) => {
  const [formData, setFormData] = useState({
    username: '',
    email: '',
    password: '',
    confirmPassword: '',
    displayName: '',
    bio: '',
    interests: [],
    agreeToTerms: false,
    subscribeNewsletter: true
  });

  const [errors, setErrors] = useState({});
  const [showOptionalFields, setShowOptionalFields] = useState(false);

  const interestOptions = [
    { value: 'fantasy', label: 'Fantasy' },
    { value: 'romance', label: 'Romance' },
    { value: 'mystery', label: 'Mystery' },
    { value: 'sci-fi', label: 'Science Fiction' },
    { value: 'thriller', label: 'Thriller' },
    { value: 'horror', label: 'Horror' },
    { value: 'adventure', label: 'Adventure' },
    { value: 'drama', label: 'Drama' },
    { value: 'comedy', label: 'Comedy' },
    { value: 'historical', label: 'Historical Fiction' }
  ];

  const validateForm = () => {
    const newErrors = {};

    if (!formData?.username?.trim()) {
      newErrors.username = 'Username is required';
    } else if (formData?.username?.length < 3) {
      newErrors.username = 'Username must be at least 3 characters';
    } else if (!/^[a-zA-Z0-9_]+$/?.test(formData?.username)) {
      newErrors.username = 'Username can only contain letters, numbers, and underscores';
    }

    if (!formData?.email?.trim()) {
      newErrors.email = 'Email is required';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/?.test(formData?.email)) {
      newErrors.email = 'Please enter a valid email address';
    }

    if (!formData?.password) {
      newErrors.password = 'Password is required';
    } else if (formData?.password?.length < 8) {
      newErrors.password = 'Password must be at least 8 characters';
    }

    if (formData?.password !== formData?.confirmPassword) {
      newErrors.confirmPassword = 'Passwords do not match';
    }

    if (!formData?.agreeToTerms) {
      newErrors.agreeToTerms = 'You must agree to the terms and conditions';
    }

    setErrors(newErrors);
    return Object.keys(newErrors)?.length === 0;
  };

  const handleSubmit = (e) => {
    e?.preventDefault();
    if (validateForm()) {
      onSubmit(formData);
    }
  };

  const handleInputChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (errors?.[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {/* Essential Fields */}
      <div className="space-y-4">
        <Input
          label="Username"
          type="text"
          placeholder="Choose a unique username"
          value={formData?.username}
          onChange={(e) => handleInputChange('username', e?.target?.value)}
          error={errors?.username}
          required
        />

        <Input
          label="Email Address"
          type="email"
          placeholder="Enter your email address"
          value={formData?.email}
          onChange={(e) => handleInputChange('email', e?.target?.value)}
          error={errors?.email}
          required
        />

        <div>
          <Input
            label="Password"
            type="password"
            placeholder="Create a strong password"
            value={formData?.password}
            onChange={(e) => handleInputChange('password', e?.target?.value)}
            error={errors?.password}
            required
          />
          <PasswordStrengthMeter password={formData?.password} />
        </div>

        <Input
          label="Confirm Password"
          type="password"
          placeholder="Confirm your password"
          value={formData?.confirmPassword}
          onChange={(e) => handleInputChange('confirmPassword', e?.target?.value)}
          error={errors?.confirmPassword}
          required
        />
      </div>
      {/* Optional Fields Toggle */}
      <div className="border-t border-border pt-4">
        <Button
          type="button"
          variant="ghost"
          onClick={() => setShowOptionalFields(!showOptionalFields)}
          className="w-full justify-between p-0 h-auto text-left"
        >
          <span className="text-sm font-medium">Optional Profile Details</span>
          <Icon 
            name={showOptionalFields ? "ChevronUp" : "ChevronDown"} 
            size={16} 
          />
        </Button>
      </div>
      {/* Optional Fields */}
      {showOptionalFields && (
        <div className="space-y-4 animate-in slide-in-from-top-2 duration-200">
          <Input
            label="Display Name"
            type="text"
            placeholder="How should others see your name?"
            description="This will be shown on your profile and stories"
            value={formData?.displayName}
            onChange={(e) => handleInputChange('displayName', e?.target?.value)}
          />

          <Input
            label="Bio"
            type="text"
            placeholder="Tell us about yourself..."
            description="A brief description about you as a writer or reader"
            value={formData?.bio}
            onChange={(e) => handleInputChange('bio', e?.target?.value)}
          />

          <Select
            label="Interests"
            description="Select genres you're interested in (optional)"
            options={interestOptions}
            value={formData?.interests}
            onChange={(value) => handleInputChange('interests', value)}
            multiple
            searchable
            placeholder="Choose your favorite genres"
          />
        </div>
      )}
      {/* Terms and Newsletter */}
      <div className="space-y-4 border-t border-border pt-4">
        <Checkbox
          label="I agree to the Terms of Service and Privacy Policy"
          checked={formData?.agreeToTerms}
          onChange={(e) => handleInputChange('agreeToTerms', e?.target?.checked)}
          error={errors?.agreeToTerms}
          required
        />

        <Checkbox
          label="Subscribe to newsletter for updates and writing tips"
          description="You can unsubscribe at any time"
          checked={formData?.subscribeNewsletter}
          onChange={(e) => handleInputChange('subscribeNewsletter', e?.target?.checked)}
        />
      </div>
      {/* Submit Button */}
      <Button
        type="submit"
        variant="default"
        size="lg"
        loading={isLoading}
        fullWidth
        className="mt-6"
      >
        Create Account
      </Button>
      {/* Legal Links */}
      <div className="text-center text-xs text-muted-foreground space-x-4">
        <button type="button" className="hover:text-foreground transition-colors">
          Terms of Service
        </button>
        <span>•</span>
        <button type="button" className="hover:text-foreground transition-colors">
          Privacy Policy
        </button>
      </div>
    </form>
  );
};

export default RegistrationForm;