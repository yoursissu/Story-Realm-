import React, { useState, useEffect } from 'react';
import Button from '../../../components/ui/Button';
import Icon from '../../../components/AppIcon';

const EmailVerificationNotice = ({ email, onResendVerification, onBackToRegistration }) => {
  const [countdown, setCountdown] = useState(60);
  const [canResend, setCanResend] = useState(false);

  useEffect(() => {
    if (countdown > 0) {
      const timer = setTimeout(() => setCountdown(countdown - 1), 1000);
      return () => clearTimeout(timer);
    } else {
      setCanResend(true);
    }
  }, [countdown]);

  const handleResend = () => {
    onResendVerification();
    setCountdown(60);
    setCanResend(false);
  };

  return (
    <div className="text-center space-y-6">
      <div className="w-16 h-16 bg-success/10 rounded-full flex items-center justify-center mx-auto">
        <Icon name="Mail" size={32} color="var(--color-success)" />
      </div>

      <div className="space-y-2">
        <h2 className="text-2xl font-heading font-semibold text-foreground">
          Check Your Email
        </h2>
        <p className="text-muted-foreground">
          We've sent a verification link to
        </p>
        <p className="font-medium text-foreground break-all">
          {email}
        </p>
      </div>

      <div className="bg-muted/50 rounded-lg p-4 space-y-3">
        <div className="flex items-start space-x-3">
          <Icon name="Info" size={20} color="var(--color-primary)" className="mt-0.5 flex-shrink-0" />
          <div className="text-sm text-muted-foreground text-left space-y-2">
            <p>Click the verification link in your email to activate your account.</p>
            <p>If you don't see the email, check your spam folder.</p>
          </div>
        </div>
      </div>

      <div className="space-y-3">
        <Button
          variant="outline"
          onClick={handleResend}
          disabled={!canResend}
          className="w-full"
        >
          {canResend ? (
            <>
              <Icon name="RefreshCw" size={16} className="mr-2" />
              Resend Verification Email
            </>
          ) : (
            `Resend in ${countdown}s`
          )}
        </Button>

        <Button
          variant="ghost"
          onClick={onBackToRegistration}
          className="w-full"
        >
          <Icon name="ArrowLeft" size={16} className="mr-2" />
          Back to Registration
        </Button>
      </div>

      <div className="text-xs text-muted-foreground">
        <p>
          Having trouble? Contact our{' '}
          <button className="text-primary hover:underline">
            support team
          </button>
        </p>
      </div>
    </div>
  );
};

export default EmailVerificationNotice;