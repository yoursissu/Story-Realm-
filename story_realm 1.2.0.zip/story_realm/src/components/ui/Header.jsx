import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import Icon from '../AppIcon';
import Button from './Button';

const Header = () => {
  const location = useLocation();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);

  const navigationItems = [
    { label: 'Discover', path: '/story-discovery-dashboard', icon: 'Compass' },
    { label: 'Create', path: '/story-creation-editor', icon: 'PenTool' },
    { label: 'Profile', path: '/user-profile-management', icon: 'User' },
  ];

  const isActive = (path) => location?.pathname === path;

  const Logo = () => (
    <Link to="/story-discovery-dashboard" className="flex items-center space-x-2">
      <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
        <Icon name="BookOpen" size={20} color="var(--color-primary-foreground)" />
      </div>
      <span className="font-heading font-semibold text-xl text-foreground">
        Story Realm
      </span>
    </Link>
  );

  const UserAvatar = () => (
    <div className="relative">
      <Button
        variant="ghost"
        size="icon"
        onClick={() => setIsUserMenuOpen(!isUserMenuOpen)}
        className="rounded-full"
      >
        <div className="w-8 h-8 bg-secondary rounded-full flex items-center justify-center">
          <Icon name="User" size={16} color="var(--color-secondary-foreground)" />
        </div>
      </Button>
      
      {isUserMenuOpen && (
        <div className="absolute right-0 top-12 w-48 bg-popover border border-border rounded-lg shadow-warm-lg z-50">
          <div className="p-2">
            <Link
              to="/user-profile-management"
              className="flex items-center space-x-2 px-3 py-2 text-sm text-popover-foreground hover:bg-muted rounded-md transition-colors"
              onClick={() => setIsUserMenuOpen(false)}
            >
              <Icon name="User" size={16} />
              <span>Profile</span>
            </Link>
            <button className="flex items-center space-x-2 px-3 py-2 text-sm text-popover-foreground hover:bg-muted rounded-md transition-colors w-full text-left">
              <Icon name="Settings" size={16} />
              <span>Settings</span>
            </button>
            <button className="flex items-center space-x-2 px-3 py-2 text-sm text-popover-foreground hover:bg-muted rounded-md transition-colors w-full text-left">
              <Icon name="HelpCircle" size={16} />
              <span>Help</span>
            </button>
            <hr className="my-2 border-border" />
            <button className="flex items-center space-x-2 px-3 py-2 text-sm text-error hover:bg-muted rounded-md transition-colors w-full text-left">
              <Icon name="LogOut" size={16} />
              <span>Sign Out</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );

  // Don't render header on auth pages
  if (location?.pathname === '/user-login' || location?.pathname === '/user-registration') {
    return null;
  }

  return (
    <header className="sticky top-0 z-40 w-full bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 border-b border-border">
      <div className="container flex h-16 items-center justify-between">
        <Logo />
        
        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center space-x-6">
          {navigationItems?.map((item) => (
            <Link
              key={item?.path}
              to={item?.path}
              className={`flex items-center space-x-2 px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                isActive(item?.path)
                  ? 'bg-primary text-primary-foreground'
                  : 'text-muted-foreground hover:text-foreground hover:bg-muted'
              }`}
            >
              <Icon name={item?.icon} size={16} />
              <span>{item?.label}</span>
            </Link>
          ))}
        </nav>

        {/* Desktop User Menu */}
        <div className="hidden md:flex items-center space-x-4">
          <UserAvatar />
        </div>

        {/* Mobile Menu Button */}
        <div className="md:hidden flex items-center space-x-2">
          <UserAvatar />
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            <Icon name={isMenuOpen ? "X" : "Menu"} size={20} />
          </Button>
        </div>
      </div>
      {/* Mobile Navigation Menu */}
      {isMenuOpen && (
        <div className="md:hidden border-t border-border bg-background">
          <nav className="container py-4 space-y-2">
            {navigationItems?.map((item) => (
              <Link
                key={item?.path}
                to={item?.path}
                className={`flex items-center space-x-3 px-3 py-3 rounded-md text-sm font-medium transition-colors ${
                  isActive(item?.path)
                    ? 'bg-primary text-primary-foreground'
                    : 'text-muted-foreground hover:text-foreground hover:bg-muted'
                }`}
                onClick={() => setIsMenuOpen(false)}
              >
                <Icon name={item?.icon} size={18} />
                <span>{item?.label}</span>
              </Link>
            ))}
          </nav>
        </div>
      )}
    </header>
  );
};

export default Header;